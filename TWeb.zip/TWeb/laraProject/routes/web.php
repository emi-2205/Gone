<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

/******************************************************************************
        SEZIONE PUBBLICA
******************************************************************************/

Route::get('/', 'PublicController@showHome')
        ->name('home');

Route::get('/catalogo', 'PublicController@showCatalogoAlloggi')
        ->name('catalogo');

Route::get('/faq/{categoria_id}', 'FaqController@showFaqList')
        ->name('faq-list');

/******************************************************************************
        LOGIN E REGISTRAZIONE UTENTI
******************************************************************************/

// Rotte per l'autenticazione
Route::get('login', 'Auth\LoginController@showLoginForm')
        ->name('login');

Route::post('login', 'Auth\LoginController@login');

Route::post('logout', 'Auth\LoginController@logout')
        ->name('logout');

// Rotte per la registrazione
Route::get('register', 'Auth\RegisterController@showRegistrationForm')
        ->name('register');

Route::post('register', 'Auth\RegisterController@register');

// Rotte per la modifica del profilo utente
Route::get('profilo', 'UserController@showProfilo')
// attraverso la chiave can (definita in App/Http/Kernel.php) che attiva il middleware (definito in Illuminate/Auth/Middleware/Authorize) 
// richiamo nella rotta la regola isNotAmministratore definita in App/Providers/AuthServiceProvider.php
        ->name('profilo')->middleware('can:isNotAmministratore');

Route::post('profilo', 'UserController@updateProfilo')
        ->name('updateProfilo')->middleware('can:isNotAmministratore');


/******************************************************************************
        LOCATARIO
******************************************************************************/

Route::get('/locatario/search', 'AlloggioController@startSearch')
        ->name('locatario-search')->middleware('can:isLocatario');

Route::get('/locatario/find', 'AlloggioController@findAlloggi')
        ->name('locatario-find')->middleware('can:isLocatario');

Route::get('/locatario/chat/{chat_id}', 'ChatController@showChat')
        ->name('chat-locatario')->middleware('can:isLocatario');

Route::get('/locatario/lista-chat', 'ChatController@listaChat')
        ->name('lista-chat-locatario')->middleware('can:isLocatario');

Route::get('/locatario/lista-opzioni', 'ChatController@listaOpzioni')
        ->name('lista-opzioni-locatario')->middleware('can:isLocatario');

/******************************************************************************
        LOCATORE
******************************************************************************/

// Gestione del drill-down

// Elenco degli alloggi del locatore con possibilità di editing e inserimento
Route::get('/locatore/alloggi', 'AlloggioController@alloggiDelLocatore')
        ->name('locatore-all-alloggi')->middleware('can:isLocatore');

// Primo livello: cerco tutte le chat del locatore che hanno avuto almeno un contatto
Route::get('/locatore/chat', 'ChatController@showAllLocatoreChat')
        ->name('locatore-all-chat')->middleware('can:isLocatore');

Route::get('/locatore/archivio', 'ChatController@showAllLocatoreArchivioChat')
        ->name('locatore-archivio-chat')->middleware('can:isLocatore');

// Secondo livello: cerco della chat selezionata tutti i locatari che la hanno contattata
Route::get('/locatore/chat/{chat_id}', 'ChatController@showAllLocatari')
        ->name('locatore-chat-all-locatari')->middleware('can:isLocatore');

// Terzo livello: mostro i messaggi della chat selezionata con il locatario selezionato
Route::get('/locatore/chat/{chat_id}/locatario/{locatario_id}', 'ChatController@showChat')
        ->name('chat-locatore')->middleware('can:isLocatore');

/******************************/

Route::get('/locatore/newalloggio', 'AlloggioController@addAlloggio')
        ->name('newalloggio')->middleware('can:isLocatore');

Route::post('/locatore/newalloggio', 'AlloggioController@storeAlloggio')
        ->name('newalloggio.store')->middleware('can:isLocatore');

Route::get('/locatore/alloggio/{alloggioId}', 'AlloggioController@showAlloggio')
        ->name('alloggio')->middleware('can:isLocatore');

Route::post('/locatore/alloggio/{alloggioId}', 'AlloggioController@updateAlloggio')
        ->name('alloggio.update')->middleware('can:isLocatore');

Route::get('/locatore/alloggio/elimina/{id}', 'AlloggioController@eliminaAlloggio')
        ->name('alloggio.elimina')->middleware('can:isLocatore');

/*******************************/

Route::get('/stampa_contratto/{alloggio_id}', 'AlloggioController@stampaContratto')
        ->name('stampa.contratto')->middleware('can:isLocatore');

/******************************************************************************
        AMMINISTRATORE
******************************************************************************/

Route::get('/statistiche', 'StatController@statistiche')
        ->name('statistiche')->middleware('can:isAmministratore');

Route::post('/statistiche/calcola', 'StatController@calcolaStatistica')
        ->name('statistiche-calcola')->middleware('can:isAmministratore');

Route::get('/faq/admin/{categoria_id}', 'FaqController@showAdminFaqList')
        ->name('faq-list-admin')->middleware('can:isAmministratore');

// Create
Route::get('/newfaq', 'FaqController@add_faq')
        ->name('newfaq')->middleware('can:isAmministratore');

Route::post('/newfaq', 'FaqController@save_faq')
        ->name('newfaq.store')->middleware('can:isAmministratore');

//Update
Route::get('/editfaq/{faqid}', 'FaqController@edit_faq')
        ->name('editfaq')->middleware('can:isAmministratore');

Route::post('/editfaq', 'FaqController@store_faq')
        ->name('editfaq.store')->middleware('can:isAmministratore');

//Delete
Route::get('/deletefaq/{faqid}', 'FaqController@delete_faq')
        ->name('deletefaq')->middleware('can:isAmministratore');

/******************************************************************************
        MESSAGGISTICA
******************************************************************************/

Route::post('/chat/sendmessage', 'ChatController@sendMessage')
        ->name('send.message')->middleware('can:isNotAmministratore');

/******************************************************************************/

Route::view('/wip', 'wip')
        ->name('wip');


