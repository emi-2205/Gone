<?php $__env->startSection('title', 'Chat Locatore'); ?>
<?php if(isset($alloggio)): ?>
<?php $__env->startSection('heading', "Locatari interessati all'alloggio ".$alloggio->nome); ?>
<?php endif; ?>
<?php if(empty($alloggio)): ?>
<?php $__env->startSection('heading', "Locatari interessati a un alloggio non presente nel sistema."); ?>
<?php endif; ?>
<?php $__env->startSection('legenda', "Puoi trovare qui l'elenco di tutti i locatari interessati al tuo alloggio." ); ?>


<?php $__env->startSection('content'); ?>



<?php echo $__env->make('componenti/list_locatari', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/locatore/locatari_list.blade.php ENDPATH**/ ?>