<?php $__env->startSection('title', 'Work In Progress'); ?>

<?php $__env->startSection('heading', 'Work In Progress'); ?>

<?php $__env->startSection('content'); ?>

<img src="<?php echo e(asset('images/under-construction.jpg')); ?>" alt="Logo" style="width:100%">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/wip.blade.php ENDPATH**/ ?>