<?php $__env->startSection('title', 'Statistiche'); ?>

<?php $__env->startSection('heading', 'Calcolo delle statistiche'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('helpers/error_display', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo e(Form::open(array('route' => 'statistiche-calcola', 'id' => 'statistiche',
                    'class' => 'w3-container w3-margin w3-container',
                    'style' => "border: 2px solid lightgrey; border-radius: 8px; padding: 5px; background-color: #BDBBBB5E; max-width:2000px"))); ?>





<div class="w3-row-padding">
    <div class="w3-third">
        <div  class="w3-section">
            <?php echo e(Form::label('tipologia', 'Tipologia :')); ?>

            <?php echo e(Form::select('tipologia', ['Qualsiasi' => 'Qualsiasi', 'Appartamento' => 'Appartamento', 'Posto Letto' => 'Posto Letto'], $tipologia,
                ['class' => 'w3-input w3-border','id' => 'tipologia'])); ?>

        </div>
    </div>
    <div class="w3-third">
        <div  class="w3-section">
            <?php echo e(Form::label('start_date', 'Dalla data :')); ?>

            <?php echo e(Form::date('start_date', $start_date, ['class' => 'w3-input w3-border','id' => 'start_date'])); ?>

        </div>
    </div>
    <div class="w3-third">
        <div  class="w3-section">
            <?php echo e(Form::label('end_date', 'Alla data :')); ?>

            <?php echo e(Form::date('end_date', $end_date, ['class' => 'w3-input w3-border','id' => 'end_date'])); ?>

        </div>
    </div>
</div>









<p class="w3-center">
    <?php echo e(Form::submit('Calcola', ['class' => 'w3-btn w3-blue'])); ?>

</p>


<?php if(isset($alloggi)): ?>
<p>Alloggi: <?php echo e($alloggi); ?></p>
<p>Opzioni: <?php echo e($opzioni); ?></p>
<p>Assegnamenti: <?php echo e($assegnazioni); ?></p>
<?php endif; ?>



<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/amministratore/statistiche.blade.php ENDPATH**/ ?>