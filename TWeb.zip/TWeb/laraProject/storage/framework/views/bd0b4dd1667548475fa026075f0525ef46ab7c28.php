<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <title>MyUniRent | <?php echo $__env->yieldContent('title'); ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- nostre eventuali personalizzazioni agli stili -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" >

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/myunirent.js')); ?>"></script>

        <!-- le pagine che estendono base inseriranno qui i riferimenti agli script a loro necessari -->
        <?php echo $__env->yieldContent('page_specific_js'); ?>


    </head>
    <body>

        <!-- Sidebar/menu -->

        <div id="menu">
            <?php echo $__env->make('layouts/_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- end #menu -->

        <!-- Top menu on small screens -->
        <header class="w3-container w3-top w3-hide-large w3-blue w3-xlarge w3-padding">
            <a href="javascript:void(0)" class="w3-button w3-blue w3-margin-right" onclick="w3_open()">☰</a>
            <span>MyUniRent</span>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left:245px;margin-right:25px">

            <!-- Header -->
            <div class="w3-container" style="margin-top:60px" id="showcase">
                <h1 class="w3-xxlarge"><b><?php echo $__env->yieldContent('heading'); ?></b></h1>
                <hr style="border:2px solid #2196F3" class="w3-round">
                <p class="w3-small"><?php echo $__env->yieldContent('legenda'); ?></p>
            </div>

            <?php echo $__env->yieldContent('content'); ?>

            <!-- End page content -->

            <?php echo $__env->make('layouts/_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <!-- W3.CSS Container -->

    </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/layouts/base.blade.php ENDPATH**/ ?>