<?php $__env->startSection('page_specific_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/alloggioSearch.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo e(Form::open(array('route' => array('newalloggio.store'), 'class' => 'w3-container', 'files' => true))); ?>



<?php echo csrf_field(); ?>

<div  class="w3-section">
    <?php echo e(Form::label('nome', 'Nome', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('nome', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il Nome', 'id' => 'nome'])); ?>

    <?php if($errors->first('nome')): ?>
    <ul class="errors"> 
        <?php $__currentLoopData = $errors->get('nome'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?> 
</div>

<div  class="w3-section">
    <?php echo e(Form::label('descrizione', 'Descrizione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('descrizione', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire la descrizione', 'id' => 'descrizione'])); ?>

    <?php if($errors->first('descrizione')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('descrizione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('canone_affitto', 'Canone affitto', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('canone_affitto',  '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il canone affitto', 'id' => 'canone_affitto'])); ?>

    <?php if($errors->first('canone_affitto')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('canone_affitto'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>





<div  class="w3-section">
    <p class="label-input"><?php echo e(Form::label('superficie', 'Superficie')); ?> &#13217</p>
    <?php echo e(Form::text('superficie', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire la superficie', 'id' => 'superficieId'])); ?>

    <?php if($errors->first('superficie')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('superficie'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('citta', 'Città', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('citta', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire la zona di localizzazione', 'id' => 'zona_localizzazioneId'])); ?>

    <?php if($errors->first('citta')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('citta'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('indirizzo', 'Indirizzo', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('indirizzo', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire la zona di localizzazione', 'id' => 'zona_localizzazioneId'])); ?>

    <?php if($errors->first('indirizzo')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('indirizzo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('eta_min', 'Età minima richiesta', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('eta_min', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire età minima richiesta', 'id' => 'eta_minId'])); ?>

    <?php if($errors->first('eta_min')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('eta_min'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('eta_max', 'Età massima richiesta', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('eta_max', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire età massima richiesta', 'id' => 'eta_maxId'])); ?>

    <?php if($errors->first('eta_max')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('eta_max'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="w3-section">
    <?php echo e(Form::label('genere', 'Genere Richiesto', ['class' => 'label-input'])); ?>

    <?php echo e(Form::select('genere', $generi, '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'genereId'])); ?>

</div>

<div class="w3-section">
    <?php echo e(Form::label('data_inizio_locazione', 'Data Inizio Locazione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::date('data_inizio_locazione', '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'data_inizio_locazioneId'])); ?>

    <?php if($errors->first('data_inizio_locazione')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('data_inizio_locazione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="w3-section">
    <?php echo e(Form::label('data_fine_locazione', 'Data Fine Locazione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::date('data_fine_locazione', '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'data_fine_locazioneId'])); ?>

    <?php if($errors->first('data_fine_locazione')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('data_fine_locazione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="w3-section">   
    <?php echo e(Form::label('immagine', 'Caricamento immaggione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::file('immagine', ['class' => 'input', 'id' => 'immagineId'])); ?>

    <?php if($errors->first('immagine')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('immagine'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>


<div class="w3-section">
    <?php echo e(Form::label('tipologia', 'Tipologia', ['class' => 'label-input'])); ?>

    <?php echo e(Form::select('tipologia', $tipologie, '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'tipologiaId'])); ?>

</div>    


<div id="idBloccoAppartamento">

    <div  class="w3-section">
        <?php echo e(Form::label('num_camere_app', 'Numero camere', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_camere_app', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di camere', 'id' => 'num_camere_app_Id'])); ?>

        <?php if($errors->first('num_camere_app')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_camere_app'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('num_letti_tot_app', 'Numero letti totali', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_letti_tot_app', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di letti totali', 'id' => 'num_letti_tot_app_Id'])); ?>

        <?php if($errors->first('num_letti_tot_app')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_letti_tot_app'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div class="w3-section">
        <?php echo e(Form::label('cucina_app', 'Cucina', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('cucina_app', 1, '')); ?>

    </div>

    <div class="w3-section">
        <?php echo e(Form::label('locale_ricreativo_app', 'Locale ricreativo', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('locale_ricreativo_app', 1, '')); ?>

    </div>

    <div class="w3-section">
        <?php echo e(Form::label('internet_app', 'Internet', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('internet_app', 1, '')); ?>

    </div>

</div>

<div id="idBloccoPostoLetto">

    <div  class="w3-section">
        <?php echo e(Form::label('num_letti_tot_pl', 'Numero letti totali', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_letti_tot_pl', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di letti totali', 'id' => 'num_letti_tot_pl_Id'])); ?>

        <?php if($errors->first('num_letti_tot_pl')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_letti_tot_pl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('num_letti_camera_pl', 'Numero letti della camera', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_letti_camera_pl', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di letti della camera', 'id' => 'num_letti_cameraId'])); ?>

        <?php if($errors->first('num_letti_camera_pl')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_letti_camera_pl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div class="w3-section">
        <?php echo e(Form::label('angolo_studio_pl', 'Angolo studio', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('angolo_studio_pl', 1, '')); ?>

    </div>

    <div class="w3-section">
        <?php echo e(Form::label('internet_pl', 'Internet', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('internet_pl', 1, '')); ?>

    </div>

</div>


<!-- Campi che non devono essere inseriti dall'utente ma comunque valorizzati -->
<?php echo e(Form::hidden('stato', 'Bozza')); ?>



<?php if($errors->any()): ?>
    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

<?php endif; ?>


<div class="container-form-btn">   
    <?php echo e(Form::submit('Salva alloggio', ['class' => 'w3-btn w3-yellow', 'name' => 'azione'])); ?>

    <?php echo e(Form::submit('Pubblica alloggio', ['class' => 'w3-btn w3-green', 'name' => 'azione'])); ?>

    <a href="<?php echo e(route('locatore-all-alloggi')); ?>" class="w3-btn w3-blue">Annulla</a>
</div>

<?php echo e(Form::close()); ?><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/componenti/alloggio_insert.blade.php ENDPATH**/ ?>