<div class="w3-container">

    <table class="w3-table-all w3-hoverable">
        <tr>
            <th>Nome Alloggio</th>
            <th>Descrizione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th class="w3-right-align">Contatti</th>
            <th class="w3-right-align">Opzioni</th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php if(isset($chat->alloggio)): ?>
            <td style="width: 20%"><?php echo e($chat->alloggio->nome); ?></td>
            <td><?php echo e($chat->alloggio->descrizione); ?></td>
            <td style="width: 10%" class="w3-right-align"><?php echo e($chat->alloggio->canone_affitto); ?>&euro;</td>
            <td class="w3-center"><span class="w3-badge w3-yellow"><?php echo e($num_contatti[$chat->id]); ?></span></td>
            <td class="w3-center"><span class="w3-badge w3-green"><?php echo e($num_opzioni[$chat->id]); ?></span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('locatore-chat-all-locatari', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            <?php endif; ?>
            <?php if(empty($chat->alloggio)): ?>
            <td style="width: 20%"><?php echo e($chat->descrizione); ?></td>
            <td>N/A</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-center"><span class="w3-badge w3-yellow"><?php echo e($num_contatti[$chat->id]); ?></span></td>
            <td class="w3-center"><span class="w3-badge w3-green"><?php echo e($num_opzioni[$chat->id]); ?></span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('locatore-chat-all-locatari', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/componenti/chat_list_locatore.blade.php ENDPATH**/ ?>