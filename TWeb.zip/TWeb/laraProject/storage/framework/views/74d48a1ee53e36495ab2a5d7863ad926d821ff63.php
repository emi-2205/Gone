<?php $__env->startSection('page_specific_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/alloggio.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<div class="w3-row-padding">
    <div class="w3-quarter">
        <div  class="w3-section">
            <?php echo e(Form::label('nome', 'Nome')); ?>

            <?php echo e(Form::textarea('nome', null, ['class' => 'w3-input w3-border', 'rows' => 2, 'placeholder' => 'Nome...', 'id' => 'nome'])); ?>

            <?php if($errors->first('nome')): ?>
            <ul class="w3-text-red"> 
                <?php $__currentLoopData = $errors->get('nome'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?> 
        </div>
    </div>
    <div class="w3-threequarter">
        <div  class="w3-section">
            <?php echo e(Form::label('descrizione', 'Descrizione')); ?>

            <?php echo e(Form::textarea('descrizione', null, ['class' => 'w3-input w3-border', 'rows' => 2, 'placeholder' => 'Descrizione...', 'id' => 'descrizione'])); ?>

            <?php if($errors->first('descrizione')): ?>
            <ul class="w3-text-red">
                <?php $__currentLoopData = $errors->get('descrizione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="w3-row-padding">
    <div class="w3-quarter">
        <div  class="w3-section">
            <?php echo e(Form::label('canone_affitto', 'Canone affitto')); ?>

            <?php echo e(Form::text('canone_affitto',  null, ['class' => 'w3-input w3-border', 'placeholder' => 'Canone affitto...', 'id' => 'canone_affitto'])); ?>

            <?php if($errors->first('canone_affitto')): ?>
            <ul class="w3-text-red">
                <?php $__currentLoopData = $errors->get('canone_affitto'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            <?php echo e(Form::label('superficie', 'Superficie mq')); ?>

            <?php echo e(Form::text('superficie', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Superficie...', 'id' => 'superficie'])); ?>

            <?php if($errors->first('superficie')): ?>
            <ul class="w3-text-red">
                <?php $__currentLoopData = $errors->get('superficie'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            <?php echo e(Form::label('citta', 'Città')); ?>

            <?php echo e(Form::text('citta', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Città...', 'id' => 'citta'])); ?>

            <?php if($errors->first('citta')): ?>
            <ul class="w3-text-red">
                <?php $__currentLoopData = $errors->get('citta'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            <?php echo e(Form::label('indirizzo', 'Indirizzo')); ?>

            <?php echo e(Form::text('indirizzo', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Indirizzo...', 'id' => 'indirizzo'])); ?>

            <?php if($errors->first('indirizzo')): ?>
            <ul class="w3-text-red">
                <?php $__currentLoopData = $errors->get('indirizzo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="w3-row-padding">
    <div class="w3-quarter">
        <div  class="w3-section">
            <?php echo e(Form::label('eta_min', 'Età minima richiesta', ['class' => 'label-input'])); ?>

            <?php echo e(Form::text('eta_min', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Età minima richiesta...', 'id' => 'eta_min'])); ?>

            <?php if($errors->first('eta_min')): ?>
            <ul class="errw3-text-redors">
                <?php $__currentLoopData = $errors->get('eta_min'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            <?php echo e(Form::label('eta_max', 'Età massima richiesta')); ?>

            <?php echo e(Form::text('eta_max', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Età massima richiesta...', 'id' => 'eta_max'])); ?>

            <?php if($errors->first('eta_max')): ?>
            <ul class="w3-text-red">
                <?php $__currentLoopData = $errors->get('eta_max'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="w3-quarter">
        <div class="w3-section">
            <?php echo e(Form::label('genere', 'Genere Richiesto')); ?>

            <?php echo e(Form::select('genere', $generi, null, ['class' => 'w3-input w3-border','id' => 'genere'])); ?>

        </div>
    </div>
</div>


<div class="w3-row">
    <div class="w3-half">
        <div class="w3-row-padding">
            <div class="w3-half">
                <div class="w3-section">
                    <?php echo e(Form::label('data_inizio_locazione', 'Data Inizio Locazione')); ?>

                    <?php echo e(Form::date('data_inizio_locazione', null, ['class' => 'w3-input w3-border','id' => 'data_inizio_locazione'])); ?>

                    <?php if($errors->first('data_inizio_locazione')): ?>
                    <ul class="w3-text-red">
                        <?php $__currentLoopData = $errors->get('data_inizio_locazione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($message); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
            <div class="w3-half">
                <div class="w3-section">
                    <?php echo e(Form::label('data_fine_locazione', 'Data Fine Locazione')); ?>

                    <?php echo e(Form::date('data_fine_locazione', null, ['class' => 'w3-input w3-border','id' => 'data_fine_locazione'])); ?>

                    <?php if($errors->first('data_fine_locazione')): ?>
                    <ul class="w3-text-red">
                        <?php $__currentLoopData = $errors->get('data_fine_locazione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($message); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="w3-row">
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        <?php echo e(Form::label('tipologia', 'Tipologia')); ?>

                        <?php echo e(Form::select('tipologia', $tipologie, null, ['class' => 'w3-input w3-border','id' => 'tipologia'])); ?>

                    </div>
                </div>

                <div class="w3-half">
                    <div  class="w3-section">
                        <?php echo e(Form::label('num_letti_tot', 'Numero posti letto totali')); ?>

                        <?php echo e(Form::text('num_letti_tot', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di posti letto totali...', 'id' => 'num_letti_tot'])); ?>

                        <?php if($errors->first('num_letti_tot')): ?>
                        <ul class="w3-text-red">
                            <?php $__currentLoopData = $errors->get('num_letti_tot'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div id="idBloccoAppartamento">

            <div class="w3-row-padding">
                <div class="w3-half">
                    <div  class="w3-section">
                        <?php echo e(Form::label('num_camere', 'Numero camere')); ?>

                        <?php echo e(Form::text('num_camere', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di camere...', 'id' => 'num_camere'])); ?>

                        <?php if($errors->first('num_camere')): ?>
                        <ul class="w3-text-red">
                            <?php $__currentLoopData = $errors->get('num_camere_app'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="w3-half">
                    <br>
                    <div class="w3-section">
                        <?php echo e(Form::label('cucina', 'Cucina')); ?>

                        <?php echo e(Form::checkbox('cucina', 1, null, ['class' => 'w3-check'])); ?>

                        &nbsp;
                        <?php echo e(Form::label('locale_ricreativo', 'Locale ricreativo')); ?>

                        <?php echo e(Form::checkbox('locale_ricreativo', 1, null, ['class' => 'w3-check'])); ?>

                    </div>
                </div>
            </div>
        </div>

        <div id="idBloccoPostoLetto">
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div  class="w3-section">
                        <?php echo e(Form::label('num_letti_camera', 'Numero posti letto della camera')); ?>

                        <?php echo e(Form::text('num_letti_camera', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Posti letto della camera...', 'id' => 'num_letti_camera'])); ?>

                        <?php if($errors->first('num_letti_camera')): ?>
                        <ul class="w3-text-red">
                            <?php $__currentLoopData = $errors->get('num_letti_camera'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="w3-half">
                    <br>
                    <div class="w3-section">
                        <?php echo e(Form::label('angolo_studio', 'Angolo studio')); ?>

                        <?php echo e(Form::checkbox('angolo_studio', 1, null, ['class' => 'w3-check'])); ?>

                        &nbsp;
                        <?php echo e(Form::label('televisione', 'Televisione')); ?>

                        <?php echo e(Form::checkbox('televisione', 1, null, ['class' => 'w3-check'])); ?>

                        &nbsp;
                        <?php echo e(Form::label('lavatrice', 'Lavatrice')); ?>

                        <?php echo e(Form::checkbox('lavatrice', 1, null, ['class' => 'w3-check'])); ?>

                        &nbsp;
                        <?php echo e(Form::label('posto_bici', 'Posto bici')); ?>

                        <?php echo e(Form::checkbox('posto_bici', 1, null, ['class' => 'w3-check'])); ?>

                    </div>
                </div>
            </div>

        </div>

        <div class="w3-row-padding">
            <div class="w3-half">
                <div class="w3-section">
                    <?php echo e(Form::label('internet', 'Internet')); ?>

                    <?php echo e(Form::checkbox('internet', 1, null, ['class' => 'w3-check'])); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="w3-half">
        <div class="w3-half">
            <div class="w3-section">   
                <?php echo e(Form::label('immagine', 'Caricamento immagine: ')); ?><br>
                <?php echo e(Form::file('immagine', ['class' => 'w3-input w3-border', 'id' => 'immagine'])); ?>


                <?php if($errors->first('immagine')): ?>
                <ul class="w3-text-red">
                    <?php $__currentLoopData = $errors->get('immagine'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
        <div class="w3-half">
            <div class="w3-section w3-input">   
                <?php echo $__env->make('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>
</div>




<?php if($errors->any()): ?>
<?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

<?php endif; ?>


<?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/componenti/alloggio_management.blade.php ENDPATH**/ ?>