<br>
<div class="w3-row w3-section">
    <div class="w3-col m3 w3-margin-left " style="width:50px;">
        <i class="w3-xxlarge fa fa-question "></i>
    </div>
    <div class="w3-col m4">
        <?php echo e(Form::text('domanda', null, ['class' => 'w3-input w3-border _error', 'id' => '_domanda', 'placeholder' => 'Domanda', 'autocomplete' => 'off', 'autofocus' ])); ?>

    </div>

    <div class="w3-col m3 w3-margin-left w3-maring-right" style="width:50px">
        <i class="w3-xxlarge fa fa-cubes"></i>
    </div>
    <div class="w3-col m4">
        <?php echo e(Form::select('categoria_id', $cats, null,  ['class' => 'w3-select _categoria'])); ?>

    </div>
</div>

<div class="w3-row w3-section">
    <div class="w3-col m4"></div>
    <div class="w3-col w3-margin-left w3-maring-right" style="width:50px">
        <i class="w3-xxlarge fa fa-reply"></i>
    </div>
    <div class="w3-col m8">
        <?php echo e(Form::textarea('risposta', null, ['class' => 'w3-input w3-border _error', 'id'=>'_risposta', 'placeholder' => 'Risposta', 'resize:none', 'rows' => 7])); ?>

    </div>
</div><?php /**PATH /home/grp_04/www/laraProject/resources/views/componenti/faq_management.blade.php ENDPATH**/ ?>