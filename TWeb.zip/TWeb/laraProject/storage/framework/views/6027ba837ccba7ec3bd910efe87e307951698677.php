<div class="w3-container w3-margin" style="border: 2px solid lightgrey; border-radius: 8px; padding: 5px; background-color: #BDBBBB5E; max-width:2000px">

<h1><?php echo e($chat-> descrizione); ?> </h1>
<h1> Notizie della chat di un alloggio che fu... </h1>

</div><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/componenti/alloggio_che_fu.blade.php ENDPATH**/ ?>