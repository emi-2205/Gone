<div class="w3-row w3-margin">

    <div class="w3-third" style="max-width:400px">
        <?php echo $__env->make('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="w3-twothird">
        <div class="">
            <div class="w3-col">
                <b><h2><?php echo e($alloggio->nome); ?></h2></b>
                <hr style="height:2px;border-width:0;color:gray;background-color:gray">
            </div>
        </div>
        <div class="w3-cell-row">
            <div class="w3-cell w3-margin">
                <h4><i class="fa fa-map-marker"></i>&nbsp<?php echo e($alloggio->indirizzo); ?></h4>
                <h4><i class="fa  fa-bed"></i>&nbsp<?php echo e($alloggio->tipologia); ?></h4>
                <h4><i class="fa fa-calendar"></i>&nbsp<?php echo e($alloggio->data_inizio_locazione); ?> - <?php echo e($alloggio->data_fine_locazione); ?></h4>
            </div>
            <div class="w3-cell-middle" style="text-align: right;">
                <h3>&nbsp</h3>
                <h3>&nbsp<?php echo e($alloggio->canone_affitto); ?>€</h3>
            </div>
        </div>
        <div class="w3-row">
            <div class="">
                <p>
                    <?php echo e($alloggio->descrizione); ?>

                </p>
            </div>
        </div>

    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/componenti/info_alloggio.blade.php ENDPATH**/ ?>