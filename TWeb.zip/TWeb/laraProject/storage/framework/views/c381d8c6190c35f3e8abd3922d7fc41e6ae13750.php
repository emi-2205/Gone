<div class="w3-container">
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-comments"></i>
        Info&nbsp;
        <i class="fa fa-paper-plane"></i>
        Opzione&nbsp;
        <i class="fa fa-check"></i>
        Assegnamento&nbsp;
        <i class="fa fa-times"></i>
        Rifiuto&nbsp;
    </div>
    <table class="w3-table-all w3-hoverable">
        <tr>
            <th></th>
            <th>Nome Alloggio</th>
            <th>Descrizione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php if(isset($chat->alloggio)): ?>
            <td><i class="<?php echo e($chat_status[$chat->id]); ?>"></i></td>
            <td style="width: 20%"><?php echo e($chat->alloggio->nome); ?></td>
            <td><?php echo e($chat->alloggio->descrizione); ?></td>
            <td style="width: 10%" class="w3-right-align"><?php echo e($chat->alloggio->canone_affitto); ?>&euro;</td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('chat-locatario', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            <?php endif; ?>
            <?php if(empty($chat->alloggio)): ?>
            <td><i class="<?php echo e($chat_status[$chat->id]); ?>"></i></td>
            <td style="width: 20%"><?php echo e($chat->descrizione); ?></td>
            <td>N/A</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('chat-locatario', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>

            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/componenti/chat_list_locatario.blade.php ENDPATH**/ ?>