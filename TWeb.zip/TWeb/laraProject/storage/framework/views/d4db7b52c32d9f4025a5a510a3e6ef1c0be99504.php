<?php if($stato == 'Bozza'): ?>
<i class="fa fa-pencil-square-o fa-2x"></i>
<?php elseif($stato == 'Pubblicato'): ?>
<i class="fa fa-cloud-upload fa-2x"></i>
<?php elseif($stato == 'Assegnato'): ?>
<i class="fa fa-check fa-2x"></i>
<?php endif; ?><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/helpers/iconStatoAlloggio.blade.php ENDPATH**/ ?>