
<?php
        // se l'immagine non c'è prendo quella di default
        if (empty($imgFile)) {
            $imgFile = 'default.jpg';
        }
        if (is_null($attrs)) {
            $attrs = '';
        }

?>

<img src="<?php echo e(asset('images/anteprime/' . $imgFile)); ?>" <?php echo $attrs; ?>><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/helpers/alloggioImg.blade.php ENDPATH**/ ?>