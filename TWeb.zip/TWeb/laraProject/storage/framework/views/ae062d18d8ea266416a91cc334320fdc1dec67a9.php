<?php $__env->startSection('title', 'Alloggi del locatore'); ?>
<?php $__env->startSection('heading', 'Inserimento di un nuovo alloggio'); ?>
<?php $__env->startSection('legenda', "Puoi inserire qui un nuovo alloggio da affittare." ); ?>

<?php $__env->startSection('content'); ?>
<div class="w3-card-4">
<?php echo e(Form::model($alloggio, array('route' => array('newalloggio.store'), 'class' => 'w3-container', 'files' => true))); ?>


<?php echo $__env->make('componenti/alloggio_management', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Azioni proprie dell'inserimento di un nuovo alloggio -->
<div class="container-form-btn">   
    <?php echo e(Form::submit('Salva alloggio', ['class' => 'w3-btn w3-yellow', 'name' => 'azione'])); ?>

    <?php echo e(Form::submit('Pubblica alloggio', ['class' => 'w3-btn w3-green', 'name' => 'azione'])); ?>

    <a href="<?php echo e(route('locatore-all-alloggi')); ?>" class="w3-btn w3-blue">Annulla</a>
</div>
<?php echo e(Form::close()); ?>

<br>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/alloggio/insert.blade.php ENDPATH**/ ?>