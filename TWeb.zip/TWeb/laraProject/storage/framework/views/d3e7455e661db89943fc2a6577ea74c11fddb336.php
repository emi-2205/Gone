<?php $__env->startSection('title', 'Avviso'); ?>

<?php $__env->startSection('heading', 'Completa il tuo profilo'); ?>

<?php $__env->startSection('content'); ?>


<div class="w3-card-4">

    <header class="w3-container w3-blue">
        <h1>Non hai inserito la data di nascita</h1>
    </header>

    <div class="w3-container w3-center">
        <img src="<?php echo e(asset('images/alert.png')); ?>" alt="Attenzione">
    </div>

    <footer class="w3-container w3-blue">
        <h5>Vai nella gestione Profilo e completa le informazioni richieste</h5>
    </footer>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/auth/completa_profilo.blade.php ENDPATH**/ ?>