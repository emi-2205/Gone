<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('heading', 'Home'); ?>

<?php $__env->startSection('page_specific_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/carousel.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="w3-container">
    <h2>News: le offerte più recenti</h2>
    <p>
        Il nuovissimo sito <i>MyUniRent</i> permette di avere un facile accesso alle offerte di locazione per studenti fuori sede.
    </p>
    <p>
        Ecco di seguito un'anteprima in tempo reale delle utime offerte di locazione che sono state inserite.<br>
        Per una lista competa di tutte le offerte presenti puoi consultare il catalogo e se sei uno studente,
        dopo che ti sarai registrato, potrai fare ricerche mirate e trovare l'alloggio che fa per te.
    </p>
    <p>Buon Lavoro dal team di <i>MyUniRent</i></p>
</div>
<div class="w3-content w3-display-container" style="width: 50%">

    <?php if(isset($alloggi)): ?>

    <?php $__currentLoopData = $alloggi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alloggio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="w3-display-container mySlides">
        <?php echo $__env->make('helpers/alloggioImg', ['attrs' => 'style="width:100%"', 'imgFile' => $alloggio->immagine], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black ellipsis">
            <?php echo e($alloggio->nome); ?>

        </div>


    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <button class="w3-button w3-display-left w3-black" onclick="plusDivs(-1)">&#10094;</button>
    <button class="w3-button w3-display-right w3-black" onclick="plusDivs(1)">&#10095;</button>

</div>

<br><br>
<div class="w3-row-padding">
    <div class="w3-col s3 w3-center">
        <h3>Cerca</h3><br>
        <i class="fa fa-search w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Cerca l'alloggio che fa per te</p>
    </div>
    <div class="w3-col s3 w3-center">
        <h3>Scrivi</h3><br>
        <i class="fa fa-paper-plane w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Opziona e/o contatta il locatore</p>
    </div>

    <div class="w3-col s3 w3-center vl">

        <h3>Pubblica</h3><br>
        <i class="fa fa-home w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Pubblica il tuo alloggio</p>
    </div>
    <div class="w3-col s3 w3-center">
        <h3>Assegna</h3><br>
        <i class="fa fa-handshake-o w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Ricevi opzioni e assegna</p>
    </div>
</div>

<div class="w3-container w3-padding-32">
    <div class="w3-panel w3-card">
        <div class="w3-container">
            <h2 class="w3-center">La nostra missione</h2>
            <p>
             Il progetto MyUniRent è stato pensato per agevolare il difficile rapporto che a volte si instaura tra chi ha la necessità di affittare un alloggio e lo studente fuori sede che cerca un posto dove vivere e studiare vicino alla sua Università.   
            </p>
            <p>
             L’idea di fondo che ha animato l’intera fase di definizione delle caratteristiche del software è stata quella di creare dei meccanismi e degli automatismi che rendessero chiare e ben definite le interazioni tra le parti, cercando di lasciare il meno possibile al caso. 
            </p>
            <p>
             Se sei uno studente è sufficiente registrarti, autenticarti ed immediatamente puoi iniziare a cercare l’alloggio che fa per te. MyUniRent ti offre uno strumento di ricerca semplice ed efficace che, oltre a trovare gli alloggi con tutte le caratteristiche richieste, ti mostrerà anche quelli che soddisfano solo parte delle tue esigenze. Magari troverai proprio fra questi la soluzione a cui non avevi pensato. Per contattare il proprietario hai a disposizione un sistema di messaggistica dedicato che ti permette anche di opzionare l’alloggio desiderato.   
            </p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/laraProject/resources/views/home.blade.php ENDPATH**/ ?>