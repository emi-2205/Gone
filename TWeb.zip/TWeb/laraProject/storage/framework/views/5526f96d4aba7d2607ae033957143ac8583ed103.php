<?php $__env->startSection('title', 'Chat Locatario'); ?>
<?php $__env->startSection('heading', 'Le tue Opzioni'); ?>
<?php $__env->startSection('legenda', 'Puoi trovare qui tutte le tue opzioni con il loro esito finale.' ); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('componenti/chat_list_locatario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/locatario/opzioni_list.blade.php ENDPATH**/ ?>