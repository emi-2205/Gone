<!-- Footer -->
<br>
<footer class="w3-container w3-padding-32">  


    <div class="w3-panel w3-card">

        <div class="w3-container">
            <h2 class="w3-center">Dicono di noi</h2>
            <p>Il nostro portale di affitti si rivolge principalmente a studenti o giovani lavoratori e contiene annunci di privati, affittacamere o agenzie immobiliari. Inserire un annuncio su MyUniRent è facile e gratuito, prova subito il nostro portale e, se ti va, facci sapere cosa ne pensi!</p>
            <p>MyUniRent è il punto di riferimento per chi cerca o affitta un posto letto, una stanza o un intero appartamento. </p>
            <div class="w3-cell-row">
                <div class="w3-container w3-cell" style="width: 50%">
                    <p class="w3-center">Trova l'alloggio più adatto a te</p>
                </div>
                <div class="w3-container w3-cell" style="width: 50%">
                    <p class="w3-center">Opzionalo e chiedi maggiori informazioni al locatore</p>
                </div>
            </div>
            <div class="w3-cell-row">
                <div class="w3-container w3-cell" style="width: 50%">
                    <p class="w3-center">Pubblica i tuoi alloggi</p>
                </div>
                <div class="w3-container w3-cell" style="width: 50%">
                    <p class="w3-center">Ricevi opzioni da parte dei potenziali locatari e assegna</p>
                </div>
            </div>

        </div>

    </div>

    <div class="w3-panel w3-card w3-light-blue">
        <div class="w3-row-padding">
            <div class="w3-quarter">
                <h3>MyUniRent</h3>
                <p>Progetto Universitario per il corso di Tecnologie Web</p>
                <p class="w3-tiny">ver: 1.0<p>
                <a class="w3-orange" href="<?php echo e(asset('images/relazione_gruppo04.pdf')); ?>" target="_blank" title="Scarica la documentazione di progetto">Documentazione di Progetto</a>

            </div>
            <div class="w3-quarter">
                <h3>Contatti</h3>
                <p><i class="fa fa-map-marker"></i> 123 Street, New York, USA</p>
                <p><i class="fa fa-phone"></i> +012 345 67890</p>
                <p><i class="fa fa-envelope"></i> info@example.com</p>
            </div>
            <div class="w3-quarter">
                <h3>Sviluppatori</h3>
                <p>Davide De Zuane</p>
                <p>Daniele Benfatto</p>
                <p>Emilio Joseph Grieco</p>
                <p>Matteo Lorenzo Bramucci</p>
            </div>
            <div class="w3-quarter">
                <h3>Dove Trovarci</h3>
                
                
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11553.91738917538!2d13.5139647!3d43.6173812!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x8d13413c91561246!2sRettorato%20Universit%C3%A0%20Politecnica%20delle%20Marche!5e0!3m2!1sit!2sit!4v1652105480905!5m2!1sit!2sit"
                        width="180" height="180" class="w3-circle" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

            </div>
        </div>
    </div>

</footer><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/layouts/_footer.blade.php ENDPATH**/ ?>