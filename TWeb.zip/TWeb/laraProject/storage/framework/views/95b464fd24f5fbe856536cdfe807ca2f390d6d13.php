<div class="w3-container w3-margin" style="border: 2px solid lightgrey; border-radius: 8px; padding: 5px; background-color: #BDBBBB5E; max-width:2000px">
    <div class="w3-row w3-margin">

        <div class="w3-col">
            <i class="fa fa-user fa-3x w3-left"></i>
            <b><h3>&nbsp;<?php echo e($locatario->name); ?> <?php echo e($locatario->surname); ?></h3></b>
            <hr style="height:2px;border-width:0;color:gray;background-color:gray">
        </div>
        <div class="w3-cell w3-margin">
            <h4><i class="fa fa-envelope"></i>&nbsp<?php echo e($locatario->email); ?></h4>
            <h4><i class="fa  fa-phone"></i>&nbsp<?php echo e($locatario->telefono); ?></h4>
        </div>
    </div>
</div><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/componenti/info_locatario.blade.php ENDPATH**/ ?>