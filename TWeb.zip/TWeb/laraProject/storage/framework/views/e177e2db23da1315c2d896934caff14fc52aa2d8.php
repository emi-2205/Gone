<?php $__env->startSection('title', 'Faq'); ?>

<?php if($edit): ?>
<?php $__env->startSection('heading', 'Gestione delle Frequently Asked Questions'); ?>
<?php else: ?>
<?php $__env->startSection('heading', 'Frequently Asked Questions'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>


<div class="w3-row">
    <div class="w3-quarter w3-container">
        <div class="w3-block w3-container w3-blue w3-card-4">
            <h2 class="faq-ellipsis">Argomenti</h2>
        </div>
        <?php if($edit): ?>
        <?php ($rotta = 'faq-list-admin'); ?>
        <?php else: ?>
        <?php ($rotta = 'faq-list'); ?>
        <?php endif; ?>
        <?php $__currentLoopData = $categorie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($categoria->id == $categoria_id): ?>
        <a class="w3-btn w3-border w3-light-blue w3-block faq-ellipsis" href="<?php echo e(route($rotta, [$categoria->id])); ?>"><?php echo e($categoria->nome); ?></a>
        <?php else: ?>
        <a class="w3-btn w3-border w3-block faq-ellipsis" href="<?php echo e(route($rotta, [$categoria->id])); ?>"><?php echo e($categoria->nome); ?></a>
        <?php endif; ?>        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($edit): ?>
        <br>
        <a class="w3-btn w3-border w3-orange w3-block" href="<?php echo e(route('newfaq')); ?>">Nuova Faq</a>
        <?php endif; ?>

    </div>

    <!-- fine sezione laterale -->
    <div class="w3-threequarter w3-container">
        <?php if(isset($faqs)): ?>
        <div class="w3-cell w3-bar-block" style="margin-left: 20%;">
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="w3-block w3-container w3-blue w3-card-4">
                <div class="w3-row">
                    <div class="w3-threequarter">
                        <h2><?php echo e($faq->domanda); ?></h2>
                    </div>
                    <div class="w3-quarter">
                        <?php if($edit): ?>
                        <a href="<?php echo e(route('editfaq', [$faq->id])); ?>">
                            <button class="w3-input w3-border w3-margin-bottom w3-round-large w3-teal"  style='cursor:pointer;'>
                                <i class="fa fa-pencil-square-o"></i>
                            </button>
                        </a>
                        <a href="<?php echo e(route('deletefaq', [$faq->id])); ?>" onclick="return confirm('Sei sicuro di voler cancellare questa Faq?');">
                            <button class="w3-input w3-border w3-margin-bottom w3-round-large w3-red" style='cursor:pointer;' >
                                <i class="fa fa-trash-o"></i>
                            </button>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="w3-container w3-card-4">
                <p><?php echo $faq->risposta; ?></p>
            </div>
            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!--Paginazione-->
        <?php echo $__env->make('pagination.paginator', ['paginator' => $faqs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/laraProject/resources/views/faq.blade.php ENDPATH**/ ?>