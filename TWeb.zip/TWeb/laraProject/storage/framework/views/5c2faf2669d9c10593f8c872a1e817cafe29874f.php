<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('heading', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">
      <div class="w3-center"><br>
        
        <img src="<?php echo e(asset('images/img_avatar.png')); ?>" alt="Avatar" style="width:30%" class="w3-circle w3-margin-top">
      </div>


    <?php echo e(Form::open(array('route' => 'login', 'class' => 'w3-container'))); ?>

    <h3>Login</h3>
    <p>Utilizza questa form per autenticarti al sito</p>

    <div  class="w3-section">
        <?php echo e(Form::label('username', 'Nome Utente', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('username', '', ['class' => 'w3-input w3-border w3-margin-bottom',
                    'placeholder' => 'Inserire il Nome Utente',
                    'id' => 'username',
                    'autofocus'])); ?>

        <?php if($errors->first('username')): ?>
        <ul class="w3-red">
            <?php $__currentLoopData = $errors->get('username'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="wrap-input">
        <?php echo e(Form::label('password', 'Password', ['class' => 'label-input'])); ?>

        <?php echo e(Form::password('password', ['class' => 'w3-input w3-border', 'placeholder' => 'Inserire la Password', 'id' => 'password'])); ?>

        <?php if($errors->first('password')): ?>
        <ul class="w3-red">
            <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div class="container-form-btn">                
        <?php echo e(Form::submit('Login', ['class' => 'w3-button w3-block w3-green w3-section w3-padding'])); ?>

    </div>
    <div  class="wrap-input">
        <p> Se non hai già un account <a  href="<?php echo e(route('register')); ?>">registrati</a></p>
    </div> 

    <?php echo e(Form::close()); ?>



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/auth/login.blade.php ENDPATH**/ ?>