<?php $__env->startSection('title', 'Chat Locatore'); ?>
<?php $__env->startSection('heading', 'Chat del Locatore'); ?>
<?php $__env->startSection('legenda', "Ti permette di gestire le comunicazioni con il locatario ed eventualmente assegnare l'alloggio." ); ?>

<?php $__env->startSection('content'); ?>





<div class="w3-row">
    <div class="w3-col m8 l9">
        <?php if(isset($alloggio)): ?>
        <?php echo $__env->make('componenti/alloggio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(empty($alloggio)): ?>
        <?php echo $__env->make('componenti/alloggio_che_fu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
    <div class="w3-col m4 l3">
        <?php if(isset($locatore)): ?>
        <?php echo $__env->make('componenti/info_locatario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(isset($locatario)): ?>
        <!-- FORM PER NUOVO MESSAGGIO con funzionamento basato su campi hidden -->
        <?php echo e(Form::open(array('route' => 'send.message', 'id' => 'messaggio',
                    'class' => '3-container w3-margin w3-container info-card'))); ?>

        <?php echo $__env->make('helpers/error_display', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h5 class="w3-center">Scrivi al Locatario</h5>



        <?php echo e(Form::textarea('testo', '', [
                    'id' => 'msg',
                    'placeholder' => 'Nuovo messaggio',
                    'class' => 'w3-input w3-border',
                    'style' => 'resize:none',
                    'rows' => '4',
                    'autofocus'
        ])); ?>


        <?php echo e(Form::hidden('chat_id', $chat->id)); ?>

        <?php echo e(Form::hidden('locatario_id', $locatario->id)); ?>

        <?php echo e(Form::hidden('tipo', 'Info_loc_stu')); ?>



        <p class="w3-center">
            <?php echo e(Form::submit('Invia', ['class' => 'w3-btn w3-blue'])); ?>

        </p>


            <?php echo e(Form::close()); ?>

            <?php endif; ?>
    </div>
</div>



<?php if(isset($messaggi)): ?>

<div class="w3-content w3-border">
    <?php echo $__env->make('componenti/chatMessageCounter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__currentLoopData = $messaggi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messaggio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($messaggio->tipo == 'Info_stu_loc'): ?>
    <div class="w3-row w3-margin">
        <!-- layout mittente locatario -->
        <div class="msg-container w3-twothird msg-darker">
            <i class="fa fa-user fa-2x w3-left"></i>
            <p>&nbsp;<?php echo e($messaggio->testo); ?></p>
            <span class="msg-time-left"><?php echo e(date('d/m/Y H:i', strtotime($messaggio->data_ora_invio))); ?></span>
        </div>
        <div class="w3-third"><span>&nbsp;</span></div>
    </div>
    <?php elseif($messaggio->tipo == 'Opzione'): ?>
    <div class="w3-row w3-margin">
        <!-- layout mittente locatario -->
        <div class="msg-container w3-twothird w3-aqua">
            <i class="fa fa-paper-plane-o fa-2x w3-left"></i>
            <p>&nbsp;<?php echo e($messaggio->testo); ?></p>
            <span class="msg-time-left"><?php echo e(date('d/m/Y H:i', strtotime($messaggio->data_ora_invio))); ?></span>
        </div>
        <div class="w3-third"><span>&nbsp;</span></div>
    </div>
    <?php elseif($messaggio->tipo == 'Info_loc_stu'): ?>
    <div class="w3-row w3-margin">
        <!-- layout mittente locatore -->
        <div class="w3-third"><span>&nbsp;</span></div>
        <div class="msg-container w3-twothird">
            <i class="fa fa-user-o fa-2x w3-right"></i>
            <p><?php echo e($messaggio->testo); ?></p>
            <span class="msg-time-right"><?php echo e(date('d/m/Y H:i', strtotime($messaggio->data_ora_invio))); ?></span>
        </div>
    </div>
    <?php elseif($messaggio->tipo == 'Assegnamento'): ?>
    <div class="w3-row w3-margin">
        <!-- layout mittente locatore -->
        <div class="w3-third"><span>&nbsp;</span></div>
        <div class="msg-container w3-twothird w3-green">
            <i class="fa fa-check fa-2x w3-right"></i>
            <p><?php echo e($messaggio->testo); ?></p>
            <span class="msg-time-right w3-text-white"><?php echo e(date('d/m/Y H:i', strtotime($messaggio->data_ora_invio))); ?></span>
        </div>
    </div>
    <?php elseif($messaggio->tipo == 'Rifiuto'): ?>
    <div class="w3-row w3-margin">
        <!-- layout mittente locatore -->
        <div class="w3-third"><span>&nbsp;</span></div>
        <div class="msg-container w3-twothird w3-red">
            <i class="fa fa-times fa-2x w3-right"></i>
            <p><?php echo e($messaggio->testo); ?></p>
            <span class="msg-time-right w3-text-white"><?php echo e(date('d/m/Y H:i', strtotime($messaggio->data_ora_invio))); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('pagination.paginator', ['paginator' => $messaggi], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php endif; ?>
<?php if(empty($chat)): ?>
<h1> Ma di cosa stiamo parlando? </h1>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/laraProject/resources/views/locatore/chat.blade.php ENDPATH**/ ?>