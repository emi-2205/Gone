<div class="w3-container w3-margin" style="border: 2px solid lightgrey; border-radius: 8px; padding: 5px; background-color: #BDBBBB5E; max-width:2000px">
    <div class="w3-row w3-margin">

        <div class="w3-col">
            <i class="fa fa-user-o fa-3x w3-left"></i>
            <b><h3>&nbsp;<?php echo e($locatore->name); ?> <?php echo e($locatore->surname); ?></h3></b>
            <hr style="height:2px;border-width:0;color:gray;background-color:gray">
        </div>
        <div class="w3-cell w3-margin">
            <h4><i class="fa fa-envelope"></i>&nbsp<?php echo e($locatore->email); ?></h4>
            <h4><i class="fa  fa-phone"></i>&nbsp<?php echo e($locatore->telefono); ?></h4>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/componenti/info_locatore.blade.php ENDPATH**/ ?>