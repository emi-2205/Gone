
<?php echo e(Form::open(array('route' => 'test2', 'class' => 'w3-container'))); ?>


<?php echo e(Form::text('value', null, ['class' => 'w3-input w3-border'])); ?>

<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($message); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <?php echo e(Form::label('data_nascita', 'Data di Nascita', ['class' => ''])); ?>



<?php echo e(Form::submit('Salva', ['class' => 'w3-btn w3-block w3-blue '])); ?>

<?php echo e(Form::close()); ?> 

</form><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/test.blade.php ENDPATH**/ ?>