<?php $__env->startSection('page_specific_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/alloggio.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('helpers/error_display', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(Auth::user()->genere == 'Non assegnato'): ?>
<p class="w3-orange w3-center">Attenzione: Non hai inserito il genere nella tua scheda profilo. Verranno mostrati solo quegli alloggi per cui il Locatore non ha richiesto tale tipo di informazione.</p>
<?php endif; ?>

<div class="w3-card-4">

    <?php echo e(Form::open(['route' => ['locatario-find'], 'method' => 'get', 'class' => 'w3-container'])); ?>


    <div class="w3-row-padding">
        <div class="w3-quarter">
            <?php echo e(Form::label('citta', 'Città')); ?>

            <?php echo e(Form::text('citta', request()->input('citta'), ['class' => 'w3-input w3-border', 'placeholder' => 'Città...', 'id' => 'citta', 'autofocus'])); ?>

        </div>
        <div class="w3-quarter">
            <div class="w3-half">
                <?php echo e(Form::label('prezzo_min', 'Fascia di prezzo')); ?>

                <?php echo e(Form::text('prezzo_min', request()->input('prezzo_min'), ['class' => 'w3-input w3-border', 'placeholder' => 'Prezzo min...', 'id' => 'prezzo_min'])); ?>

            </div>

            <div class="w3-half">
                <?php echo e(Form::label('prezzo_max', '&nbsp;')); ?>

                <?php echo e(Form::text('prezzo_max', request()->input('prezzo_max'), ['class' => 'w3-input w3-border', 'placeholder' => 'Prezzo max...', 'id' => 'prezzo_max'])); ?>

            </div>
        </div>
        <div class="w3-quarter">
            <div class="w3-half">
                <?php echo e(Form::label('data_inizio_locazione', 'Periodo di locazione')); ?>

                <?php echo e(Form::date('data_inizio_locazione', request()->input('data_inizio_locazione'), ['class' => 'w3-input w3-border', 'id' => 'data_inizio_locazione'])); ?>

            </div>

            <div class="w3-half">
                <?php echo e(Form::label('data_fine_locazione', '&nbsp;')); ?>

                <?php echo e(Form::date('data_fine_locazione', request()->input('data_fine_locazione'), ['class' => 'w3-input w3-border', 'id' => 'data_fine_locazione'])); ?>

            </div>
        </div>
        <div class="w3-quarter">
            <?php echo e(Form::label('tipologia', 'Tipologia')); ?>

            <?php echo e(Form::select('tipologia', $tipologie, request()->input('tipologia'), ['class' => 'w3-input w3-border', 'id' => 'tipologia'])); ?>

        </div>
    </div>
    <br>

    <div class="w3-row-padding">
        <div class="w3-quarter">
            <?php echo e(Form::label('num_letti_tot', 'Numero posti letto totali')); ?>

            <?php echo e(Form::text('num_letti_tot', request()->input('num_letti_tot'), ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di posti letto totali...', 'id' => 'num_letti_tot_app'])); ?>

        </div>
    </div>
    <br>
    <div id="idBloccoAppartamento">
        <div class="w3-row-padding">
            <div class="w3-quarter">
                <?php echo e(Form::label('num_camere', 'Numero camere')); ?>

                <?php echo e(Form::text('num_camere', request()->input('num_camere'), ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di camere...', 'id' => 'num_camere_app'])); ?>

            </div>

            <div class="w3-half">
                <br>
                <div class="w3-rest">
                    <?php echo e(Form::label('cucina', 'Cucina')); ?>

                    <?php echo e(Form::checkbox('cucina', 1, request()->input('cucina'), ['class' => 'w3-check'])); ?>


                    <?php echo e(Form::label('locale_ricreativo', 'Locale ricreativo')); ?>

                    <?php echo e(Form::checkbox('locale_ricreativo', 1, request()->input('locale_ricreativo'), ['class' => 'w3-check'])); ?>


                </div>
            </div>

        </div>
    </div>


    <div id="idBloccoPostoLetto">
        <div class="w3-row-padding">
            <div class="w3-quarter">
                <?php echo e(Form::label('num_letti_camera', 'Numero posti letto della camera')); ?>

                <?php echo e(Form::text('num_letti_camera', request()->input('num_letti_camera'), ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di posti letto della camera...', 'id' => 'num_letti_camera'])); ?>

            </div>
            <div class="w3-half">
                <br>
                <div class="w3-rest">
                    <?php echo e(Form::label('angolo_studio', 'Angolo studio')); ?>

                    <?php echo e(Form::checkbox('angolo_studio', 1, request()->input('angolo_studio'), ['class' => 'w3-check'])); ?>


                    <?php echo e(Form::label('televisione', 'Televisione')); ?>

                    <?php echo e(Form::checkbox('televisione', 1, request()->input('televisione'), ['class' => 'w3-check'])); ?>


                    <?php echo e(Form::label('lavatrice', 'Lavatrice')); ?>

                    <?php echo e(Form::checkbox('lavatrice', 1, request()->input('lavatrice'), ['class' => 'w3-check'])); ?>


                    <?php echo e(Form::label('posto_bici', 'Posto bici')); ?>

                    <?php echo e(Form::checkbox('posto_bici', 1, request()->input('posto_bici'), ['class' => 'w3-check'])); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="w3-row-padding">
        <div class="w3-quarter">
            <?php echo e(Form::label('internet', 'Internet')); ?>

            <?php echo e(Form::checkbox('internet', 1, request()->input('internet'), ['class' => 'w3-check'])); ?>

        </div>
        
        <div class="w3-threequarter" align="right">
            <?php echo e(Form::label('smart', 'Smart Search', ['class' => 'w3-text-red'])); ?>

            <?php echo e(Form::checkbox('smart', 1, request()->input('smart'), ['class' => 'w3-check'])); ?>

        </div>
    </div>

    <div class="container-form-btn">
        <?php echo e(Form::submit('Cerca', ['class' => 'w3-button w3-block w3-green w3-section w3-padding'])); ?>

    </div>


    <?php echo e(Form::close()); ?>

</div>

<br>


<?php /**PATH /home/grp_04/www/laraProject/resources/views/componenti/alloggi_filter_locatario.blade.php ENDPATH**/ ?>