<a href="<?php echo e(route('locatario-search')); ?>" title="Cerca un Alloggio" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Cerca un Alloggio</a>
<a href="<?php echo e(route('lista-opzioni-locatario')); ?>" title="Gestisci le tue opzioni" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Le tue Opzioni</a>
<a href="<?php echo e(route('lista-chat-locatario')); ?>" title="Parla con i locatori" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Le tue Chat</a>
<a href="<?php echo e(route('profilo')); ?>" title="Vai al tuo Profilo" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Profilo</a>
<?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/layouts/_sidebar_locatario.blade.php ENDPATH**/ ?>