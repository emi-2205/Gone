<?php $__env->startSection('title', 'Alloggi del locatore'); ?>
<?php $__env->startSection('heading', 'Gestione alloggi'); ?>
<?php $__env->startSection('legenda', "Puoi gestire qui gli alloggi che vuoi affittare." ); ?>

<?php $__env->startSection('content'); ?>

            <?php echo $__env->make('componenti/alloggi_list_locatore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--Paginazione-->
            <br>
            <?php echo $__env->make('pagination.paginator', ['paginator' => $alloggi], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            <div class="w3-center">
            <a href="<?php echo e(route('newalloggio')); ?>" class="w3-btn w3-blue">Inserisci un nuovo allogio</a>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/locatore/alloggi_list.blade.php ENDPATH**/ ?>