<?php $__env->startSection('title', 'Alloggi del locatore'); ?>
<?php if($alloggio->stato == 'Bozza'): ?>
<?php $__env->startSection('heading', 'Modifica di un alloggio in stato di bozza'); ?>
<?php else: ?>
<?php $__env->startSection('heading', 'Modifica di un alloggio'); ?>
<?php endif; ?>
<?php $__env->startSection('legenda', "Puoi modificare i dati del tuo alloggio." ); ?>

<?php $__env->startSection('content'); ?>
<div class="w3-card-4">
    <?php echo e(Form::model($alloggio, array('route' => array('alloggio.update', $alloggio->id), 'class' => 'w3-container', 'files' => true))); ?>


    <?php echo $__env->make('componenti/alloggio_management', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Azioni proprie dell'inserimento di un nuovo alloggio -->
    <div class="container-form-btn"> 
        <?php echo e(Form::submit('Salva alloggio', ['class' => 'w3-btn w3-yellow', 'name' => 'azione'])); ?>

        <?php if($alloggio->stato == 'Bozza'): ?>
        <?php echo e(Form::submit('Pubblica alloggio', ['class' => 'w3-btn w3-green', 'name' => 'azione'])); ?>

        <?php endif; ?>
        <a href="<?php echo e(route('locatore-all-alloggi')); ?>" class="w3-btn w3-blue">Annulla</a>
        &nbsp;&nbsp;
        <a class="w3-btn w3-red" href="<?php echo e(route('alloggio.elimina', [$alloggio->id])); ?>" onclick="return confirm('Vuoi veramente cancellare questo alloggio?');">
        Cancella questo alloggio
        </a>
    </div>
    <?php echo e(Form::close()); ?>

    <br>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/alloggio/modify.blade.php ENDPATH**/ ?>