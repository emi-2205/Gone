
<div class="w3-container">
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-pencil-square-o"></i>
        Bozza&nbsp;
        <i class="fa fa-cloud-upload"></i>
        Pubblicato&nbsp;
        <i class="fa fa-check"></i>
        Assegnato
    </div>
    <table class="w3-table-all w3-hoverable big-screen">
        <tr>
            <th></th>
            <th></th>
            <th>Nome Alloggio</th>
            <th>Descrizione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th></th>
        </tr>
        <tbody id="myTable">
            <?php if(isset($alloggi)): ?>
            <?php $__currentLoopData = $alloggi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alloggio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $__env->make('helpers/iconStatoAlloggio', ['stato' => $alloggio->stato], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                <td style="max-width: 300px"><?php echo $__env->make('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                <td class="break-word nome" style="width: 20%"><?php echo e($alloggio->nome); ?><br><?php echo $__env->make('componenti/alloggioServizi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                <td class="break-word" style="width: 40%"><?php echo e($alloggio->descrizione); ?></td>
                <td class="w3-right-align"><?php echo e($alloggio->canone_affitto); ?>&euro;</td>
                <td class="w3-right-align"><a href="<?php echo e(route('alloggio', [$alloggio->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>

    <table class="w3-table-all w3-hoverable small-screen">
        <tr>
            <th></th>
            <th>Nome Alloggio</th>
            <th class="w3-right-align">Canone</th>
            <th></th>
        </tr>
        <tbody id="myTable">
            <?php if(isset($alloggi)): ?>
            <?php $__currentLoopData = $alloggi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alloggio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $__env->make('helpers/iconStatoAlloggio', ['stato' => $alloggio->stato], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                <td class="break-word nome" style="width: 40%"><?php echo e($alloggio->nome); ?><br><?php echo $__env->make('componenti/alloggioServizi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                <td class="w3-right-align"><?php echo e($alloggio->canone_affitto); ?>&euro;</td>
                <td class="w3-right-align"><a href="<?php echo e(route('alloggio', [$alloggio->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>

</div><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/componenti/alloggi_list_locatore.blade.php ENDPATH**/ ?>