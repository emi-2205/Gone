<?php if($paginator->lastPage() != 1): ?>
<div class="w3-center">
    <div class="w3-bar w3-border">
        <a href="<?php echo e($paginator->url(1)); ?>" class="w3-bar-item w3-button">&laquo;</a>
        <?php for($i=1;$i<=$paginator->lastPage();$i++): ?>
        <?php if($paginator->currentPage() == $i): ?>
        <a href="#" class="w3-bar-item w3-button w3-blue"><?php echo e($i); ?></a>
        <?php endif; ?>
        <?php if($paginator->currentPage() != $i): ?>
        <a href="<?php echo e($paginator->url($i)); ?>" class="w3-bar-item w3-button"><?php echo e($i); ?></a>
        <?php endif; ?>
        <?php endfor; ?>
        <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>" class="w3-bar-item w3-button">&raquo;</a>
    </div>
</div>
<?php endif; ?>
<div class="w3-center">
    <p><?php echo e($paginator->total()); ?> elementi trovati</p>
</div>
<?php /**PATH /home/grp_04/www/laraProject/resources/views/pagination/paginator.blade.php ENDPATH**/ ?>