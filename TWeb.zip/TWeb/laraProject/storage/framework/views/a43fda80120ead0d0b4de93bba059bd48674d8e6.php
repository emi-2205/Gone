
<?php if($alloggio->internet): ?>
<i class="fa fa-wifi" title="Internet"></i>&nbsp;
<?php endif; ?>

<?php if($alloggio->cucina): ?>
<i class="fa fa-fire" title="Uso cucina"></i>&nbsp;
<?php endif; ?>

<?php if($alloggio->locale_ricreativo): ?>
<i class="fa fa-gamepad" title="Locale ricreativo"></i>&nbsp;
<?php endif; ?>

<?php if($alloggio->angolo_studio): ?>
<i class="fa fa-pencil-square-o" title="Angolo Studio"></i>&nbsp;
<?php endif; ?>

<?php if($alloggio->televisione): ?>
<i class="fa fa-television" title="Televisione"></i>&nbsp;
<?php endif; ?>

<?php if($alloggio->lavatrice): ?>
<i class="fa fa-recycle" title="Lavatrice"></i>&nbsp;
<?php endif; ?>

<?php if($alloggio->posto_bici): ?>
<i class="fa fa-bicycle" title="Posto bici"></i>
<?php endif; ?><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/componenti/alloggioServizi.blade.php ENDPATH**/ ?>