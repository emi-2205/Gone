<h1>Questo è il contratto</h1>
<h2><?php echo e($alloggio->nome); ?></h2>
<h2><?php echo e($locatore->name); ?> <?php echo e($locatore->surname); ?></h2>
<h2><?php echo e($locatario->name); ?> <?php echo e($locatario->surname); ?></h2><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/alloggio/contratto.blade.php ENDPATH**/ ?>