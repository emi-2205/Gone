<?php $__env->startSection('title', 'Alloggi del locatore'); ?>
<?php $__env->startSection('heading', 'Modifica alloggio'); ?>
<?php $__env->startSection('legenda', "Puoi getire qui gli alloggi che vuoi affittare." ); ?>

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('componenti/alloggio_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/locatore/alloggio_edit.blade.php ENDPATH**/ ?>