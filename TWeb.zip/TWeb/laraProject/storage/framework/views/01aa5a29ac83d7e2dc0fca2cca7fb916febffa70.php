<div class="w3-container w3-light-blue">
    <div class="w3-row">
        <?php if($num_messaggi == 0): ?>
        <h4>Non hai messaggi per questo alloggio</h4>
        <?php elseif($num_messaggi == 1): ?>
        <h4>Hai un messaggio per questo alloggio</h4>
        <?php else: ?>
        <h4>Hai <?php echo e($num_messaggi); ?> messaggi per questo alloggio</h4>
        <?php endif; ?>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/componenti/chatMessageCounter.blade.php ENDPATH**/ ?>