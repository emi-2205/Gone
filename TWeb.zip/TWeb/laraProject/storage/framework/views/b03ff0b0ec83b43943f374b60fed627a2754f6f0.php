<?php $__env->startSection('title', 'Chat Locatore'); ?>
<?php $__env->startSection('heading', 'Chat Attive' ); ?>
<?php $__env->startSection('legenda', 'Puoi trovare qui tutte le chat associate ad alloggi per cui hai ricevuto contatti e/o opzioni.' ); ?>

<?php $__env->startSection('content'); ?>



<?php echo $__env->make('componenti/chat_list_locatore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/laraProject/resources/views/locatore/chat_list_all.blade.php ENDPATH**/ ?>