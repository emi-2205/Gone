<?php $__env->startSection('title', 'Alloggi del locatore'); ?>
<?php $__env->startSection('heading', 'Gestione alloggi'); ?>
<?php $__env->startSection('legenda', "Puoi gestire qui gli alloggi che vuoi affittare." ); ?>

<?php $__env->startSection('page_specific_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/inpagesearch.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="w3-container">
    <div class="w3-row">
        <div class="w3-quarter">
            <div class="w3-row"> 
                <div class="w3-threequarter">
                    <input id="myInput" class="w3-input w3-border" type="text" placeholder="Cerca in questa pagina..." autofocus>
                </div>
                <div class="w3-quarter">
                    <button id="pulisci" class="w3-button w3-blue">X</button>
                </div>
            </div>
        </div>
        <div class="w3-half">
            <?php echo $__env->make('pagination.paginator', ['paginator' => $alloggi], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="w3-quarter" align="center">
            <a href="<?php echo e(route('newalloggio')); ?>" class="w3-btn w3-blue">Nuovo alloggio</a>
        </div>
    </div>
</div>
<?php echo $__env->make('componenti/alloggi_list_locatore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/laraProject/resources/views/locatore/alloggi_list.blade.php ENDPATH**/ ?>