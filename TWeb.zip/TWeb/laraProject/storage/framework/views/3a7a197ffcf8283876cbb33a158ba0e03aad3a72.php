<?php $__env->startSection('title', 'Gestione Faq'); ?>
<?php $__env->startSection('heading', 'Inserimento di una nuova Faq'); ?>
<?php $__env->startSection('legenda', "Puoi inserire qui una nuova Faq." ); ?>

<?php $__env->startSection('content'); ?>
<div class="w3-card-4">

    <?php echo e(Form::model($faq, array('route' => 'newfaq.store'), ['class' => 'w3-container w3-card-4 w3-light-grey w3-text-blue w3-margin'])); ?>


    <?php echo $__env->make('componenti/faq_management', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <footer class="w3-container">
        <div class="w3-row w3-section">
            <div class="w3-col m5"></div>
            <div class="w3-col m2">
                <?php echo e(Form::submit('Aggiungi Faq', ['class' => 'w3-button w3-block w3-green', 'style' => 'cursor:pointer;'])); ?>

            </div>
            <div class="w3-col m5"></div>
        </div>
    </footer>
    <?php echo e(Form::close()); ?>


</div>









<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/faq/insert.blade.php ENDPATH**/ ?>