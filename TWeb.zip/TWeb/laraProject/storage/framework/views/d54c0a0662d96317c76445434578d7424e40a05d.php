<a href="<?php echo e(route('locatore-all-alloggi')); ?>" title="Gestisci i tuoi alloggi" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">I tuoi Alloggi</a>
<a href="<?php echo e(route('locatore-all-chat')); ?>" title="Parla con i locatari" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Chat Attive</a>
<a href="<?php echo e(route('locatore-archivio-chat')); ?>" title="Consulta l'archivio delle Chat" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Chat Archiviate</a>
<a href="<?php echo e(route('profilo')); ?>" title="Vai al tuo Profilo" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Profilo</a>
<?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/layouts/_sidebar_locatore.blade.php ENDPATH**/ ?>