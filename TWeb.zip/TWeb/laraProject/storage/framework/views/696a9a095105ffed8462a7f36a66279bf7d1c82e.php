<?php $__env->startSection('title', 'Registrazione'); ?>

<?php $__env->startSection('heading', 'Registrazione Nuovo Utente'); ?>

<?php $__env->startSection('content'); ?>
<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">
    <div class="w3-center"><br>
        <img src="<?php echo e(asset('images/img_avatar.png')); ?>" alt="Avatar" style="width:30%" class="w3-circle w3-margin-top">
    </div>


    <?php echo e(Form::open(array('route' => 'register', 'class' => 'w3-container'))); ?>

    
    <p>Utilizza questa form per registrarti al sito</p>

    <div  class="w3-section">
        <?php echo e(Form::label('name', 'Nome', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('name', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'name', 'autofocus'])); ?>

        <?php if($errors->first('name')): ?>
        <ul class="w3-text-red">
            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('surname', 'Cognome', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('surname', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'surname'])); ?>

        <?php if($errors->first('surname')): ?>
        <ul class="w3-text-red">
            <?php $__currentLoopData = $errors->get('surname'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('email', 'Email', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('email', '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'email'])); ?>

        <?php if($errors->first('email')): ?>
        <ul class="w3-text-red">
            <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('username', 'Nome Utente', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('username', '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'username'])); ?>

        <?php if($errors->first('username')): ?>
        <ul class="w3-text-red">
            <?php $__currentLoopData = $errors->get('username'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('password', 'Password', ['class' => 'label-input'])); ?>

        <?php echo e(Form::password('password', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'password'])); ?>

        <?php if($errors->first('password')): ?>
        <ul class="w3-text-red">
            <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('password-confirm', 'Conferma password', ['class' => 'label-input'])); ?>

        <?php echo e(Form::password('password_confirmation', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'password-confirm'])); ?>

    </div>
    

    
    <?php echo e(Form::label('locatario', 'Locatario', ['class' => 'label-input'])); ?>

    <?php echo e(Form::radio('tipo', 'Locatario', true, ['id' => 'locatario'])); ?>

    &nbsp;
    <?php echo e(Form::label('locatore', 'Locatore', ['class' => 'label-input'])); ?>

    <?php echo e(Form::radio('tipo', 'Locatore', false, ['id' => 'locatore'])); ?>




    <div class="container-form-btn">                
        <?php echo e(Form::submit('Registra', ['class' => 'w3-button w3-block w3-green w3-section w3-padding'])); ?>

    </div>

    <?php echo e(Form::close()); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/laraProject/resources/views/auth/register.blade.php ENDPATH**/ ?>