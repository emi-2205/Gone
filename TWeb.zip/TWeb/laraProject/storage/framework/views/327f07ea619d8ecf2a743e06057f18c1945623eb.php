<div class="w3-container">
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-pencil-square-o"></i>
        Bozza&nbsp;
        <i class="fa fa-cloud-upload"></i>
        Pubblicato&nbsp;
        <i class="fa fa-check"></i>
        Assegnato
    </div>
  <table class="w3-table-all w3-hoverable">
    <tr>
      <th></th>
      <th>Nome Alloggio</th>
      <th>Descrizione</th>
      <th class="w3-right-align">Canone Affitto</th>
      <th></th>
    </tr>
    <?php if(isset($alloggi)): ?>
    <?php $__currentLoopData = $alloggi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alloggio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
      <td><?php echo $__env->make('helpers/iconStatoAlloggio', ['stato' => $alloggio->stato], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
      <td style="width: 20%"><?php echo e($alloggio->nome); ?></td>
      <td><?php echo e($alloggio->descrizione); ?></td>
      <td style="width: 10%" class="w3-right-align"><?php echo e($alloggio->canone_affitto); ?>&euro;</td>
      <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('alloggio', [$alloggio->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </table>
</div><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/componenti/alloggi_list_locatore.blade.php ENDPATH**/ ?>