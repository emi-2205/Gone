<div class="w3-container">

    <table class="w3-table-all w3-hoverable big-screen">
        <tr>
            <th class="break-word">Nome Alloggio</th>
            <th class="break-word">Descri&shy;zione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th class="w3-right-align">Con&shy;tatti</th>
            <th class="w3-right-align">Opzio&shy;ni</th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php if(isset($chat->alloggio)): ?>
            <td class="break-word" style="width: 20%"><?php echo e($chat->alloggio->nome); ?></td>
            <td class="break-word"><?php echo e($chat->alloggio->descrizione); ?></td>
            <td style="width: 10%" class="w3-right-align"><?php echo e($chat->alloggio->canone_affitto); ?>&euro;</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow"><?php echo e($num_contatti[$chat->id]); ?></span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green"><?php echo e($num_opzioni[$chat->id]); ?></span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('locatore-chat-all-locatari', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            <?php endif; ?>
            <?php if(empty($chat->alloggio)): ?>
            <td class="break-word" style="width: 20%"><?php echo e($chat->descrizione); ?></td>
            <td>N/A</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow"><?php echo e($num_contatti[$chat->id]); ?></span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green"><?php echo e($num_opzioni[$chat->id]); ?></span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('locatore-chat-all-locatari', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
        <table class="w3-table-all w3-hoverable small-screen">
        <tr>
            <th class="break-word">Nome Alloggio</th>
            <th class="w3-right-align">Canone</th>
            <th class="w3-right-align">Con&shy;tatti</th>
            <th class="w3-right-align">Opzio&shy;ni</th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <?php if(isset($chat->alloggio)): ?>
            <td class="break-word" style="width: 70%"><?php echo e($chat->alloggio->nome); ?></td>
            <td style="width: 10%" class="w3-right-align"><?php echo e($chat->alloggio->canone_affitto); ?>&euro;</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow"><?php echo e($num_contatti[$chat->id]); ?></span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green"><?php echo e($num_opzioni[$chat->id]); ?></span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('locatore-chat-all-locatari', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            <?php endif; ?>
            <?php if(empty($chat->alloggio)): ?>
            <td class="break-word" style="width: 70%"><?php echo e($chat->descrizione); ?></td>
            <td>N/A</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow"><?php echo e($num_contatti[$chat->id]); ?></span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green"><?php echo e($num_opzioni[$chat->id]); ?></span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('locatore-chat-all-locatari', [$chat->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/componenti/chat_list_locatore.blade.php ENDPATH**/ ?>