
<div class="w3-container w3-margin" style="border: 2px solid lightgrey; border-radius: 8px; padding: 5px; background-color: #BDBBBB5E; max-width:2000px">
    <div class="w3-row w3-margin">

        <div class="w3-third" style="max-width:400px">
            <img src="<?php echo e(asset('images/anteprime/'.$alloggio->immagine)); ?>" class="responsive"">
        </div>
        <div class="w3-twothird">
            <div class="">
                <div class="w3-col">
                    <b><h2><?php echo e($alloggio->nome); ?></h2></b>
                    <hr style="height:2px;border-width:0;color:gray;background-color:gray">
                </div>
            </div>
            <div class="w3-cell-row">
                <div class="w3-cell w3-margin">
                    <h4><i class="fa fa-map-marker"></i>&nbsp<?php echo e($alloggio->indirizzo); ?></h4>
                    <h4><i class="fa  fa-bed"></i>&nbsp<?php echo e($alloggio->tipologia); ?></h4>
                    <h4><i class="fa fa-calendar"></i>&nbsp<?php echo e($alloggio->data_inizio_locazione); ?> - <?php echo e($alloggio->data_fine_locazione); ?></h4>
                </div>
                <div class="w3-cell-middle" style="text-align: right;">
                    <h3>&nbsp</h3>
                    <h3>&nbsp<?php echo e($alloggio->canone_affitto); ?>€</h3>
                </div>
            </div>
            <div class="w3-row">
                <div class="">
                    <p>
                        <?php echo e($alloggio->descrizione); ?>

                    </p>
                </div>
            </div>

        </div>
    </div>
    
</div>



<?php if($alloggio->id != 0): ?>
    <?php echo e($titolo = 'Modifica Alloggio'); ?>

    <?php echo e($azione = 'Modifica'); ?>

    <?php echo e($azione_immagine = 'Per cambiare l\' immagine dell\' alloggio:'); ?>

<?php else: ?>
    <?php echo e($titolo = 'Crea Alloggio'); ?> 
    <?php echo e($azione = 'Crea'); ?>

    <?php echo e($azione_immagine = 'Per inserire un\' immagine:'); ?>    
<?php endif; ?>

<?php $__env->startSection('heading',  $titolo); ?>



<!-- inizio sezione alloggi -->
<?php $__env->startSection('content'); ?>

<?php if($alloggio->id != 0): ?>
    <?php echo e(Form::open(array('route' => array('aggiornaAlloggio', [$alloggio]), 'class' => 'w3-container', 'files' => true))); ?>

<?php else: ?>
    <?php echo e(Form::open(array('route' => 'inserisciAlloggio', 'class' => 'w3-container', 'files' => true))); ?>     
<?php endif; ?>

<?php echo csrf_field(); ?>

<div  class="w3-section">
    <?php echo e(Form::label('nome', 'Nome', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('nome', $alloggio->nome, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il Nome', 'id' => 'nome'])); ?>

    <?php if($errors->first('nome')): ?>
    <ul class="errors"> 
        <?php $__currentLoopData = $errors->get('nome'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?> 
</div>

<div  class="w3-section">
    <?php echo e(Form::label('descrizione', 'Descrizione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('descrizione', $alloggio->descrizione, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire la descrizione', 'id' => 'descrizione'])); ?>

    <?php if($errors->first('descrizione')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('descrizione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('canone_affitto', 'Canone affitto', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('canone_affitto',  $alloggio->canone_affitto, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il canone affitto', 'id' => 'canone_affitto'])); ?>

    <?php if($errors->first('canone_affitto')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('canone_affitto'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="w3-section">
    <?php echo e($alloggio->stato); ?>

    <?php echo e(Form::label('stato', 'Stato', ['class' => 'label-input'])); ?>

    <?php echo e(Form::select('stato', $stati, $alloggio->stato, ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'statoId'])); ?>

</div>



<div  class="w3-section">
    <p class="label-input"><?php echo e(Form::label('superficie', 'Superficie')); ?> &#13217</p>
    <?php echo e(Form::text('superficie', $alloggio->superficie, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire la superficie', 'id' => 'superficieId'])); ?>

    <?php if($errors->first('superficie')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('superficie'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('zona_localizzazione', 'Zona di localizzazione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('zona_localizzazione', $alloggio->zona_localizzazione, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire la zona di localizzazione', 'id' => 'zona_localizzazioneId'])); ?>

    <?php if($errors->first('zona_localizzazione')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('zona_localizzazione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('eta_min', 'Età minima richiesta', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('eta_min', $alloggio->eta_min, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire età minima richiesta', 'id' => 'eta_minId'])); ?>

    <?php if($errors->first('eta_min')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('eta_min'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div  class="w3-section">
    <?php echo e(Form::label('eta_max', 'Età massima richiesta', ['class' => 'label-input'])); ?>

    <?php echo e(Form::text('eta_max', $alloggio->eta_max, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire età massima richiesta', 'id' => 'eta_maxId'])); ?>

    <?php if($errors->first('eta_max')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('eta_max'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="w3-section">
    <?php echo e(Form::label('genere', 'Genere Richiesto', ['class' => 'label-input'])); ?>

    <?php echo e(Form::select('genere', $generi, $alloggio->genere, ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'genereId'])); ?>

</div>

<div class="w3-section">
    <?php echo e(Form::label('data_inizio_locazione', 'Data Inizio Locazione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::date('data_inizio_locazione', $alloggio->data_inizio_locazione, ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'data_inizio_locazioneId'])); ?>

    <?php if($errors->first('data_inizio_locazione')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('data_inizio_locazione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="w3-section">
    <?php echo e(Form::label('data_fine_locazione', 'Data Fine Locazione', ['class' => 'label-input'])); ?>

    <?php echo e(Form::date('data_fine_locazione', $alloggio->data_fine_locazione, ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'data_fine_locazioneId'])); ?>

    <?php if($errors->first('data_fine_locazione')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('data_fine_locazione'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="w3-section">   
    <?php echo e(Form::label('immagine', $azione_immagine, ['class' => 'label-input'])); ?>

    <?php echo e(Form::file('immagine', ['class' => 'input', 'id' => 'immagineId'])); ?>

    <?php if($errors->first('immagine')): ?>
    <ul class="errors">
        <?php $__currentLoopData = $errors->get('immagine'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>


<div class="w3-section">
    <?php echo e(Form::label('tipologia', 'Tipologia', ['class' => 'label-input'])); ?>

    <?php echo e(Form::select('tipologia', $tipologie, $alloggio->tipologia, ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'tipologiaId'])); ?>

</div>    


<div id="idBloccoAppartamento">
    
    <div  class="w3-section">
        <?php echo e(Form::label('num_camere_app', 'Numero camere', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_camere_app', $alloggio->num_camere, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di camere', 'id' => 'num_camere_app_Id'])); ?>

        <?php if($errors->first('num_camere_app')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_camere_app'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div  class="w3-section">
        <?php echo e(Form::label('num_letti_tot_app', 'Numero letti totali', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_letti_tot_app', $alloggio->num_letti_tot, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di letti totali', 'id' => 'num_letti_tot_app_Id'])); ?>

        <?php if($errors->first('num_letti_tot_app')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_letti_tot_app'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div class="w3-section">
        <?php echo e(Form::label('cucina_app', 'Cucina', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('cucina_app', 1, $alloggio->cucina)); ?>

    </div>

    <div class="w3-section">
        <?php echo e(Form::label('locale_ricreativo_app', 'Locale ricreativo', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('locale_ricreativo_app', 1, $alloggio->locale_ricreativo)); ?>

    </div>

    <div class="w3-section">
        <?php echo e(Form::label('internet_app', 'Internet', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('internet_app', 1, $alloggio->internet)); ?>

    </div>

</div>

<div id="idBloccoPostoLetto">

    <div  class="w3-section">
        <?php echo e(Form::label('num_letti_tot_pl', 'Numero letti totali', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_letti_tot_pl', $alloggio->num_letti_tot, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di letti totali', 'id' => 'num_letti_tot_pl_Id'])); ?>

        <?php if($errors->first('num_letti_tot_pl')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_letti_tot_pl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
    
    <div  class="w3-section">
        <?php echo e(Form::label('num_letti_camera_pl', 'Numero letti della camera', ['class' => 'label-input'])); ?>

        <?php echo e(Form::text('num_letti_camera_pl', $alloggio->num_letti_camera, ['class' => 'w3-input w3-border w3-margin-bottom', 'placeholder' => 'Inserire il numero di letti della camera', 'id' => 'num_letti_cameraId'])); ?>

        <?php if($errors->first('num_letti_camera_pl')): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->get('num_letti_camera_pl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>

    <div class="w3-section">
        <?php echo e(Form::label('angolo_studio_pl', 'Angolo studio', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('angolo_studio_pl', 1, $alloggio->angolo_studio)); ?>

    </div>
    
    <div class="w3-section">
        <?php echo e(Form::label('internet_pl', 'Internet', ['class' => 'label-input'])); ?>

        <?php echo e(Form::checkbox('internet_pl', 1, $alloggio->internet)); ?>

    </div>

</div>


<div class="container-form-btn">                
    <?php echo e(Form::submit($azione, ['class' => 'w3-button w3-block w3-green w3-section w3-padding'])); ?>

</div>

<?php echo e(Form::close()); ?>



<?php $__env->startSection('page_specific_js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/alloggioSearch.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/componenti/alloggio_edit.blade.php ENDPATH**/ ?>