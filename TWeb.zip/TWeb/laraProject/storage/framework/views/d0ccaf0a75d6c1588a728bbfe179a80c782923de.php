<?php $__env->startSection('title', 'PROFILO'); ?>

<?php $__env->startSection('heading', 'Gestione del profilo di '.Auth::user()->name); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('helpers/error_display', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="w3-card-4">

    <?php echo e(Form::model($user, array('route' => 'updateProfilo', 'class' => 'w3-container'))); ?>

    <div class="w3-row-padding">
        <div class="w3-quarter">

            <img src="<?php echo e(asset('images/img_avatar.png')); ?>" alt="Avatar" style="width:70%" class="w3-circle w3-margin-top">

        </div>
        <div class="w3-threequarter">
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        <?php echo e(Form::label('name', 'Nome', ['class' => ''])); ?>

                        <?php echo e(Form::text('name', null, ['class' => 'w3-input w3-border',
                                    'placeholder' => 'Nome...',
                                    'id' => 'name', 'autofocus'])); ?>

                    </div>
                </div>
                <div class="w3-half">
                    <div class="w3-section">
                        <?php echo e(Form::label('surname', 'Cognome', ['class' => '', 'style'=>''])); ?>

                        <?php echo e(Form::text('surname', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Cognome...', 'id' => 'surname'])); ?>

                    </div> 
                </div>
            </div>

            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        <?php echo e(Form::label('email', 'E-mail', ['class' => ''])); ?>

                        <?php echo e(Form::email('email', null, ['class' => 'w3-input w3-border', 'placeholder' => 'E-mail...', 'id' => 'email'])); ?>

                    </div>
                </div>
                <div class="w3-half">
                    <div class="w3-section">
                        <?php echo e(Form::label('telefono', 'Telefono', ['class' => ''])); ?>

                        <?php echo e(Form::text('telefono', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Telefono...', 'id' => 'telefono'])); ?>

                    </div>
                </div>
            </div>
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        <?php echo e(Form::label('genere', 'Genere', ['class' => ''])); ?>

                        <?php echo e(Form::select('genere', $genere, null, ['class' => 'w3-input w3-border', 'id' => 'tipologia'])); ?>

                    </div>
                </div>
                <div class="w3-half">
                    <div class="w3-section">
                        <?php echo e(Form::label('data_nascita', 'Data di Nascita', ['class' => ''])); ?>

                        <?php echo e(Form::date('data_nascita', null, ['class' => 'w3-input w3-border', 'id' => 'data_nascita'])); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="w3-row-padding">
        <div class="w3-threequarter">&nbsp;</div>
        <div class="w3-quarter">
            <div class="w3-section">
                <?php echo e(Form::submit('Salva', ['class' => 'w3-btn w3-block w3-blue '])); ?>

            </div>
        </div>
    </div>

    <?php echo e(Form::close()); ?> 
</div>

<?php $__env->stopSection(); ?>

<!--                 <form action="/action_page.php" class="w3-input w3-border w3-margin-bottom w3-round-large">
                    <input type="date" class="w3-input w3-border w3-margin-bottom w3-round-large" id="birthday" name="birthday" value="ciao">
                </form> -->


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/auth/profilo.blade.php ENDPATH**/ ?>