<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('heading', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .vl {
        border-left: 2px solid blue;
        height: 200px;
    }
</style>

<div class="w3-container">
    <h2>News: le offerte più recenti</h2>
    <p>Sed lacus. Donec lectus. Nullam pretium nibh ut turpis. Nam bibendum. In nulla tortor, elementum vel, tempor at, varius non, purus. Mauris vitae nisl nec metus placerat consectetuer. Donec ipsum. Proin imperdiet est. Phasellus dapibus semper urna. Pellentesque ornare, orci in consectetuer hendrerit, urna elit eleifend nunc, ut consectetuer nisl felis ac diam. Etiam non felis. Donec ut ante. In id eros. Suspendisse lacus turpis, cursus egestas at sem. Phasellus pellentesque. Mauris quam enim, molestie in, rhoncus ut, lobortis a, est.</p>
</div>
<div class="w3-content w3-display-container" style="width: 50%">

    <?php if(isset($alloggi)): ?>

    <?php $__currentLoopData = $alloggi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alloggio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="w3-display-container mySlides">
        <img src="<?php echo e(asset('images/anteprime/'. $alloggio->immagine)); ?>" style="width:100%">
        <div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
            <?php echo e($alloggio->nome); ?>

        </div>
          <div class="w3-display-topright w3-container w3-padding-16 w3-black">
    <?php echo e($alloggio->descrizione); ?> situato in <?php echo e($alloggio->indirizzo); ?>

    </div>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <button class="w3-button w3-display-left w3-black" onclick="plusDivs(-1)">&#10094;</button>
    <button class="w3-button w3-display-right w3-black" onclick="plusDivs(1)">&#10095;</button>

</div>

<br><br>
<div class="w3-row-padding">
    <div class="w3-col s3 w3-center">
        <h3>Cerca</h3><br>
        <i class="fa fa-search w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Cerca l'alloggio che fa per te</p>
    </div>
    <div class="w3-col s3 w3-center">
        <h3>Scrivi</h3><br>
        <i class="fa fa-paper-plane w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Opziona e/o contatta il locatore</p>
    </div>

    <div class="w3-col s3 w3-center vl">

        <h3>Pubblica</h3><br>
        <i class="fa fa-home w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Pubblica il tuo alloggio</p>
    </div>
    <div class="w3-col s3 w3-center">
        <h3>Assegna</h3><br>
        <i class="fa fa-handshake-o w3-margin-bottom w3-text-theme" style="font-size:60px"></i>
        <p>Ricevi opzioni e assegna</p>
    </div>
</div>

<script>
    var slideIndex = 1;
    showDivs(slideIndex);

    function plusDivs(n) {
        showDivs(slideIndex += n);
    }

    function showDivs(n) {
        var i;
        var x = document.getElementsByClassName("mySlides");
        if (n > x.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = x.length
        }
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        x[slideIndex - 1].style.display = "block";
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/home1.blade.php ENDPATH**/ ?>