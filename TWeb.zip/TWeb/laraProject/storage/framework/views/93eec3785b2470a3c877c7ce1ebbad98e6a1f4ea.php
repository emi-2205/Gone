<?php $__env->startSection('title', 'Chat Locatario'); ?>
<?php $__env->startSection('heading', 'Ricerca alloggi'); ?>
<?php $__env->startSection('legenda', "Puoi cercare qui l'alloggio che soddisfa le tue esigenze." ); ?>

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('componenti/alloggi_filter_locatario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('componenti/alloggi_list_locatario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(isset($alloggi)): ?>
<!--Paginazione-->
<br>
<?php echo $__env->make('pagination.paginator', ['paginator' => $alloggi->appends(request()->input())], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/grp_04/www/laraProject/resources/views/locatario/alloggi_list.blade.php ENDPATH**/ ?>