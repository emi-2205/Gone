

<nav class="w3-sidebar w3-blue w3-collapse w3-top w3-large w3-padding w3-card-4" style="z-index:3;width:230px;font-weight:bold;" id="mySidebar"><br>
    <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Chiudi</a>
    <div class="w3-container">
        <div class="w3-bar-block w3-padding-32">
            <img src="<?php echo e(asset('images/affittasi.png')); ?>" alt="Logo" style="width:100%">
            <h3 class=""><b>MyUniRent<h6>Il miglior sito di alloggi per studenti</b></h6></h3>
            <?php if(auth()->guard()->check()): ?>
            <h6><?php echo e(Auth::user()->name); ?></h6>
            <?php endif; ?> 
            <?php if(auth()->guard()->guest()): ?>
            <h6>Benvenuto</h6>
            <?php endif; ?>
        </div>
    </div>
    <div class="w3-bar-block">
        <a href="<?php echo e(route('home')); ?>" title="Vai alla Home" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Home</a>
        <a href="<?php echo e(route('catalogo')); ?>" title="Visualizza il Catalogo" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Catalogo</a> 
        <a href="<?php echo e(route('faq-list', ['1'])); ?>" title="Consulta le Faq" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Faq</a>
        <hr>
        <?php if(auth()->guard()->check()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isLocatore')): ?>
        <?php echo $__env->make('layouts/_sidebar_locatore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isLocatario')): ?>
        <?php echo $__env->make('layouts/_sidebar_locatario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAmministratore')): ?>
        <?php echo $__env->make('layouts/_sidebar_amministratore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <a href="" title="Esci dal sito" onclick="w3_close(); event.preventDefault(); document.getElementById('logout-form').submit();" class="w3-bar-item w3-button w3-hover-white">Logout</a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>
        <?php endif; ?> 
   
        <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('login')); ?>" title="Accedi all'area riservata del sito" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Accedi</a>
        <?php endif; ?>

    </div>
</nav><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/layouts/_sidebar.blade.php ENDPATH**/ ?>