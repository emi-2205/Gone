<div class="w3-row w3-margin">

    <div class="w3-third" style="max-width:400px">
        <?php echo $__env->make('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="w3-twothird">
        <div class="">
            <div class="w3-col">
                <b><h2><?php echo e($alloggio->nome); ?></h2></b>
                <hr style="height:2px;border-width:0;color:gray;background-color:gray">
            </div>
        </div>
        <div class="w3-cell-row">
            <div class="w3-cell w3-margin">
                <h4><i class="fa fa-map-marker" title="Indirizzo"></i>&nbsp<?php echo e($alloggio->indirizzo); ?></h4>
                <?php if($alloggio->tipologia == 'Appartamento'): ?>
                <h4><i class="fa  fa-home"title="Tipologia"></i>&nbsp<?php echo e($alloggio->tipologia); ?></h4>
                <?php else: ?>
                <h4><i class="fa  fa-bed"title="Tipologia"></i>&nbsp<?php echo e($alloggio->tipologia); ?></h4>
                <?php endif; ?>
                <h4><i class="fa fa-calendar" title="Periodo di locazione"></i>&nbsp<?php echo e(date('d/m/Y', strtotime($alloggio->data_inizio_locazione))); ?> - <?php echo e(date('d/m/Y', strtotime($alloggio->data_fine_locazione))); ?></h4>
                <h4><?php echo $__env->make('componenti/alloggioServizi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></h4>
                <?php if(isset($alloggio->data_ora_pubblicazione)): ?>
                <p>Annuncio inserito il <?php echo e(date('d/m/Y', strtotime($alloggio->data_ora_pubblicazione))); ?></p>
                <?php endif; ?>
            </div>
            <div class="w3-cell-middle" style="text-align: right;">
                <h3>&nbsp</h3>
                <h3>&nbsp<?php echo e($alloggio->canone_affitto); ?>€</h3>
            </div>
        </div>
        <div class="w3-row">
            <div class="">
                <p>
                    <?php echo e($alloggio->descrizione); ?>

                </p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/grp_04/www/laraProject/resources/views/componenti/info_alloggio.blade.php ENDPATH**/ ?>