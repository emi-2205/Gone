<?php
        if (empty($imgFile)) {
            $imgFile = 'default.jpg';
        }
        if (is_null($attrs)) {
            $attrs = '';
        }

?>
<img src="<?php echo e(asset('images/anteprime/' . $imgFile)); ?>" <?php echo $attrs; ?>><?php /**PATH /Applications/MAMP/htdocs/myunirent/resources/views/helpers/alloggioImg.blade.php ENDPATH**/ ?>