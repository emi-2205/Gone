<?php $__env->startSection('title', 'Catalogo'); ?>

<?php $__env->startSection('heading', 'Catalogo degli Alloggi'); ?>

<?php $__env->startSection('content'); ?>

<?php if(isset($alloggi)): ?>
<?php $__currentLoopData = $alloggi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alloggio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="w3-container w3-margin info-card">
<?php echo $__env->make('componenti/info_alloggio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($alloggio->stato == 'Assegnato'): ?>
<p class="banner">Questo alloggio è stato assegnato di recente.</p>
<?php endif; ?>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--Paginazione-->
<?php echo $__env->make('pagination.paginator', ['paginator' => $alloggi], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/catalog.blade.php ENDPATH**/ ?>