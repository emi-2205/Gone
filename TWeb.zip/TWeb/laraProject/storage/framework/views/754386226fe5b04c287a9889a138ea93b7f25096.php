<div class="w3-container">
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-comments"></i>
        Info&nbsp;
        <i class="fa fa-paper-plane"></i>
        Opzione&nbsp;
        <i class="fa fa-check"></i>
        Assegnamento&nbsp;
        <i class="fa fa-times"></i>
        Rifiuto&nbsp;
    </div>
  <table class="w3-table-all w3-hoverable">
    <tr>
      <th></th>
      <th>Cognome</th>
      <th>Nome</th>
      <th>Telefono</th>
      <th>Mail</th>
      <th></th>
    </tr>
    <?php $__currentLoopData = $azioni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $azione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($locatario = $azione->locatario); ?>
     <tr>
         <td><i class="<?php echo e($locatari_status[$locatario->id]); ?>"></i></td>
      <td><?php echo e($locatario->surname); ?></td>
      <td><?php echo e($locatario->name); ?></td>
      <td><?php echo e($locatario->telefono); ?></td>
      <td><?php echo e($locatario->email); ?></td>
      <td class="w3-right-align" style="width: 70px"> <a href="<?php echo e(route('chat-locatore', [$chat_id, $locatario->id])); ?>" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/componenti/list_locatari.blade.php ENDPATH**/ ?>