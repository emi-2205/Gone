<?php
        if (empty($imgFile)) {
            $imgFile = 'default.jpg';
        }
        if (is_null($attrs)) {
            $attrs = '';
        }

?>
<img src="<?php echo e(asset('images/anteprime/' . $imgFile)); ?>" <?php echo $attrs; ?>><?php /**PATH /home/grp_04/www/myunirent_v1beta/resources/views/helpers/alloggioImg.blade.php ENDPATH**/ ?>