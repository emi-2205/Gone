<div class="w3-container w3-margin info-card">

<h1><?php echo e($chat-> descrizione); ?> </h1>
<h1> Notizie della chat di un alloggio che fu... </h1>

</div><?php /**PATH /Users/emiliojosephgrieco/Workspace/Apache/TWeb/laraProject/resources/views/componenti/alloggio_che_fu.blade.php ENDPATH**/ ?>