<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isLocatario')): ?>
<?php
$msg = '';
if ($alloggio->stato == 'Assegnato') {
if ($alloggio->assegnatario_id == $locatario->id) {
$msg = "Questo alloggio ti è stato assegnato";
$msg = $msg.' in data '.date('d/m/Y H:i', strtotime($alloggio->data_ora_assegnazione));
} else {
$msg = "Alloggio assegnato ad altro Locatario";
}
} elseif ($alloggio->stato == 'Pubblicato') {
if (!is_null($opzione)) {
$msg = "Hai già opzionato questo alloggio";
}
}
?>

<h4><?php echo e($msg); ?></h4>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isOpzionabile', $alloggio)): ?> <!-- Le informazioni per fare questi controlli sarebbero
    già disponibili a livello di vista, ma si è voluto sperimentare l'utilizzo di un Gate complesso
    con passaggio di parametri -->

<?php echo e(Form::open(array('route' => 'send.message', 'id' => 'messaggio_opzione'))); ?>


<?php echo e(Form::hidden('chat_id', $chat->id)); ?>

<?php echo e(Form::hidden('locatario_id', $locatario->id)); ?>

<?php echo e(Form::hidden('tipo', 'Opzione')); ?>

<?php echo e(Form::hidden('testo', "Richiesta di opzione per l'alloggio ".$alloggio->nome)); ?>


<?php echo e(Form::submit('Opziona questo alloggio', ['class' => 'w3-btn w3-block w3-blue'])); ?>


<?php echo e(Form::close()); ?>

<?php endif; ?> <!-- chisura isOpzionabile -->


<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isLocatore')): ?>
<?php
$msg = '';
$showAssegnaButton = false;
$showContrattoButton = false;
if ($alloggio->stato == 'Assegnato') {
if ($alloggio->assegnatario_id == $locatario->id) {
$msg = "Alloggio assegnato a questo Locatario: ".$locatario->name." ".$locatario->surname;
$msg = $msg.' in data '.date('d/m/Y H:i', strtotime($alloggio->data_ora_assegnazione));
$showContrattoButton = true;
} else {
$msg = "Alloggio assegnato ad altro Locatario";
$msg = $msg.' in data '.date('d/m/Y H:i', strtotime($alloggio->data_ora_assegnazione));
}
} elseif ($alloggio->stato == 'Pubblicato') {
if (!is_null($opzione)) {
$msg = "Il Locatario ha opzionato questo alloggio";
$showAssegnaButton = true;
}
}

?>

<h4><?php echo e($msg); ?></h4>

<?php if($showAssegnaButton): ?>
<?php echo e(Form::open(array('route' => 'send.message', 'id' => 'messaggio_assegnamento'))); ?>


<?php echo e(Form::hidden('chat_id', $chat->id)); ?>

<?php echo e(Form::hidden('locatario_id', $locatario->id)); ?>

<?php echo e(Form::hidden('tipo', 'Assegnamento')); ?>

<?php echo e(Form::hidden('testo', "Ti è stato assegnato l'alloggio ".$alloggio->nome)); ?>


<?php echo e(Form::submit('Assegna questo alloggio', ['class' => 'w3-btn w3-block w3-blue'])); ?>


<?php echo e(Form::close()); ?>

<?php endif; ?>

<?php if($showContrattoButton): ?>
<?php if($alloggio->data_ora_contratto == null): ?>
<a href="<?php echo e(route('stampa.contratto', [$alloggio->id])); ?>" target="_blank" class="w3-btn w3-blue w3-block">Stampa il contratto</a>
<?php else: ?>
<a href="<?php echo e(route('stampa.contratto', [$alloggio->id])); ?>" target="_blank" class="w3-btn w3-blue w3-block">Stampa una copia del contratto</a>
<?php endif; ?>
<?php endif; ?>

<?php endif; ?>

<?php /**PATH /home/grp_04/www/laraProject/resources/views/helpers/alloggioStatusHelper.blade.php ENDPATH**/ ?>