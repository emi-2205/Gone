
<div class="w3-container w3-margin info-card">
    <?php echo $__env->make('componenti/info_alloggio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('helpers/alloggioStatusHelper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Helper che si occupa di gestire l'accesso alle funzioni di
    opzione e assegnamento e di stampare i relativi messaggi di stato, sia per il locatore che per il locatario-->
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isLocatario')): ?> <!-- Cose da fare nel caso di Locatario -->
    
    <?php endif; ?> <!-- chisura isLocatario -->
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isLocatore')): ?> <!-- Cose da fare nel caso di Locatore -->

    <?php endif; ?> <!-- chisura isLocatore -->

</div>
<?php /**PATH /home/grp_04/www/laraProject/resources/views/componenti/alloggio.blade.php ENDPATH**/ ?>