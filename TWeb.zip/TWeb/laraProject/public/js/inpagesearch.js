// queste funzioni jQuery permettono di ridurre gli elementi visualizzati
// in una tabella di id="myTable" applicando, al keyUp, un filtraggio sui valori degli elementi della colonna
// identificata dalla classe "nome"
// il bottone identificato dall' id="pulisci" resetta il valore del campo di ricerca e vi scatena 
// un evento di keyUp per attivare la procedura che visualizzerà nuovamente l'intero contenuto della tabella

// $(document).ready() permette di eseguire una funzione quando il documento, cioè la pagina è completamente caricata
$(document).ready(function () {
    //applico il metodo on agli elementi del document con id=myInput
    //il metodo on() aggancia uno o più handler agli elementi
    //l'evento keyup è quando l'utente rilascia un tasto della keyboard
    $("#myInput").on("keyup", function () {
        //in quel caso viene chiamata una funzione che prende il valore inserito e lo setta a lowercase
        var value = $(this).val().toLowerCase();
        //nella tabella degli alloggi va dove c'è il nome e fa un filtraggio
        $("#myTable .nome").filter(function () {
            $(this).parent().toggle($(this).text().toLowerCase().indexOf(value) > -1)
            //con parent() all'interno del DOM vado a prendere il padre della riga nome, cioè l'intera tabella
            //dopodiché con toggle(condizione) nascondo la tabella dell'alloggio se condizione=true, altrimenti la mostro

            //value è la stringa che l'utente ha inserito nella form di ricerca
            //indexOf cerca value all'interno di nome e restituisce il numero di caratteri dopo la quale si trova value
            //se value non è presente all'interno di nome restituisce -1

            //Complessivamente quindi: se value non è contenuta in nome nascondi la tabella dell'alloggio
        });
    });

    $("#pulisci").on("click", function () {
        //al click della pulsante con la x pulisci la form di ricerca, in automatico si mostreranno tutti gli elementi
        $("#myInput").val('').keyup();
    });
});