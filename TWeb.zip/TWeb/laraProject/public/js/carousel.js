//Questo è il codice per animare lo slideshow mostrato in homepage

//indice slider
var slideIndex = 1;

//gli passo 1 o -1 e si sposta di avanti o indietro di 1 rispetto all'indice attuale
function plusDivs(n) {
    showDivs(slideIndex += n);
}


window.onload = function () {
    showDivs(slideIndex);
}


function showDivs(n) {
    var i;
    var x = document.getElementsByClassName("mySlides");
    //se arrivo a fine carousel ricomincio dal primo elemento
    if (n > x.length) {
        slideIndex = 1
    }
    //se vado all'elemento precedente al primo ricomincio dall'ultimo
    if (n < 1) {
        slideIndex = x.length;
    }
    //assegno a tutti il display="none", quindi li nascondo
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    //mostro solo l'elemento attuale nel carousel
    x[slideIndex - 1].style.display = "block";
}