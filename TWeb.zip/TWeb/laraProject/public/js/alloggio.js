// funzione jQuery che, nella form di ricerca per il locatario, al cambio della tipologia di alloggio, 
// permette di presentare solo le informazioni proprie della tipologia selezionata
$(function () {
    $("#tipologia")
            .change(function () {
                var select = document.getElementById('tipologia');
                var text = select.options[select.selectedIndex].text;
                if (text == 'Appartamento') {
                    $("#idBloccoPostoLetto").hide();
                    $("#idBloccoAppartamento").show();
                } else if (text == 'Posto Letto') {
                    $("#idBloccoPostoLetto").show();
                    $("#idBloccoAppartamento").hide();
                } else if ((text == 'Tutte') || (text == '')) {
                    $("#idBloccoPostoLetto").hide();
                    $("#idBloccoAppartamento").hide();
                }
            })
            .change();
});
