google.charts.load("current", {packages: ['corechart']});
google.charts.setOnLoadCallback(drawChart);

var num_alloggi = 0;
var num_opzioni = 0;
var num_assegnazioni = 0;
var tipologia = "Qualsiasi";
var titolo = "Tutte le tipologie di alloggi";


// gestione del grafico

// funzione utilizzata per gestire il componente 'charts' di Google
function drawChart() {
    var data = google.visualization.arrayToDataTable([
        ["Element", "Quantità", {role: "style"}],
        [tipologia, num_alloggi, "color: blue"],
        ["Opzioni", num_opzioni, "color: aqua"],
        ["Assegnamenti", num_assegnazioni, "color: green"],
    ]);

    var view = new google.visualization.DataView(data);
    view.setColumns([0, 1,
        {calc: "stringify",
            sourceColumn: 1,
            type: "string",
            role: "annotation"},
        2]);

    var options = {
        title: titolo,
        width: 450,
        height: 400,
        bar: {groupWidth: "80%"},
        legend: {position: "none"},
    };
    var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
    chart.draw(view, options);
}

// funzione ajax che invia la richiesta POST al server per ricevere i dati statistici in formato json
function calcolaStatistiche() {
    var form = new FormData(document.getElementById('statistiche'));
    $.ajax({
        type: 'POST',
        // url: "{{ route('statistiche-calcola') }}", questo funzionava quando lo script era nella pagina e blade interveniva
        url: "statistiche/calcola", // non bisogna mettere lo / inziale perche così facciamo riferimento ad un url interno
        data: form,
        dataType: "json",
        //in caso di problemi nella ricezione del json
        error: function (data) {
            alert('Problemi nel recupero dei dati. Provare più tardi.')
        },
        //in caso di successo
        success: function (data) {
            //prendo dal json gli attributi che mi servono
            tipologia = data.tipologia;
            num_alloggi = parseInt(data.alloggi);
            num_opzioni = parseInt(data.opzioni);
            num_assegnazioni = parseInt(data.assegnazioni);
            // dalla tipogia ottengo una descrizione estesa
            switch (data.tipologia) {
                case 'Qualsiasi':
                    titolo = "Tutte le tipologie di alloggi";
                    break;
                case 'Appartamento':
                    titolo = "Solo gli Appartamenti";
                    break;
                case 'Posto Letto':
                    titolo = "Solo i Posti Letto";
                    break;
            }
            

            // personalizzazione dei messaggi mostrati a video dipendentemente
            // dai risultati ricevuti
            if ((num_alloggi + num_opzioni + num_assegnazioni) == 0) { // non ho trovato nulla
                var msg = "Nessun dato trovato per i criteri di ricerca indicati.";
                $("#info").text(msg);
                $("#alloggi").text("");
                $("#opzioni").text("");
                $("#assegnazioni").text("");
                $("#columnchart_values").hide();
            } else { // dati trovati
                var msg = "Questi sono i risultati trovati per la tipologia " + data.tipologia;
                $("#info").text(msg);
                $("#alloggi").text("Offerte di alloggio (Alloggi): " + data.alloggi);
                $("#opzioni").text("Offerte di locazione (Opzioni): " + data.opzioni);
                $("#assegnazioni").text("Alloggi locati (Assegnamenti): " + data.assegnazioni);
                // i dati sono arrivati correttamente e quindi richiamo la funzione che
                // disegnerà il grafico all'interno dell'elemento html indicato
                $("#columnchart_values").show();
                drawChart();
            }
            

        },
        contentType: false,
        processData: false
    });
}

$(function () {
    
    // aggancio all'evento change degli elementi html che utilizzano la classe ricalcolo
    //la chiamata alla funzione calcolaStatistiche()
    $(".ricalcolo").change(function () {
        calcolaStatistiche();
    });

 
    calcolaStatistiche();  // inizializzo la pagina

});