<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAlloggioTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('alloggio', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->timestamps();
            $table->unsignedBigInteger('proprietario_id');
            $table->foreign('proprietario_id')->references('id')->on('users');
            $table->unsignedBigInteger('assegnatario_id')->nullable();
            $table->foreign('assegnatario_id')->references('id')->on('users');
            $table->unsignedBigInteger('chat_id');
            $table->foreign('chat_id')->references('id')->on('chat');
            
            // servizi e informazioni prorpri dell'Alloggio
            $table->string('nome', 50);
            $table->text('descrizione')->nullable();
            $table->unsignedDecimal('canone_affitto', 6, 2)->nullable();
            $table->enum('stato', ['Bozza','Pubblicato','Assegnato'])->default('Bozza');
            $table->enum('tipologia', ['Appartamento','Posto Letto']);
            $table->unsignedSmallInteger('superficie')->nullable();
            $table->string('indirizzo', 100)->nullable();
            $table->string('citta', 100)->nullable();
            $table->dateTimeTz('data_ora_inserimento')->nullable();
            $table->dateTimeTz('data_ora_pubblicazione')->nullable();
            $table->dateTimeTz('data_ora_assegnazione')->nullable();
            $table->dateTimeTz('data_ora_contratto')->nullable();
            $table->unsignedTinyInteger('eta_min')->nullable();
            $table->unsignedTinyInteger('eta_max')->nullable();
            $table->enum('genere', ['Non assegnato','Maschio','Femmina'])->default('Non assegnato');
            $table->date('data_inizio_locazione')->nullable();
            $table->date('data_fine_locazione')->nullable();
            $table->unsignedTinyInteger('num_letti_tot')->nullable();
            $table->boolean('internet')->default(false);
            $table->text('immagine')->nullable();
            
            // servizi e informazioni prorpri dell'Appartamento
            $table->unsignedTinyInteger('num_camere')->nullable();
            $table->boolean('cucina')->default(false);
            $table->boolean('locale_ricreativo')->default(false);
            
            // servizi e informazioni prorpri del Posto Letto
            $table->unsignedTinyInteger('num_letti_camera')->nullable();
            $table->boolean('angolo_studio')->default(false);
            $table->boolean('televisione')->default(false);
            $table->boolean('lavatrice')->default(false);
            $table->boolean('posto_bici')->default(false);
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('alloggio');
    }
}
