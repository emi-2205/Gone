<?php

use Illuminate\Database\Seeder;

class AlloggioSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {

        // Alloggio 1 Posto letto
        DB::table('chat')->insert(
                [
                    'id' => 1,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Accogliente stanza singola con parcheggio bici',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Posto Letto',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 1,
                    'proprietario_id' => 1,
                    'chat_id' => 1,
                    'nome' => 'Accogliente stanza singola con parcheggio bici',
                    'descrizione' => "Un posto letto in camera doppia perfettamente arredata che si trova all'interno di una struttura dal design moderno con tanti spazi per gli studenti dove poter stare in condivisione e poter usufruire di tutti i nostri servizi.",
                    'canone_affitto' => 500,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Posto Letto',
                    'superficie' => 14,
                    'indirizzo' => 'Viale Giovanni Vicini 2040134, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => null,
                    'num_letti_tot' => 3,
                    'num_letti_camera' => 1,
                    'cucina' => false,
                    'locale_ricreativo' => false,
                    'angolo_studio' => true,
                    'televisione' => false,
                    'lavatrice' => false,
                    'posto_bici' => true,
                    'internet' => true,
                    'immagine' => 'foto1.jpg'
        ]);
        // Alloggio 2 Posto letto
        DB::table('chat')->insert(
                [
                    'id' => 2,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Stanza attrezzata in alloggi per studenti',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Posto Letto',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 2,
                    'proprietario_id' => 1,
                    'chat_id' => 2,
                    'nome' => 'Stanza attrezzata in alloggi per studenti',
                    'descrizione' => "Stanza singola in un appartamento condiviso, composto da 6 camere e 2 bagni. Stanza di circa 14 mq con un letto singolo e una scrivania. Con parcheggio bici, televisione, wifi, lavastoviglie, lavatrice. Classe energetica: D, IPE 76.05 Kwh/mq anno.",
                    'canone_affitto' => 380,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Posto Letto',
                    'superficie' => 14,
                    'indirizzo' => 'Viale della Vittoria, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => null,
                    'num_letti_tot' => 3,
                    'num_letti_camera' => 1,
                    'cucina' => false,
                    'locale_ricreativo' => false,
                    'angolo_studio' => false,
                    'televisione' => true,
                    'lavatrice' => false,
                    'posto_bici' => false,
                    'internet' => false,
                    'immagine' => 'foto2.jpg'
        ]);
        // Alloggio 3 Posto letto
        DB::table('chat')->insert(
                [
                    'id' => 3,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Confortevole stanza singola',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Posto Letto',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 3,
                    'proprietario_id' => 1,
                    'chat_id' => 3,
                    'nome' => 'Confortevole stanza singola',
                    'descrizione' => "Stanza singola in un appartamento condiviso, composto da 4 camere e 1 bagno. Stanza di circa 18 mq con un letto singolo e una scrivania. Con televisione, wifi, lavastoviglie, lavatrice",
                    'canone_affitto' => 420,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Posto Letto',
                    'superficie' => 14,
                    'indirizzo' => 'Viale Giovanni Vicini 2040134, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => null,
                    'num_letti_tot' => 6,
                    'num_letti_camera' => 1,
                    'cucina' => false,
                    'locale_ricreativo' => false,
                    'angolo_studio' => false,
                    'televisione' => false,
                    'lavatrice' => true,
                    'posto_bici' => false,
                    'internet' => true,
                    'immagine' => 'foto3.jpg'
        ]);
        // Alloggio 4 Posto letto
        DB::table('chat')->insert(
                [
                    'id' => 4,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Singola nuova Centro',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Posto Letto',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 4,
                    'proprietario_id' => 1,
                    'chat_id' => 4,
                    'nome' => 'Singola nuova Centro',
                    'descrizione' => "Camera singola (con spaziosissimo balcone panoramico con affaccio sul verde del giardino condominiale), in appartamento nella centralissima Corso Mazzini",
                    'canone_affitto' => 550,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Posto Letto',
                    'superficie' => 14,
                    'indirizzo' => 'Corso Mazzini 31, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => null,
                    'num_letti_tot' => 3,
                    'num_letti_camera' => 1,
                    'cucina' => false,
                    'locale_ricreativo' => false,
                    'angolo_studio' => false,
                    'televisione' => false,
                    'lavatrice' => false,
                    'posto_bici' => true,
                    'internet' => true,
                    'immagine' => 'foto4.jpg'
        ]);
        // Alloggio 5 Posto letto
        DB::table('chat')->insert(
                [
                    'id' => 5,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Camera Doppia Viale Vittoria',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Posto Letto',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 5,
                    'proprietario_id' => 1,
                    'chat_id' => 5,
                    'nome' => 'Camera Doppia Viale Vittoria',
                    'descrizione' => "Stanza singola in un appartamento condiviso, composto da 6 camere e 2 bagni. Stanza di circa 14 mq con un letto singolo e una scrivania. Con parcheggio bici, televisione, wifi, lavastoviglie, lavatrice. Classe energetica: D, IPE 76.05 Kwh/mq anno.",
                    'canone_affitto' => 460,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Posto Letto',
                    'superficie' => 14,
                    'indirizzo' => 'Viale Giovanni Vicini 2040134, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => null,
                    'num_letti_tot' => 3,
                    'num_letti_camera' => 1,
                    'cucina' => false,
                    'locale_ricreativo' => true,
                    'angolo_studio' => true,
                    'televisione' => true,
                    'lavatrice' => true,
                    'posto_bici' => true,
                    'internet' => true,
                    'immagine' => 'foto5.jpg'
        ]);

        // Alloggio 6 Appartamento
        DB::table('chat')->insert(
                [
                    'id' => 6,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Confortevole monolocale',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Appartamento',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 6,
                    'proprietario_id' => 1,
                    'chat_id' => 6,
                    'nome' => 'Confortevole monolocale',
                    'descrizione' => "Intero appartamento di circa 23 mq composto da una stanza giorno/notte, con cucina e bagno privati, con un letto singolo, una scrivania.",
                    'canone_affitto' => 700,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Appartamento',
                    'superficie' => 23,
                    'indirizzo' => 'Viale Giovanni Vicini 2040134, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => 1,
                    'num_letti_tot' => 1,
                    'num_letti_camera' => null,
                    'cucina' => true,
                    'locale_ricreativo' => false,
                    'angolo_studio' => false,
                    'televisione' => false,
                    'lavatrice' => false,
                    'posto_bici' => false,
                    'internet' => true,
                    'immagine' => 'foto6.jpg'
        ]);
        // Alloggio 7 Appartamento
        DB::table('chat')->insert(
                [
                    'id' => 7,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Studio/Apt entrata indipendente',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Appartamento',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 7,
                    'proprietario_id' => 1,
                    'chat_id' => 7,
                    'nome' => 'Studio/Apt entrata indipendente',
                    'descrizione' => "Confortevole appartamento/studio finemente ristrutturato e accessoriato con cabina armadio, bagno finestrato in palazzina d'epoca con giardino privato. Capienza 2 persone",
                    'canone_affitto' => 600,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Appartamento',
                    'superficie' => 14,
                    'indirizzo' => 'Viale Giovanni Vicini 2040134, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => 2,
                    'num_letti_tot' => 2,
                    'num_letti_camera' => null,
                    'cucina' => false,
                    'locale_ricreativo' => true,
                    'angolo_studio' => false,
                    'televisione' => false,
                    'lavatrice' => false,
                    'posto_bici' => false,
                    'internet' => false,
                    'immagine' => 'foto7.jpg'
        ]);
        // Alloggio 8 Appartamento
        DB::table('chat')->insert(
                [
                    'id' => 8,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Appartamento Via Marconi',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Appartamento',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 8,
                    'proprietario_id' => 1,
                    'chat_id' => 8,
                    'nome' => 'Appartamento Via Marconi',
                    'descrizione' => "Affittasi Appartamento a Ancona, Via Marconi 262a, per 950 Euro al mese. Ammessi animali domestici.",
                    'canone_affitto' => 950,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Appartamento',
                    'superficie' => 14,
                    'indirizzo' => 'Viale Giovanni Vicini 2040134, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => 2,
                    'num_letti_tot' => 3,
                    'num_letti_camera' => null,
                    'cucina' => true,
                    'locale_ricreativo' => true,
                    'angolo_studio' => false,
                    'televisione' => false,
                    'lavatrice' => false,
                    'posto_bici' => false,
                    'internet' => true,
                    'immagine' => 'foto8.jpg'
        ]);
        // Alloggio 9 Appartamento
        DB::table('chat')->insert(
                [
                    'id' => 9,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Monolocale spese incluse',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Appartamento',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 9,
                    'proprietario_id' => 1,
                    'chat_id' => 9,
                    'nome' => 'Monolocale spese incluse',
                    'descrizione' => "Zona Stazione, monolocale arredato ed accessoriato, disponibile per 1 sola persona, letto singolo",
                    'canone_affitto' => 800,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Appartamento',
                    'superficie' => 14,
                    'indirizzo' => 'Via Rosselli 45, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => 1,
                    'num_letti_tot' => 1,
                    'num_letti_camera' => null,
                    'cucina' => false,
                    'locale_ricreativo' => false,
                    'angolo_studio' => false,
                    'televisione' => false,
                    'lavatrice' => false,
                    'posto_bici' => false,
                    'internet' => false,
                    'immagine' => 'foto9.jpg'
        ]);
        // Alloggio 10 Appartamento
        DB::table('chat')->insert(
                [
                    'id' => 10,
                    'responsabile_id' => 1,
                    'is_active' => true,
                    'descrizione' => 'Appartamento zona Umberto I',
                    'data_ora_pubblicazione' => now(),
                    'data_ora_ultimo_contatto' => now(),
                    'tipologia' => 'Appartamento',
        ]);
        DB::table('alloggio')->insert(
                [
                    'id' => 10,
                    'proprietario_id' => 1,
                    'chat_id' => 10,
                    'nome' => 'Appartamento zona Umberto I',
                    'descrizione' => "Nei pressi dell' Ospedale di Torrette in contesto silenzioso un appartamento al secondo piano di circa 60 mq con ascensore. L’appartamento è completamente arredato.",
                    'canone_affitto' => 450,
                    'stato' => 'Pubblicato',
                    'tipologia' => 'Appartamento',
                    'superficie' => 60,
                    'indirizzo' => 'Via Conca 4, Ancona (AN) , Italia',
                    'citta' => 'Ancona',
                    'data_ora_inserimento' => now(),
                    'data_ora_pubblicazione' => now(),
                    'data_ora_assegnazione' => null,
                    'data_ora_contratto' => null,
                    'eta_min' => 18,
                    'eta_max' => 25,
                    'genere' => 'Non assegnato',
                    'data_inizio_locazione' => '2022-06-15',
                    'data_fine_locazione' => '2023-01-15',
                    'num_camere' => 2,
                    'num_letti_tot' => 3,
                    'num_letti_camera' => null,
                    'cucina' => true,
                    'locale_ricreativo' => true,
                    'angolo_studio' => false,
                    'televisione' => false,
                    'lavatrice' => false,
                    'posto_bici' => false,
                    'internet' => true,
                    'immagine' => 'foto10.jpg'
        ]);
    }

}
