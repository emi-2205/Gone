<?php

use Illuminate\Database\Seeder;

class FaqSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {


        DB::table('categoria')->insert([
            ['id' => 1, 'nome' => 'Informazioni generali'],
            ['id' => 2, 'nome' => 'Accesso e Registrazione al sito'],
            ['id' => 3, 'nome' => 'Area pubblica'],
            ['id' => 4, 'nome' => 'Cosa può fare il locatore'],
            ['id' => 5, 'nome' => 'Cosa può fare il locatario'],
            ['id' => 6, 'nome' => 'Amministrazione del sito'],
            ['id' => 7, 'nome' => 'Varie']
                ]
        );

        // Informazioni generali
        DB::table('faq')->insert(
                ['categoria_id' => 1,
                    'domanda' => "Perchè MyUniRent",
                    'risposta' => "Il sito nasce dall'esigenza di semplificare il contatto tra chi ha spazi da offrire "
                    . "e gli studenti fuori sede in cerca di alloggio."]);

        DB::table('faq')->insert(
                ['categoria_id' => 1,
                    'domanda' => "Peculiarità",
                    'risposta' => "<p>Nel progetto dell'intero sistema si è posta cura particolare alla 'User Experience'.<p>"
                    . "<p>Le diverse tipologie di utenti che si registrano trovano ambienti operativi dedicati con "
                    . "funzionalità appositamente costruite per rendere facile ed intuitivo l'utilizzo del sito stesso.<p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 1,
                    'domanda' => "Una vetrina aperta a tutti",
                    'risposta' => "MyUniRent offre informazioni anche ai 'navigatori' occasionali, che possono avere un'anteprima "
                    . "di quanto messo a disposizione dai locatori e delle 'Success Stories' di contratti stipulati."]);

        DB::table('faq')->insert(
                ['categoria_id' => 1,
                    'domanda' => "Chi sa dirmi che cos'è un’Opzione?",
                    'risposta' => "<p>L’<i>Opzione</i> rappresenta la volontà di uno studente di prendere in affitto un alloggio.</p>"
                    . "<p>La gestione delle Opzioni è una delle caratteristiche distintive di MyUniRent, attraverso questa funzionalità si automatizza "
                    . "e si rende fluida la procedura che porta all'assegnazione di un alloggio.</p>"]);
        
        DB::table('faq')->insert(
                ['categoria_id' => 1,
                    'domanda' => "... e riguardo all'Assegnazione?",
                    'risposta' => "<p>Un alloggio è assegnato quando il locatore, tra tutti i locatari che hanno dimostrato "
                    . "interesse per questo inviando un’Opzione, ne ha scelto uno a cui affittarlo.</p>"]);
        
        DB::table('faq')->insert(
                ['categoria_id' => 1,
                    'domanda' => "Posso eliminare una chat?",
                    'risposta' => "<p>No, una chat può passare da attiva ad archiviata ma non può essere eliminata.</p>"]);
        
        DB::table('faq')->insert(
                ['categoria_id' => 1,
                    'domanda' => "Posso decidere di archiviare una chat?",
                    'risposta' => "<p>No, MyUniRent gestisce in automatico l’archiviazione delle chat. Dovrai solamente controllare "
                    . "di tanto in tanto lo stato delle tue Chat, lascia che il sistema se ne occupi per te.</p>"]);
        

        // Accesso e Registrazione al sito
        DB::table('faq')->insert(
                ['categoria_id' => 2,
                    'domanda' => "Accesso al sito",
                    'risposta' => "Per poter accedere a tutte le funzionalità del sito è necessario fare il login. "
                    . "La registrazione è gratuita e, se non l'hai ancora fatta, <a href='##registra##'>clicca qui per registrarti</a>. "
                    . "Se si gia registrato verrai rediretto alla pagina Home del sito."]);

        DB::table('faq')->insert(
                ['categoria_id' => 2,
                    'domanda' => "Procedura di Login",
                    'risposta' => "Solo gli utenti registrati possono accedere alle funzionalità di MyUniRent. "
                    . "Una volta inserite le tue credenziali, sia che tu sia un locatore o uno studenta in cerca di alloggio,"
                    . " il sistema ti guiderà presentando menù personalizzati per le tue esigenza."]);

        DB::table('faq')->insert(
                ['categoria_id' => 2,
                    'domanda' => "Aggiornamento del tuo Profilo",
                    'risposta' => "<p>In ogni momento potrai aggiornare le informazioni del tuo Profilo Utente "
                    . "dall'apposito menu 'Profilo' nella barra laterale o semplicemente <a href='##profilo##'>facendo click qui</a>.</p>"
                    . "<p>Ovviamente se non sei anora autenticato verrai automaticamente prima rediretto alla pagina di LogIn.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 2,
                    'domanda' => "Problemi nella fase di LogIn",
                    'risposta' => "Se non riesci ad autenticarti e myUniRent comunica che 'Le credenziali inserite non sono corrette', "
                    . "prova a controllare che <i>Nome Utente</i> e <i>Password</i> siano esattamente quelli che hai utilizzato in fase di registrazioone."
                    . "<p>Ricorda le lettere maiuscole e minuscole sono importanti!</p>"]);

        // Area pubblica
        DB::table('faq')->insert(
                ['categoria_id' => 3,
                    'domanda' => "Home",
                    'risposta' => "<p>Qui MyUinRent si presenta</p>"
                    . "<p>Potrai trovare informazioni sul team di sviluppo e gestione, le motiviazini che ci hanno spinto a realizzare questa soluzion, "
                    . "cosa siamo in grado di fare per te e come poterci contattare.</p>"
                    . "<p>E' anche presente un'anteprima degli utltimi alloggi pubblicati e che potrebbero intressarti.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 3,
                    'domanda' => "Catalogo",
                    'risposta' => "<p>Se vuoi sapere di più su quanto potrai trovare in MyUiniRent, il Catalogo è il posto giusto.</p>"
                    . "<p>Tutti gli alloggi presenti in archivo sono mostrati con le loro caratteristiche principali. Potrai anche notare la presenza di "
                    . "'Success Stories', ovvero alloggi che hanno già trovato un nuovo e soddisfatto inquilino.</p>"
                    . "<p>Non perdere tempo, registrati. Ti stiamo aspettando.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 3,
                    'domanda' => "Faq",
                    'risposta' => "Per le Faq non credo tu abbia bisogno di particolare aiuto. Le stai già utilizzando."]);

        // Cosa può fare il locatore
        DB::table('faq')->insert(
                ['categoria_id' => 4,
                    'domanda' => "I tuoi Alloggi",
                    'risposta' => "<p>I locatori poranno gestire in questa sezione gli alloggi che intendono affittare agli studenti.<br>"
                    . "Per rendere tale attività ancora più semplice MyUniRent ti permette di creare delle <i>Bozze</i>. "
                    . "Solo tu vedrai le informazioni degli Alloggi in Bozza e quando sarai sicuro che tutto sia come desideri, con un semplice click "
                    . "pubblicherai l'annuncio e da quel momento il tuo alloggio sarà visibile nel Catalogo e disponibile per la Ricerca.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 4,
                    'domanda' => "Chat Attive",
                    'risposta' => "<p>Puoi trovare qui l'elenco di tutte le tue Chat associate ad alloggi per cui hai ricevuto almeno un contatto e che non hai ancora assegnato.</p>"
                    . "<p>Sarà questa la dashboard che ti permetterà di non perdere nesssuna possibilità di Business.</p>"
                    . "<p>Abbiamo realizzato per te un'interfacia grafica che, a colpo d'occhio, ti permette di conoscere, per ogni alloggio, "
                    . "quante richieste di informazioni e quante opzioni hai ricevuto.</p>"
                    . "<p>Entrando nel dettaglio di una Chat accederai alle informazioni specifiche degli studenti interessati."
                    . "Con un semplice click potrai assegnare l'Aloggio a chi ne ha fatto opzione e MyUniRent, in automatico, si farà carico di comunicare all'assegnatario "
                    . "tale informazione e invierà un messaggio di rifiuto a tutti gli altri partecipant della Chat.</p>"
                    . "<p>Per aiutarti nello svolgimento delle formalità amministrative MyUniRent gestisce anche la Stampa del Contratto di Locazione, dove "
                    . "sono riportate, oltre alla data e al luogo del contratto, tutte le informazioni relative all'alloggio ceduto in locazione, "
                    . "al locatore e al locatario, predisponendo anche gli spazi per raccogliere le firme olografe dei contraenti.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 4,
                    'domanda' => "Chat Archiviate",
                    'risposta' => "<p>Puoi trovare qui la storia completa degli alloggi che hai già assegnato o eliminato dal sistema.</p>"
                    . "<p>Anche se l'alloggio in questione è stato già assegnato potrai continuare a parlare con chi ha manifestato un interesse per questo.<br>"
                    . "'Chat Archiviate' è anche lo strumento per rimanere in contatto con gli assegnatari dei tuoi alloggi.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 4,
                    'domanda' => "Profilo",
                    'risposta' => "Qui hai la possibilità di modificare i dati del tuo profilo, in modo che le informazioni che ti riguardano siano sempre aggiornate."]);

        DB::table('faq')->insert(
                ['categoria_id' => 4,
                    'domanda' => "Logout",
                    'risposta' => "E' stato un piacere trascorrere del tempo con te. A presto!"]);
        
        DB::table('faq')->insert(
                ['categoria_id' => 4,
                    'domanda' => "Cosa è una bozza?",
                    'risposta' => "<p>La bozza è lo strumento che ti permette di 'riflettere' su qunto hai scritto.</p>"
                    . "<p>E' come l'annuncio di un alloggio da affittare ma è visibile solo a te. Puoi modificarla quante "
                    . "volte vuoi e, quando pensi sia perfetta, puoi pubblicarla con il pulsante 'Pubblica Alloggio'.</p>"]);
        
        DB::table('faq')->insert(
                ['categoria_id' => 4,
                    'domanda' => "Che differenza c’è tra la bozza e la pubblicazione di un alloggio?",
                    'risposta' => "Solo tu vedrai le informazioni degli Alloggi in Bozza, la pubblicazione li rende visibili a tutti."]);
        
        

        // Cosa può fare il locatario
        DB::table('faq')->insert(
                ['categoria_id' => 5,
                    'domanda' => "Cerca un Alloggio",
                    'risposta' => "<p>Se sei giunto fino a qui è chiaro che hai la necessità di trovare il miglor luogo possibile per trascorrere le tue "
                    . "gionate da universitario. MyUniRent ti aiuterà a cercare l'alloggio che possa soddisfare al meglio le tue esigenze, offrendoti la "
                    . "possibilità di selezionare gli annunci per tipologia dell'alloggio, caratteristiche e servizi offerti.</p> <p>Se il mix di servizi che "
                    . "ricerchi per l'alloggio dei tuoi sogni sembra non fornire alcun risultato, non ti preoccupare, attivando la funzione 'Smart Search' "
                    . "il sistema ti mostrerà gli alloggi che soddisfano anche solo un sottinsieme delle tue richieste ordinando i risultati per quantità"
                    . "di richieste soddisfatte. Infatti, i primi alloggi a comparire saranno il più possibile vicini alle tue esigenze, mentre i successivi saranno "
                    . "via via meno aderenti a quanto da te specificato, con l'indicazione del 'cosa manca' per ciascuna soluzione proposta.</p>"
                    . "<p>Selezionando l'alloggio che ti interessa puoi aprire una conversazione a riguardo con il locatore e, se ritieni che "
                    . "questo sia proprio 'quello giusto', non esitare ad opzionarlo, il sistema informerà il proprietario delle tue intenzioni.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 5,
                    'domanda' => "Le tue Opzioni",
                    'risposta' => "Puoi trovare qui tutte le tue opzioni con il loro stato e puoi controllarle ogni volta che vuoi. In ogni caso, "
                    . "se hai necessità di comunicare con il locatore, selezionando l'opzione che ti interessa, accederai alla Chat associata."]);

        DB::table('faq')->insert(
                ['categoria_id' => 5,
                    'domanda' => "Le tue Chat",
                    'risposta' => "<p>Da questa sezione hai accesso a tutte le Chat associate ad alloggi per i quali hai già chiesto informazioni o "
                    . "fatto opzioni, indipendentemente dal fatto che questi siano ancora disponibili, assegnati ad altri, a te o cancellati.</p>"
                    . "<p>Per comprendere la situazione con un solo sguardo, ti verranno in aiuto le apposite icone che rappresentano i diversi stati "
                    . "di avanzamento.</p>"]);

        DB::table('faq')->insert(
                ['categoria_id' => 5,
                    'domanda' => "Profilo",
                    'risposta' => "Qui hai la possibilità di modificare i dati del tuo profilo, in modo che le informazioni che ti riguardano siano sempre aggiornate."]);

        DB::table('faq')->insert(
                ['categoria_id' => 5,
                    'domanda' => "Logout",
                    'risposta' => "E' stato un piacere trascorrere del tempo con te. A presto!"]);
        
        DB::table('faq')->insert(
                ['categoria_id' => 5,
                    'domanda' => "Posso annullare un’opzione?",
                    'risposta' => "<p>Non è possibile annullare un’opzione ma, attraverso la chat, "
                    . "puoi inviare un messaggio al locatore proprietario dell’alloggio per segnalare il disguido.</p>"
                    . "<p>Sicuramente comprenderà!</p>"]);

        // Amministrazione del sito
        DB::table('faq')->insert(
                ['categoria_id' => 6,
                    'domanda' => "Statistiche",
                    'risposta' => "<p>In qualità di Amministratore potrai controllare le attività di MyUniRent selezionando una tipologia di alloggio "
                    . "e/o un periodo temporale di interesse. Il sistema, in maniera chiara e reattiva, ti presenterà i risultati dell'elaborazione, "
                    . "sia in forma testuale che grafica.</p>"
                    . "In particolare vengono mostrati quanti alloggi pubblicati ci sono nel periodo e della tipologia selezionati, "
                    . "quanti di questi sono stati opzionati e quanti invece assegnati."]);

        DB::table('faq')->insert(
                ['categoria_id' => 6,
                    'domanda' => "Gestione Faq",
                    'risposta' => "Tutti gli utenti di MyUniRent e i responsabili del sito ringraziano l'Amministratore per aver utilizzato questa "
                    . "funzione, che gli ha permesso di inserire, modificare (e a volte cancellare) le utili informazioni presenti nella sezione FAQ."]);

        DB::table('faq')->insert(
                ['categoria_id' => 6,
                    'domanda' => "Logout",
                    'risposta' => "E' stato un piacere trascorrere del tempo con te. A presto!"]);

        // Varie
        DB::table('faq')->insert(
                ['categoria_id' => 7,
                    'domanda' => "Ringraziamenti",
                    'risposta' => "<p>I principali <i>personaggi</i> di questo applicativo web sono: i linguaggi HTML, CSS, PHP e JavaScript; il DBMS MySQL; il FrameWork Web Laravel; "
                    . "il Web Server Apache; la libreria JQuery.</p>"
                    . "<p>Senza di loro, la vita degli sviluppatori sarebbe stata molto più complicata.</p>"]);
    }

}
