<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            // quelli richiesti per la presentazione
            [
                'name' => 'Luigi',
                'surname' => 'Pino',
                'email' => 'luigi@pino.it',
                'username' => 'lorelore',
                'password' => Hash::make('3yj55TK5'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '1967-03-20',
                'tipo'=>'Locatore'
                ],
            [
                'name' => 'Franco',
                'surname' => 'Abete',
                'email' => 'franco@abete.it',
                'username' => 'lariolario',
                'password' => Hash::make('3yj55TK5'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '2001-03-20',
                'tipo'=>'Locatario'
                ],
            [
                'name' => 'Giulio',
                'surname' => 'Ciliegia',
                'email' => 'giulio@ciliegia.it',
                'username' => 'adminadmin',
                'password' => Hash::make('3yj55TK5'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '1970-03-20',
                'tipo'=>'Amministratore'
                ],
            [
                'name' => 'Marco',
                'surname' => 'Bianchi',
                'email' => 'marco@bianchi.it',
                'username' => 'lariolario1',
                'password' => Hash::make('3yj55TK5'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '1999-05-25',
                'tipo'=>'Locatario'
                ],
            [
                'name' => 'Alex',
                'surname' => 'Verdi',
                'email' => 'alex@verdi.it',
                'username' => 'lorelore1',
                'password' => Hash::make('3yj55TK5'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '1959-03-20',
                'tipo'=>'Locatore'
                ],
            
            
            
            /*
            
            // utenti interni di test
            
            
            
            
            [
                'name' => 'Matti',
                'surname' => 'Gialli',
                'email' => 'matti@gialli.it',
                'username' => 'mattimatti',
                'password' => Hash::make('mattimatti'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '2000-10-31',
                'tipo'=>'Locatore'
                ],
            
            ['name' => 'Donatella',
                'surname' => 'Viola',
                'email' => 'dona@viola.it',
                'username' => 'donadona',
                'password' => Hash::make('donadona'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '2000-11-26',
                'tipo'=>'Locatario'
                ],
            
            ['name' => 'Mario',
                'surname' => 'Rossi',
                'email' => 'mario@rossi.it',
                'username' => 'adminadmin1',
                'password' => Hash::make('adminadmin'),
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'data_nascita' => '1959-03-20',
                'tipo'=>'Amministratore'
                ],
            */
            
            
        ]);
    }
}
