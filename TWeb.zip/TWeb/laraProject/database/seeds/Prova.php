<?php

use Illuminate\Database\Seeder;
use App\User;

class Prova extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*
        $user = User::find(3);
        $currentDate = date("Y-m-d");
        $eta_locatario = date_diff(date_create($user->data_nascita), date_create($currentDate))->y;
        print ($eta_locatario);
         * 
         */
        
        //print (route('register'));
        $alloggio = App\Models\Resources\Alloggio::Find(3);
        print ($alloggio['data_ora_pubblicazione']);
         

    }
}
