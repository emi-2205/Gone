<?php

namespace App\Models;

use App\User;
use App\Models\Resources\Alloggio;
use App\Models\Resources\Azione;
use App\Models\Resources\Chat;
use App\Models\EnumHelpers\EH;

class AlloggioAppModel {

    protected $_opzioni = [
        'internet',
        'cucina',
        'locale_ricreativo',
        'angolo_studio',
        'televisione',
        'lavatrice',
        'posto_bici',
    ];
    protected $_legenda = [
        'internet' => 'Internet',
        'cucina' => 'Uso cucina',
        'locale_ricreativo' => 'Locale ricreativo',
        'angolo_studio' => 'Angolo studio',
        'televisione' => 'Televisione',
        'lavatrice' => 'Lavatrice',
        'posto_bici' => 'Posto bici',
    ];

    public static function isOpzionabile($user, $alloggio) {

        if ($alloggio->stato == 'Assegnato') {
            // l'alloggio non è opzionabile se già assegnato
            return false;
        } else {
            $opzioni = Azione::where('locatario_id', $user->id)
                    ->where('chat_id', $alloggio->chat_id)
                    ->where('tipo', 'Opzione')
                    ->count();
            return $opzioni == 0; // o se il locatario lo ha già opzionato una volta
        }
    }

    // ritorno tutti gli alloggi del locatore collegato ordinati per nome
    public function getAlloggilLocatore($nome_alloggio = null) {
        //identifico il locatore attualmente loggato
        $locatore = auth()->user();
        if (is_null($nome_alloggio)) {
            //tiro su tutti gli alloggi di locatore, li metto in ordine alfabetico e ne metto 5 per pagina
            $alloggi = Alloggio::where('proprietario_id', '=', $locatore->id)
                            ->orderBy('nome')->paginate(5);
                            //paginate è un metodo della componente Paginator che si applica al risultato della query 
                            //per incapsulare gli oggetti e organizzarli in pagine
        }
        return $alloggi;
    }

    public function newChat() {
        // creazione di una nuova chat
        return new Chat;
    }

    public function getChat($id) {
        // ricerca di una chat per id
        return Chat::findOrFail($id);
    }

    public function newAlloggio() {
        // creazione di un nuovo alloggio
        return new Alloggio;
    }

    // mi tira su un alloggio per id
    public function getAlloggio($id) {
        // ricerca di un alloggio per id
        return Alloggio::findOrFail($id); //se la query non produce alcun risultato viene lanciata un'eccezione anziché andare in errore
    }

    public function getUser($id) {
        // ricerca din un utente per id
        return User::findOrFail($id);
    }

    public function getStatoList() {
        // utilizzo l'helper per ritornare l'enum dei possibili stati di un alloggio
        return EH::getPossibleEnumValues('alloggio', 'stato');
    }

    public function getTipologiaList() {
        // utilizzo l'helper per ritornare l'enum delle possibili tipologie di un alloggio
        return EH::getPossibleEnumValues('alloggio', 'tipologia');
    }

    public function getGenereList() {
        // utilizzo l'helper per ritornare l'enum dei possibili generi accettati per i potenziali locatari
        return EH::getPossibleEnumValues('alloggio', 'genere');
    }

    //fa una lista delle opzioni/seriviz che quell'alloggio non presenta rispetto alla richiesta iniziale
    private function cosaManca($alloggio, $originalRequest) {
        $manca = [];
        foreach ($this->_opzioni as $opzione) {
            // se la caratteristca opzionale è presente nella richiesta originale ma non nell'alloggio
            if (!empty($originalRequest[$opzione]) && !$alloggio[$opzione]) {
                // allora la indico come una mancanza
                $manca[] = $opzione;
            }
        }
        return $manca;
    }

    private function filterReduction(&$alloggi, &$query_param, $key, &$statusList, $originalRequest) {
        //Se presente, tolgo il criterio specificato ed eseguo una nuova ricerca
        if (!empty($query_param[$key])) {
            //elimino da query_param la l'elemento con chiave $key
            //tolgo cioè un filtro
            unset($query_param[$key]);
            //rifaccio la search senza il filtro
            $alloggi_tmp = $this->ricercaAlloggiSpecial($query_param)->get();
            foreach ($alloggi_tmp as $elem) {
                //per ogni elemento controllo se sta anche in $alloggi
                if (!$alloggi->contains($elem)) {
                    //quando becco un elemento che non sta in alloggi guardo quali servizi gli mancano (es.internet)
                    //statusList è un array associativo con nome id dell'alloggio mancante e valore la lista dei servizi mancanti rispetto alla richiesta originale
                    $statusList[$elem->id] = $this->cosaManca($elem, $originalRequest);
                    // la costruzione dello score adottata permette un facile ordinamento della collezione
                    // degli alloggi selezionati per punteggio e data_ora_pubblicazione in modo decrescente

                    //per ogni servizio mancante tolto un punto allo score
                    $elem['score'] = (9 - count($statusList[$elem->id])) . '|' . $elem->data_ora_pubblicazione;
                    //faccio l'append di questi alloggi extra alla collection iniziale
                    $alloggi->push($elem);
                }
            }
        }
    }

    public function ricercaAlloggi($request) {
        $statusList = [];
        // estraggo in un array associativo i criteri di ricerca presenti nella request
        $query_param = $request->all();
        $original_request = $query_param;
        // Eseguo la ricerca rispettando tutti i criteri specificati dall'utente
        $alloggi = $this->ricercaAlloggiSpecial($query_param)->get();
        // aggiungo lo score di default
        foreach ($alloggi as $alloggio) {
            // la costruzione dello score adottata permette un facile ordinamento della collezione
            // degli alloggi selezionati per punteggio e data_ora_pubblicazione in modo decrescente
            $alloggio['score'] = '9|' . $alloggio->data_ora_pubblicazione;
        }

        // Se richiesto eseguo le ricerche con la filterReduction (modalità SmartSearch)
        if (!empty($query_param['smart'])) {
            $this->filterReduction($alloggi, $query_param, 'internet', $statusList, $original_request);
            if ($query_param['tipologia'] == 'Appartamento') {   // Per appartamento...
                $this->filterReduction($alloggi, $query_param, 'cucina', $statusList, $original_request);
                $this->filterReduction($alloggi, $query_param, 'locale_ricreativo', $statusList, $original_request);
            } else if ($query_param['tipologia'] == 'Posto Letto') { // Per posto letto...
                $this->filterReduction($alloggi, $query_param, 'angolo_studio', $statusList, $original_request);
                $this->filterReduction($alloggi, $query_param, 'televisione', $statusList, $original_request);
                $this->filterReduction($alloggi, $query_param, 'lavatrice', $statusList, $original_request);
                $this->filterReduction($alloggi, $query_param, 'posto_bici', $statusList, $original_request);
            }
        }
        //ritorno gli alloggi ordinati per score e data_pubblicazione e li impagino ogni 3 elementi, ritorno anche la lista dei servizi mancanti per ogni alloggio extra
        return [
            'alloggi' => ($alloggi)->sortByDesc('score')->paginate(3),
            'statusList' => $statusList
        ];
    }

    private function ricercaAlloggiSpecial($my_request) {

        //La base della ricerca è costituita da tutti gli alloggi
        //in stato di Pubblicato o Assegnato
        $alloggi = Alloggio::where(function ($query) {
                    $query->where('stato', 'Pubblicato')
                            ->orWhere('stato', 'Assegnato');
                });
        // selezione dipendentemente dai dati presenti nel profilo del locatario
        $genere_utente = auth()->user()->genere;
        //Dipendentemente dai vincoli di genere specificati per l'alloggio e dal
        //genere del locatario collegato eseguo le opportune ricerche

        if ($genere_utente == 'Non assegnato') {
            // il locatario non ha specificato il proprio genere:
            // seleziono solo gli alloggi in cui il locatore non ha specificato preferenze di genere
            $alloggi->where('genere', 'Non assegnato');
        } else {
            // il locatario ha specificato il proprio genere:
            // seleziono gli alloggi in cui il locatore non ha specificato preferenze di genere
            // e quelli in cui la specifica coincide con quella del locatario
            $alloggi->where(function ($query) use ($genere_utente) {
                //tira su gli allogi che hanno genere= Non assegnato oppure genere= $genere_utente
                $query->where('genere', 'Non assegnato')
                        ->orWhere('genere', $genere_utente);
            });
        }


        // ricerca per età del locatario
        $currentDate = date("Y-m-d");
        //differenza in anni tra la data attuale e la data di nascita del locatario
        $eta_locatario = date_diff(date_create(auth()->user()->data_nascita), date_create($currentDate))->y;
        $alloggi->where('eta_min', '<=', $eta_locatario)
                ->where('eta_max', '>=', $eta_locatario);

        //Se indicato seleziono gli alloggi localizzati nella città specificata
        if (!empty($my_request['citta'])) {
            $alloggi->where('citta', 'like', '%' . $my_request['citta'] . '%');
        }

        //Dipendentemente dal fatto che siano indicate o meno
        //Seleziono gli alloggi il cui canone di affitto rientra nella fascia di prezzo specificata
        $prezzo_min = (!empty($my_request['prezzo_min']) ? $my_request['prezzo_min'] : 0);
        $prezzo_max = (!empty($my_request['prezzo_max']) ? $my_request['prezzo_max'] : 9999.99);
        $alloggi->whereBetween('canone_affitto', [$prezzo_min, $prezzo_max]);

        //Dipendentemente dal fatto che siano indicate o meno
        //Seleziono ulteriormente gli alloggi in base alle disponibilità temporali
        if (!empty($my_request['data_inizio_locazione'])) {
            $alloggi->where('data_inizio_locazione', '<=', date($my_request['data_inizio_locazione']))
                    ->where('data_fine_locazione', '>=', date($my_request['data_inizio_locazione']));
        }

        if (!empty($my_request['data_fine_locazione'])) {
            $alloggi->where('data_inizio_locazione', '<=', date($my_request['data_fine_locazione']))
                    ->where('data_fine_locazione', '>=', date($my_request['data_fine_locazione']));
        }

        //Se indicato seleziono in base al numero di letti
        if (!empty($my_request['num_letti_tot'])) {
            $alloggi->where('num_letti_tot', $my_request['num_letti_tot']);
        }

        //Se richiesto controllo la disponibilità della connessione ad Internet
        if (!empty($my_request['internet'])) {
            $alloggi->where('internet', true);
        }

        //Selezioni ulteriori condizionate alla tipologia di alloggio selezionata

        if ($my_request['tipologia'] == 'Appartamento') {   // Per appartamento...
            //Seleziono gli appartamenti
            $alloggi->where('tipologia', 'Appartamento');
            //Se inserito seleziono in base al numero di camere
            if (!empty($my_request['num_camere'])) {
                $alloggi->where('num_camere', $my_request['num_camere']);
            }
            //Se richiesto controllo la disponibilità della cucina
            if (!empty($my_request['cucina'])) {
                $alloggi->where('cucina', true);
            }
            //Se richiesto controllo la disponibilità di locale ricreativo
            if (!empty($my_request['locale_ricreativo'])) {
                $alloggi->where('locale_ricreativo', true);
            }
        } else if ($my_request['tipologia'] == 'Posto Letto') { // Per posto letto...
            //Seleziono i Posti Letto
            $alloggi->where('tipologia', 'Posto letto');
            //Se inserito seleziono per numero di posti letto nella camera
            if (!empty($my_request['num_letti_camera'])) {
                $alloggi->where('num_letti_camera', $my_request['num_letti_camera']);
            }
            //Se richiesto controllo la disponibilità di angolo studio
            if (!empty($my_request['angolo_studio'])) {
                $alloggi->where('angolo_studio', true);
            }
            //Se richiesto controllo la disponibilità della televisione
            if (!empty($my_request['televisione'])) {
                $alloggi->where('televisione', true);
            }
            //Se richiesto controllo la disponibilità della lavatrice
            if (!empty($my_request['lavatrice'])) {
                $alloggi->where('lavatrice', true);
            }
            //Se richiesto controllo la disponibilità del posto bici
            if (!empty($my_request['posto_bici'])) {
                $alloggi->where('posto_bici', true);
            }
        }

        $alloggi->orderBy('data_ora_pubblicazione', 'desc');

        return $alloggi;
    }

    public function storeImage($alloggio, $image) {
        // il pattern per la costruzione del nome del file dell'immagine è foto<idAlloggio>.<estensione>
        $extension = $image->extension(); //estensione estrapolata dall'apposito Helper di Laravel analizzando il contenuto del file stesso
        $alloggio->immagine = 'foto' . $alloggio->id . '.' . $extension;
        $destinationPath = public_path() . '/images/anteprime';
        // move() sposta il file $image con nome $alloggio->immagine in $destinationPath
        $image->move($destinationPath, $alloggio->immagine);
    }

    public function isProprietario($user, $alloggio) {
        if ($alloggio->proprietario_id != $user->id) {
            // alloggio non di pertinenza dell'utente indicato
            // l'errore 403 viene lanciato quando un server ti proibisce di accedere ad una risorsa, come in questo caso
            abort(403, 'Non sei il proprietario di questo alloggio');
        }
    }

    public function eliminaAlloggio($id) {
        $alloggio = $this->getAlloggio($id);
        $this->isProprietario(auth()->user(), $alloggio);
        // posso procedere se il locatore autenticato è il proprietaro dell'alloggio che si desidera cancellare
        $chat = $this->getChat($alloggio->chat_id);
        //disattivo la sua chat, la chat mi serve per preservare tutte le interazioni associate all'alloggio (es. i messaggi) nonostante l'alloggio venga rimosso
        $chat->is_active = false;
        $chat->save();

        // se esiste deve essere cancellata l'immagine associata all'alloggio
        if (!is_null($alloggio->immagine)) {
            $imagePath = public_path() . '/images/anteprime/' . $alloggio->immagine;
            if (file_exists($imagePath)) {
                //dato il path come parametro elimina il file associato
                unlink($imagePath);
            }
        }
        //elimino l'alloggio
        $alloggio->delete();
    }

}
