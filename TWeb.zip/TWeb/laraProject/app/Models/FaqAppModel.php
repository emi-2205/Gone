<?php

namespace App\Models;

use App\Models\Resources\Categoria;
use App\Models\Resources\Faq;

class FaqAppModel {

    public function newFaq() {
        // creazione di una nuova Faq
        return new Faq;
    }

    public function getCategorie() {
        return Categoria::all();
    }

    public function getFaqsByCat($id, $paged = 1) {
        $faqs = Faq::where('categoria_id', $id);
        $faqs->orderBy('id');
        return $faqs->paginate($paged);
    }

    public function getFaqsById($id) {
        return Faq::findOrFail($id);
    }

}
