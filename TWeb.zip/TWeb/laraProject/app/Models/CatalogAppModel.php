<?php

namespace App\Models;


use App\Models\Resources\Alloggio;

class CatalogAppModel {

    // ricerca degli alloggi da presentare nel catalogo generale o nel carousel
    public function getCatalogoAlloggi($limit = null, $solo_pubblicati = false) {
        if($solo_pubblicati) {
            $alloggi = Alloggio::where('stato', 'Pubblicato'); //Tira su tutti gli alloggi Pubblicati, da presentare nel carousel
        } else {
            $alloggi = Alloggio::where('stato', '!=', 'Bozza'); //tutti gli alloggi Pubblicati o Assegnati da presentare nel catalogo generale
        }
        $alloggi = $alloggi->orderBy('data_ora_pubblicazione', 'desc');

        if (!is_null($limit)) {
            return $alloggi->take($limit)->get();
        } else {
            return $alloggi->paginate(3);
        }
    }
}
