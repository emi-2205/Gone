<?php

namespace App\Models\EnumHelpers;

use Illuminate\Support\Facades\DB;

class EH
{
    public static function getPossibleEnumValues($table, $column) 
    {    
        // Pulls column string from DB
        // tiro su tutti i valori che un attributo può assumere in una tabella
        $enumStr = DB::select(DB::raw('SHOW COLUMNS FROM '.$table.' WHERE Field = "'.$column.'"'))[0]->Type;
    
        // Parse string
        preg_match_all("/'([^']+)'/", $enumStr, $matches);
    
        // Return matches
        $preproc_array = isset($matches[1]) ? $matches[1] : [];
        
        
        $postproc_array = array();
        foreach($preproc_array as &$value)
        {
            $postproc_array[$value] = $value;
        }

        return $postproc_array;
    }
}