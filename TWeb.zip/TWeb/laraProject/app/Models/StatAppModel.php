<?php

namespace App\Models;

use App\Models\Resources\Chat;
use App\Models\Resources\Alloggio;
use App\Models\Resources\Azione;


class StatAppModel {

    public function countAlloggi($tipologia, $start_date, $end_date) {
        // conteggio degli allgggi
        $found = Alloggio::where('stato', '!=', 'Bozza'); // si parte da tutti quelli non in stato di Bozza
        if (!is_null($start_date)) {
            //dopo start_date
            $found->where('data_ora_pubblicazione', '>=', date($start_date));
        }
        if (!is_null($end_date)) {
            // prima di end_date
            $found->where('data_ora_pubblicazione', '<=', date($end_date));
        }
        // filtro per tipologia
        if ($tipologia != 'Qualsiasi') {
            $found->where('tipologia', $tipologia);
        }
        return $found->get()->count();
    }

    public function countAzioni($tipologia, $start_date, $end_date, $tipoAzione) {
        $found = Azione::where('tipo', $tipoAzione); // si parte dal tipo di azione selezionata (Opzione, Assegnamento)
        if (!is_null($start_date)) {
            //dopo start_date
            $found->where('data_ora_invio', '>=', date($start_date));
        }
        if (!is_null($end_date)) {
            // prima di end_date
            $found->where('data_ora_invio', '<=', date($end_date));
        }
        // filtro per tipologia
        if ($tipologia != 'Qualsiasi') {
            $found->whereHas('chat', function ($query) use ($tipologia) {
                $query->where('tipologia', $tipologia);
            });
        }
        return $found->get()->count();
    }

}
