<?php

namespace App\Models;

use App\Models\Resources\Chat;
use App\Models\Resources\Alloggio;
use App\User;
use App\Models\Resources\Azione;
use Illuminate\Database\Eloquent\Builder;

class ChatAppModel {

    public function newAzione() {
        // creazione di una nuova Azione
        return new Azione;
    }

    public function getChat($chat_id, $locatario_id = null) {
        // il comportamento è diverso se la ricerca vine fatta da un utente di tipo locatario o locatore
        if (is_null($locatario_id)) {
            // ramo eseguito se l'utente corrente è il locatario
            $locatario = auth()->user();
            $chat = Chat::findOrFail($chat_id);
        } else {
            // ramo eseguito se l'utente corrente è il locatore
            $locatario = User::findOrFail($locatario_id);
            $chat = Chat::where('id', $chat_id)->where('responsabile_id', auth()->user()->id)->firstOrFail();
        }
        // ricerche eseguite sia nel caso di locatore che di locatario
        // il controllo sul fatto che l'oggetto chat sia nullo è un eccesso di sicurezza
        // infatti se non viene trovata la chat, sia per il locatario che per il locatore,
        // si ha un fail del sistema gestito dal framework
        if (!is_null($chat)) {
            $alloggio = Alloggio::where('chat_id', $chat_id)->first();
            $locatore = User::find($chat->responsabile_id);
            $messaggi = Azione::where('chat_id', $chat_id)
                            ->where('locatario_id', $locatario->id)
                            //->get()->sortByDesc('id');
                            ->orderBy('id', 'desc')->paginate(6);
            $num_messaggi = Azione::where('chat_id', $chat_id)
                    ->where('locatario_id', $locatario->id)
                    ->count();
            $opzione = Azione::where('chat_id', $chat_id)
                    ->where('locatario_id', $locatario->id)
                    ->where('tipo', 'Opzione')
                    ->first();
            $assegnamento = Azione::where('chat_id', $chat_id)
                    ->where('locatario_id', $locatario->id)
                    ->where('tipo', 'Assegnamento')
                    ->first();
            $rifiuto = Azione::where('chat_id', $chat_id)
                    ->where('locatario_id', $locatario->id)
                    ->where('tipo', 'Rifiuto')
                    ->first();
        } else {
            // grazie alle condizioni di tipo "OrFail" questo ramo else non verrà mai eseguito
            // ma viene lasciato ugualmente, in memoria di come era la logica in passato
            $locatario = null;
            $chat = null;
            $alloggio = null;
            $locatore = null;
            $messaggi = null;
            $num_messaggi = null;
            $opzione = null;
            $assegnamento = null;
            $rifiuto = null;
        }

        return [
            'locatario' => $locatario,
            'chat' => $chat,
            'alloggio' => $alloggio,
            'locatore' => $locatore,
            'messaggi' => $messaggi,
            'num_messaggi' => $num_messaggi,
            'opzione' => $opzione,
            'assegnamento' => $assegnamento,
            'rifiuto' => $rifiuto,
        ];
    }

    // sezione per la gestione del locatario
    
    public function listaChatLocatario() {
        // ricerca le chat a cui partecipa il locatario autenticato ordinate per descrizione
        $chats = Chat::whereHas('azione', function (Builder $query) {
            //tira su le cheat connesse a delle azioni il cui locatario id è quello dell'attuale locatario
                    $query->where('locatario_id', auth()->user()->id);
                })->with('alloggio')
                ->get()
                ->sortBy('descrizione');

        // contestualmente alla chat del locatario viene costruito un array associativo
        // che collega la chat al suo stato, relativamente al locatario autenticato
        $chat_status = [];
        foreach ($chats as $chat) {
            $chat_status[$chat->id] = $this->getChatStatus($chat->id, auth()->user()->id);
        }

        return ['chats' => $chats,
            'chat_status' => $chat_status];
    }

    public function listaOpzioniLocatario() {
        // ricerca le chat a cui partecipa il locatario autenticato e che contengono un messaggio di tipo 'Opzione'
        $chats = Chat::whereHas('azione', function (Builder $query) {
                    $query->where('locatario_id', auth()->user()->id)
                    ->where('tipo', 'Opzione');
                //di tutte le chat tirate su mi va a prendere anche gli alloggi associati
                })->with('alloggio')

                ->get()
                ->sortBy('descrizione');

        //dump($chats);

        // contestualmete alla chat del locatario viene costruito un array associativo
        // che collega la chat al suo stato, relativamente al locatario autenticato
        $chat_status = [];
        foreach ($chats as $chat) {
            //per ogni chat ne prendo l'iconcina associata allo stato in base alle azioni che contiene
            $chat_status[$chat->id] = $this->getChatStatus($chat->id, auth()->user()->id);
        }

        return ['chats' => $chats,
            'chat_status' => $chat_status];
    }

    // sezione per la gestione del locatore

    public function listaChatLocatore($chat_id = null, $is_active = true) {
        $locatore = auth()->user();

        //se non viene passato alcun chat_id
        if (is_null($chat_id)) {
            // Primo livello: cerco tutte le chat del locatore che hanno avuto almeno un contatto
            $chats = Chat::where('responsabile_id', $locatore->id)
                            ->where('is_active', $is_active) // con lo stato passato come parametro
                            ->has('azione') //tutte lechat collegate ad almeno un'azione
                            ->get()->sortByDesc('data_ora_ultimo_contatto');
            // costruzione di un array associativo con chaive chat->id e valore numero di locatari
            // che hanno contattato la chat e opzionato l'alloggio relativo alla chat stessa
            $num_contatti = [];
            $num_opzioni = [];
            foreach ($chats as $chat) {
                $tot_contatti = Azione::where('chat_id', $chat->id)
                        ->distinct('locatario_id')
                        ->count();
                $num_contatti[$chat->id] = $tot_contatti;
                $tot_opzioni = Azione::where('chat_id', $chat->id)
                        ->where('tipo', 'Opzione')
                        ->distinct('locatario_id')
                        ->count();
                $num_opzioni[$chat->id] = $tot_opzioni;
            }

            return ['chats' => $chats,
                'num_contatti' => $num_contatti,
                'num_opzioni' => $num_opzioni];
        } else {
            //se ho specificato un chat_id
            // Secondo livello: cerco della chat selezionata tutti i locatari che la hanno contattata
            $azioni = Azione::where('chat_id', $chat_id)
                    ->with('locatario')
                    ->distinct()
                    ->get('locatario_id');
            
            // costruzione di un array associativo che indica lo stato della chat selezionata
            // per il particolare locatario ad essa collegato
            $locatari_status = [];
            foreach ($azioni as $azione) {
                //per ogni chat ne prendo l'iconcina associata allo stato in base alle azioni che contiene
                $locatari_status[$azione->locatario_id] = $this->getChatStatus($chat_id, $azione->locatario_id);
            }
            $alloggio = Alloggio::where('chat_id', $chat_id)->first();

            return ['azioni' => $azioni,
                'locatari_status' => $locatari_status,
                'alloggio' => $alloggio];
        }
    }

    public function updateChatDataOoraUltimoContatto($chat_id) {
        // aggiornamento della data e ora di ultimo contatto della chat movimentata
        $chat = Chat::findOrFail($chat_id); // eccesso di zelo dato che tale funzione viene chiamata solo da metodi interni del back-end
        $chat->data_ora_ultimo_contatto = now();
        $chat->save();
    }

    public function getLocatariAssociati($chat_id) {
        // seleziona tutti i locatari che hanno scambito un messaggi (Azione) con la chat selezionata
        $locatari_associati = Azione::where('chat_id', $chat_id)
                ->distinct()
                ->get('locatario_id');
        return $locatari_associati;
    }

    public function blacklistRifiuto($chat_id, $locatario_id) {
        // business logic che dispensa in automatico una Azione (messaggio) di rifiuto a tutti i locatari a cui l'alloggio
        // non è stato assegnato, con relativo cambio di stato della chat e dell'alloggio
        $chat = Chat::findOrFail($chat_id);
        $chat->is_active = false;
        $chat->save();

        $alloggio = Alloggio::where('chat_id', $chat_id)->firstOrFail();
        $alloggio->stato = 'Assegnato';
        $alloggio->assegnatario_id = $locatario_id;
        $alloggio->data_ora_assegnazione = now();
        $alloggio->save();

        $blackList = $this->getLocatariAssociati($chat_id);
        foreach ($blackList as $elem) {
            if ($elem->locatario_id != $locatario_id) {
                $msg = new Azione;
                $msg->locatario_id = $elem->locatario_id;
                $msg->chat_id = $chat_id;
                $msg->tipo = 'Rifiuto';
                $msg->testo = "L'alloggio è stato assegnato ad altro Locatario";
                $msg->save();
            }
        }
    }

    public function getChatStatus($chat_id, $locatario_id) {
        // metodo helper che ritorna lo stato della chat per il locatario indicato
        // permettendo la gestione dell'interfaccia grafica (scelta delle icone da presentare)
        $hasOpzione = (Azione::where('chat_id', $chat_id)->where('locatario_id', $locatario_id)->where('tipo', 'Opzione')->count() != 0);
        $hasAssegnamento = (Azione::where('chat_id', $chat_id)->where('locatario_id', $locatario_id)->where('tipo', 'Assegnamento')->count() != 0);
        $hasRifiuto = (Azione::where('chat_id', $chat_id)->where('locatario_id', $locatario_id)->where('tipo', 'Rifiuto')->count() != 0);

        if (!$hasOpzione && !$hasAssegnamento && !$hasRifiuto) {
            $retu = 'fa fa-comments fa-2x';
        } elseif ($hasOpzione && !$hasAssegnamento && !$hasRifiuto) {
            $retu = 'fa fa-paper-plane fa-2x';
        } elseif ($hasAssegnamento) {
            $retu = 'fa fa-check fa-2x';
        } elseif ($hasRifiuto) {
            $retu = 'fa fa-times fa-2x';
        }
        return $retu;
    }

}
