<?php

namespace App\Models\Resources;

use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    protected $table = 'chat';
    
    public function azione() {
        return $this->hasMany('App\Models\Resources\Azione');
    }
    
    public function alloggio() {
        return $this->hasOne('App\Models\Resources\Alloggio');
    }
}
