<?php

namespace App\Models\Resources;

use Illuminate\Database\Eloquent\Model;

class Azione extends Model
{
    protected $guarded = ['id'];
    protected $table = 'azione';
    
    public function locatario() {
        return $this->belongsTo('App\User', 'locatario_id');
    }
    
    public function chat() {
        return $this->belongsTo('App\Models\Resources\Chat');
    }
}
