<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Requests\UpdateProfileRequest;

class UserController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    public function index() {
        return view('user');
    }

    public function showProfilo() {
        $user = User::find(auth()->user()->id);
        $genere = array("Non assegnato" => "Non assegnato", 'Maschio' => 'Maschio', 'Femmina' => 'Femmina');

        return view('auth/profilo')
                        ->with('user', $user)
                        ->with('genere', $genere);
    }

    public function updateProfilo(UpdateProfileRequest $request) {
        $user = User::find(auth()->user()->id);
        $user->fill($request->validated());
        $user->save();
       
        return redirect()->action('PublicController@showHome');
    }

}
