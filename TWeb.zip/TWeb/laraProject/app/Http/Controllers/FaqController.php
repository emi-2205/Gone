<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FaqAppModel;
use App\Http\Requests\FaqRequest;


class FaqController extends Controller {

    protected $_faqAppModel;

    public function __construct() {
        $this->_faqAppModel = new FaqAppModel;
    }
    
    private function sanificaFaqList($faqs) { // è come un Blade fatto in casa
        foreach($faqs as $faq) {
            //per inserire l'ancora di registrazione nelle faq
            $faq->risposta = str_replace("##registra##",route('register'),$faq->risposta);
            //per inserire l'ancora al profilo nelle faq
            $faq->risposta = str_replace("##profilo##",route('profilo'),$faq->risposta);
        }
    }

    public function showFaqList($categoria_id) {

        //Accesso alla visualizzazione delle Faq con selezione delle categorie
        //mostrate parte pubblica del sito
        $categorie = $this->_faqAppModel->getCategorie();

        //estrae le faq per categoria, 3 per pagina
        $faqs = $this->_faqAppModel->getFaqsByCat($categoria_id, 3);
        
        
        $this->sanificaFaqList($faqs);

        return view('faq')
                        ->with('categorie', $categorie)
                        ->with('categoria_id', $categoria_id)
                        ->with('faqs', $faqs)
                        ->with('edit', false);
    }

    //praticamente è uguale a showFaqList ma mette $edit a TRUE
    public function showAdminFaqList($categoria_id) {

        //Accesso alla visualizzazione delle Faq con selezione delle categorie
        //mostrate nella parte dell'Amministratore con le funzioni di creazione, modifica e cancellazione
        $categorie = $this->_faqAppModel->getCategorie();

        $faqs = $this->_faqAppModel->getFaqsByCat($categoria_id, 3);
        
        $this->sanificaFaqList($faqs);

        return view('faq')
                        ->with('categorie', $categorie)
                        ->with('categoria_id', $categoria_id)
                        ->with('faqs', $faqs)
                        ->with('edit', true);
    }

    /* ###################################################################################################
      Funzioni utilizzate per la gestionde delle Faq da parte dell'Amministratore
      ################################################################################################### */
    
        /*  Il prossimo gruppo di metodi è quello utilizzato per gestire le funzionalità di
     *  Inserimento, Modifica e Cancellazione di una Faq, con la relativa business logic associata
     * 
     *  Per le form presenti nelle pagine di gestione si è deciso di utilizzare il concetto del
     *  "Form-Model Binding", messo a disposizione dal metodo model della Facade Form di LaravelCollective.
     *  */

    public function add_faq() {
        // risponde alla rotta GET che permette l'inserimento di una nuova Faq
        $faq = $this->_faqAppModel->newFaq();
        //pluck ritorna solo gli attributi specificati della tabella
        $categorie = $this->_faqAppModel->getCategorie()->pluck('nome', 'id');
        return view('faq.insert')
                        ->with('faq', $faq)
                        ->with('cats', $categorie);
    }

    // ATTENZIONE controllare questa nella logica della gui non viene più utilizzata
    // VERIICARE
    public function show_faq($categoria_id = null) {
        $categorie = $this->_faqAppModel->getCategorie();

        if (!isset($categoria_id)) {
            return view('faq')
                            ->with('categorie', $categorie);
        } else {
            $faqs = $this->_faqAppModel->getFaqsByCat($categoria_id, 5);
            return view('faq')
                            ->with('categorie', $categorie)
                            ->with('faqs', $faqs);
        }
    }

    public function edit_faq($faq_id) {
        // risponde all rotta GET che permette di modificare una faq
        $faq = $this->_faqAppModel->getFaqsById($faq_id);
        $categorie = $this->_faqAppModel->getCategorie()->pluck('nome', 'id');
        return view('faq.modify')
                        ->with('cats', $categorie)
                        ->with('faq', $faq);
    }

    public function save_faq(FaqRequest $request) {
        // caso di nuova faq
        // risponde alla rotta POST che permette di inserire una nuova faq
        $faq = $this->_faqAppModel->newFaq();
        $faq->fill($request->validated());
        $faq->save();
        return redirect()->action('FaqController@showAdminFaqList', ['categoria_id' => $faq->categoria_id]);
    }

    public function store_faq(FaqRequest $request) {
        // caso di modifica di faq esistente
        // risponde alla rotta POST che permette di salvare le modifiche ad una faq esistente
        $faq = $this->_faqAppModel->getFaqsById($request->input('id'));
        $faq->fill($request->validated());
        $faq->save();
        return redirect()->action('FaqController@showAdminFaqList', ['categoria_id' => $faq->categoria_id]);
    }

    public function delete_faq($id) {
        // risponde alla rotta POST che permette di cancella re la faq selezionata
        $faq = $this->_faqAppModel->getFaqsById($id);
        $faq->delete();
        return redirect()->action('FaqController@showAdminFaqList', ['categoria_id' => $faq->categoria_id]);
    }

}
