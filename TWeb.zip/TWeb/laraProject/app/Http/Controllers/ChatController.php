<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ChatAppModel;
use App\Http\Requests\NewMessageRequest;
// use Illuminate\Support\Facades\Log;

class ChatController extends Controller {

    protected $_chatAppModel;

    public function __construct() {
        $this->_chatAppModel = new ChatAppModel;
    }

    public function showChat($chat_id, $locatario_id = null) {
        // risponde alla rotta GET che permette accedere alle informazioni della chat selezionata
        // come locatore o come locatario, se inserito
        if (is_null($locatario_id)) {
            $view_name = 'locatario/chat';
        } else {
            $view_name = 'locatore/chat';
        }
        $context = $this->_chatAppModel->getChat($chat_id, $locatario_id);

        return view($view_name)
                        ->with('locatario', $context['locatario'])
                        ->with('chat', $context['chat'])
                        ->with('alloggio', $context['alloggio'])
                        ->with('locatore', $context['locatore'])
                        ->with('messaggi', $context['messaggi'])
                        ->with('num_messaggi', $context['num_messaggi'])
                        ->with('opzione', $context['opzione'])
                        ->with('assegnamento', $context['assegnamento'])
                        ->with('rifiuto', $context['rifiuto']);
    }

    public function sendMessage(NewMessageRequest $request) {
        // risponde alla rotta POST che realizza l'inseriento di un nuovo messaggio (Azione)
        // con le informazioni ricevute dalla request, opportunamente validate
        $msg = $this->_chatAppModel->newAzione();
        $msg->fill($request->validated());
        $msg->save();
        
        //Log::info($request->input('tipo'));
        
        // agggiornamento delle informazioni di accesso alla chat
        $this->_chatAppModel->updateChatDataOoraUltimoContatto($request->input('chat_id'));

        // business logic relativa al tipo di Azione eseguita e quindi dal tipo di utente che la ha eseguita.
        // redirezione condizionale in base alla tipologia di messaggio (e quindi dell'utente)
        if (in_array($request->input('tipo'), ['Info_stu_loc', 'Opzione'])) {
            // non devono essere fatte azioni particolari ma solo registrare il messaggio (fatto sopra)
            // e tornare alla chat del locatario
            return redirect()->route('chat-locatario', [$request->input('chat_id')]);
        } else {
            if (in_array($request->input('tipo'), ['Assegnamento'])) {
                // inviare il messaggio di assegnamento al locatario corrente (fatto sopra) e uno di rifiuto a tutti gli altri
                // che partecipano alla chat corrente, bloccando contestualmente la chat e dichiarando l'alloggio Assegnato

                $this->_chatAppModel->blacklistRifiuto($request->input('chat_id'), $request->input('locatario_id'));
            }
            // in ogni caso se siamo in questo ramo si deve tornare alla chat del locatore
            return redirect()->route('chat-locatore', [$request->input('chat_id'), $request->input('locatario_id')]);
        }
    }

    public function listaChat() {
        // risponde alla rotta GET che permette di accedere alla lista delle chat del locatario
        // con relativo stato
        $context = $this->_chatAppModel->listaChatLocatario();
        return view('locatario/chat_list')
                        ->with('chats', $context['chats'])
                        ->with('chat_status', $context['chat_status']);
    }

    public function listaOpzioni() {
        // risponde alla rotta GET che permette di accedere alla lista delle opzioni del locatario
        // con relativo stato
        $context = $this->_chatAppModel->listaOpzioniLocatario();
        return view('locatario/opzioni_list')
                        ->with('chats', $context['chats'])
                        ->with('chat_status', $context['chat_status']);
    }

    // Sezione per la gesione delle attività del Locatore
    // Primo livello: cerco tutte le chat del locatore corrente che hanno avuto almeno un contatto
    public function showAllLocatoreChat() {
        // risponede all rotta GET che permette di accedere alle chat attive del locatore
        // con indicazione del numero di contatti ed opzioni ricevute per ognuna
        //di default tira su le chat attive
        $context = $this->_chatAppModel->listaChatLocatore();
        return view('locatore/chat_list_all')
                        ->with('chats', $context['chats'])
                        ->with('num_contatti', $context['num_contatti'])
                        ->with('num_opzioni', $context['num_opzioni']);
    }

    public function showAllLocatoreArchivioChat() {
        //tiro su quelle non attive
        $context = $this->_chatAppModel->listaChatLocatore(null, false);
        // risponede all rotta GET che permette di accedere alle chat archiviate (non attive) del locatore
        // con indicazione del numero di contatti ed opzioni ricevute per ognuna
        return view('locatore/chat_list_archivio')
                        ->with('chats', $context['chats'])
                        ->with('num_contatti', $context['num_contatti'])
                        ->with('num_opzioni', $context['num_opzioni']);
    }
    // Fine primo livello

    // Secondo livello: cerco della chat selezionata tutti i locatari che la hanno contattata
    public function showAllLocatari($chat_id) {
        // risponde alla rotta GET che permette di mostrare tutti i locatari che partecipano a quella chat
        // con relativo loro stato nella stessa e informazioni sull'allggio a cui questa si riferisce
        $context = $this->_chatAppModel->listaChatLocatore($chat_id);
        return view('locatore/locatari_list')
                        ->with('azioni', $context['azioni'])
                        ->with('locatari_status', $context['locatari_status'])
                        ->with('chat_id', $chat_id)
                        ->with('alloggio', $context['alloggio']);
    }

    /* Terzo livello: mostro i messaggi della chat selezionata con il locatario selezionato
     * utilizzando il metodo showChat definito più su, che è di tipo generico e gestisce 
     * correttamente la visualizzazione della chat indicata, sia per il locatario che per il locatore
     */
}
