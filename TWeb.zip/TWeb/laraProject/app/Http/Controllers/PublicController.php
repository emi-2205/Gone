<?php

namespace App\Http\Controllers;

use App\Models\CatalogAppModel;

// Controller per le funzionalità pubbliche del sito, in comune a tutti i livelli

class PublicController extends Controller {

    protected $_catalogAppModel;

    
    public function __construct() {
        $this->_catalogAppModel = new CatalogAppModel;
    }

    public function showCatalogoAlloggi() {
        // risponde alla rotta GET che presenta l'elenco degli alloggi
        // ordinati per data di pubblicazione e paginati per 3 (default - fisso)
        $alloggi = $this->_catalogAppModel->getCatalogoAlloggi();

        return view('catalog')
                        ->with('alloggi', $alloggi);
    }
        
    public function showHome() {
        // risponde alla rota GET che presenta la home del sistema
        //tira su i 5 alloggi, pubblicati= true, da mettere nel carosello in home
        $alloggi = $this->_catalogAppModel->getCatalogoAlloggi(5, true);

        return view('home')
                        ->with('alloggi', $alloggi);
    }

}
