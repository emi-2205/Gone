<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StatAppModel;
use App\Http\Requests\StatRequest;

class StatController extends Controller {

    protected $_statAppModel;

    public function __construct() {
        $this->_statAppModel = new StatAppModel;
    }

    public function statistiche() {
        // risponde alla rotta GET che presenta la pagina delle statistiche
        return view('amministratore/statistiche')
                        ->with('start_date', null)
                        ->with('end_date', null)
                        ->with('tipologia', 'Qualsiasi');
    }

    public function calcolaStatistica(StatRequest $request) {
        // risponde alla rotta POST che calcola le statistiche secondo i criteri selezionati nella form
        $start_date = $request->input('start_date');
        if (!is_null($start_date)) {
            $start_date = $start_date . ' 00:00:00';  // risolvo il problema del date time nel db
        }
        $end_date = $request->input('end_date');
        if (!is_null($end_date)) {
            $end_date = $end_date . ' 23:59:59';  // risolvo il problema del date time nel db
        }
        $tipologia = $request->input('tipologia');

        // viene ritornato un array associativo che il framework invia al browser cone oggetto json
        // questo è necessario perchè la chiamata POST a questa rotta vine fatta con la tecnologia ajax
        // i dati ricevuti vengono elaborati lato client per la loro visulizzazione ed il disegno del grafico
        // senza la necessita di ricaricare la pagina
        return [
            'tipologia' => $tipologia,
            'alloggi' => $this->_statAppModel->countAlloggi($tipologia, $start_date, $end_date),
            'opzioni' => $this->_statAppModel->countAzioni($tipologia, $start_date, $end_date, 'Opzione'),
            'assegnazioni' => $this->_statAppModel->countAzioni($tipologia, $start_date, $end_date, 'Assegnamento'),
        ];
    }

}
