<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\FindAlloggioRequest;
use App\Models\AlloggioAppModel;
use App\Http\Requests\AlloggioRequest;
use App\Models\Resources\Alloggio;
use App\Models\Resources\Chat;

class AlloggioController extends Controller {

    protected $_alloggioAppModel;

    public function __construct() {
        $this->_alloggioAppModel = new AlloggioAppModel;
    }

    public function startSearch() {
        // risponde alla rotta GET che presenta la pagina inizialmente vuota per la ricerca degli alloggi
        $tipologie = ['Tutte' => 'Tutte'] + $this->_alloggioAppModel->getTipologiaList();
        // viene aggiunto il parametro di default per la ricerca in testa alla lista riportata dall'Helper
        $locatario = auth()->user();
        // viene controllata la presenza della data di nascita nel profilo del locatario,
        // parametro necessario per l'esecuzione della ricerca di un alloggio
        if (is_null($locatario->data_nascita)) {
            //se non c'è la data diamo errore perché non sappiamo se il locatario rientra nel range di età degli alloggi
            return view('auth/completa_profilo');
        } else {
            return view('locatario/alloggi_list')
                            ->with('tipologie', $tipologie);
        }
    }

    public function findAlloggi(FindAlloggioRequest $request) {
        // risponde alla rotta GET per l'esecuzione della ricerca degli alloggi, mantenendo i parametri di ricerca
        // precedentemente inseriti negli appositi campi della form: tale caratteristica permette di ripetere una nuova
        // ricerca modificando anche un solo parametro ed è necessaria per il corretto funzionamento del paginatore
        $tipologie = ['Tutte' => 'Tutte'] + $this->_alloggioAppModel->getTipologiaList();
        // viene aggiunto il parametro di default per la ricerca in testa alla lista riportata dall'Helper
        $context = $this->_alloggioAppModel->ricercaAlloggi($request);
        return view('locatario/alloggi_list')
                        ->with('alloggi', $context['alloggi'])
                        ->with('statusList', $context['statusList'])
                        ->with('tipologie', $tipologie);
    }

    // visulizza la lista degli alloggi del locatore autenticato
    public function alloggiDelLocatore() {
        $alloggi = $this->_alloggioAppModel->getAlloggilLocatore();
        return view('locatore/alloggi_list')
                        ->with('alloggi', $alloggi);
    }

    /*  Il prossimo gruppo di metodi è quello utilizzato per gestire le funzionalità di
     *  Inserimento, Modifica e Cancellazione di un alloggio, con la relativa business logic associata
     * 
     *  Per le form presenti nelle pagine di gestione si è deciso di utilizzare il concetto del
     *  "Form-Model Binding", messo a disposizione dal metodo model della Facade Form di LaravelCollective.
     *  */

    public function addAlloggio() {
        // risponde alla rotta GET che presenta la Form per l'inserimento di un nuovo alloggio
        $alloggio = $this->_alloggioAppModel->newAlloggio();
        //tiro su tutte le tipologie
        $tipologie = $this->_alloggioAppModel->getTipologiaList();
        //tiro su tutti i generi
        $generi = $this->_alloggioAppModel->getGenereList();
        return view('alloggio/insert')
                        ->with('alloggio', $alloggio)
                        //oggetto vuoto che serve per l'inizializzazione della
                        //form di inserimento di un nuovo alloggio
                        ->with('tipologie', $tipologie)
                        ->with('generi', $generi);
    }

    private function setServiziAlloggio($request, $alloggio) {
        // metodo privato che costituisce parte della business logic necessaria
        $alloggio->cucina = $request->has('cucina');
        $alloggio->locale_ricreativo = $request->has('locale_ricreativo');
        $alloggio->angolo_studio = $request->has('angolo_studio');
        $alloggio->internet = $request->has('internet');
        $alloggio->televisione = $request->has('televisione');
        $alloggio->lavatrice = $request->has('lavatrice');
        $alloggio->posto_bici = $request->has('posto_bici');
    }

    public function storeAlloggio(AlloggioRequest $request) {
        // risponde alla rotta POST che realizza l'inseriento di un nuovo alloggio nella base dati
        // devo creare la chat di riferimento per questo nuovo alloggio e valorizzarne i campi previsti
        $chat = $this->_alloggioAppModel->newChat();
        $chat->descrizione = $request->input('nome');
        $chat->tipologia = $request->input('tipologia');
        $chat->responsabile_id = auth()->user()->id;
        $chat->is_active = false; // di default ogni chat appena creata è disattiva
        $chat->save();

        // creo il nuovo alloggio
        $alloggio = $this->_alloggioAppModel->newAlloggio();
        // utilizzo il metodo fill proprio dei Model di Eloquent per popolare in automatico
        // i campi "fillable" del modello con i valori validati ottenuti dalla request
        $alloggio->fill($request->validated());

        if ($request->input('azione') == 'Pubblica alloggio') {
            // in caso di pressione del pulsante pubblica invece che salva, la business logic prevede di
            // aggiornare opportunamente sia l'alloggio che la chat associata
            $alloggio->stato = 'Pubblicato';
            $alloggio->data_ora_pubblicazione = now();
            $chat->data_ora_pubblicazione = $alloggio->data_ora_pubblicazione;
            $chat->data_ora_ultimo_contatto = $alloggio->data_ora_pubblicazione;
            $chat->is_active = true;
            $chat->save();
        }
        $alloggio->proprietario_id = auth()->user()->id;
        $alloggio->chat_id = $chat->id;
        $alloggio->data_ora_inserimento = now();
        $this->setServiziAlloggio($request, $alloggio);
        $alloggio->save();  // ho bisogno dell'id dell'alloggio per costruire il nome del file dell'immagine,
        // dato che si tratta di un nuovo alloggio l'ORM conosce la chiave primaria solo dopo il salvataggio
        if ($request->hasFile('immagine')) {
            // per il commento della logica legata all'immagine si rimanda al metodo storeImage
            $this->_alloggioAppModel->storeImage($alloggio, $request->file('immagine'));
            $alloggio->save();
        }


        return redirect()->action('AlloggioController@alloggiDelLocatore');
    }

    public function showAlloggio($alloggioId) {
        // risponde alla rotta GET che presenta la Form per la modifica di un alloggio
        $alloggio = $this->_alloggioAppModel->getAlloggio($alloggioId);
        // controllo e fallisco nel caso in cui l'alloggio non sia del locatore autenticato
        $this->_alloggioAppModel->isProprietario(auth()->user(), $alloggio);
        //array associativo
        $tipologie = [$alloggio->tipologia => $alloggio->tipologia];
        $generi = $this->_alloggioAppModel->getGenereList();
        return view('alloggio/modify')
                        ->with('alloggio', $alloggio)
                        // viene passato l'oggetto che rappresenta l'alloggio che si vuole modificare
                        ->with('tipologie', $tipologie)
                        ->with('generi', $generi);
    }

    public function updateAlloggio(AlloggioRequest $request, $alloggioId) {
        // risponde alla rotta POST che realizza l'aggiornamento delle informazioni di un alloggio nella base dati
        // contrariamente al caso precedente non ho bisogno di un nuovo alloggio ma devo trovare quello che voglio modificare
        $alloggio = $this->_alloggioAppModel->getAlloggio($alloggioId);

        // utilizzo il metodo fill proprio dei Model di Eloquent per popolare in automatico
        // i campi "fillable" del modello con i valori validati ottenuti dalla request
        $alloggio->fill($request->validated());
        if ($request->hasFile('immagine')) {
            // per il commento della logica legata all'immagine si rimanda al metodo storeImage
            $this->_alloggioAppModel->storeImage($alloggio, $request->file('immagine'));
        }

        $this->setServiziAlloggio($request, $alloggio);

        // caso di modifica di un alloggio in stato di bozza
        // azione è nome della submit premuta
        if ($request->input('azione') == 'Pubblica alloggio') {
            // in caso di pressione del pulsante pubblica invece che salva, la business logic prevede di
            // aggiornare opportunamente sia l'alloggio che la chat associata
            $alloggio->stato = 'Pubblicato';
            $alloggio->data_ora_pubblicazione = now();
            // nel caso di modifica di un alloggio la chat associata non viene creata contestualmente ma già
            // esiste e quindi la devo recuperare
            $chat = $this->_alloggioAppModel->getChat($alloggio->chat_id);
            $chat->data_ora_pubblicazione = $alloggio->data_ora_pubblicazione;
            $chat->data_ora_ultimo_contatto = $alloggio->data_ora_pubblicazione;
            $chat->is_active = true;
            $chat->save();
        }

        $alloggio->save();

        return redirect()->action('AlloggioController@alloggiDelLocatore');
    }

    public function eliminaAlloggio($id) {
        // risponde alla rotta get che permette di eliminare l'alloggio indicato
        $this->_alloggioAppModel->eliminaAlloggio($id);
        //richiamo la rotta
        return redirect()->action('AlloggioController@alloggiDelLocatore');
    }

    /*     * ******************************* */

    public function stampaContratto($alloggio_id) {
        // dato che tale rotta viene chiamata con una get con parametro nell'url
        // sono necessari alcuni controlli aggiuntivi
        $alloggio = $this->_alloggioAppModel->getAlloggio($alloggio_id); // l'alloggio deve esistere
        $this->_alloggioAppModel->isProprietario(auth()->user(), $alloggio);
        // l'alloggio deve essere del locatore autenticato
        if (!is_null($alloggio->assegnatario_id)) {
            // l'alloggio deve essere stato assegnato a un locatario
            if (is_null($alloggio->data_ora_contratto)) {
                $alloggio->data_ora_contratto = now();
                $alloggio->save();
            }

            $locatario = $this->_alloggioAppModel->getUser($alloggio->assegnatario_id);
            $locatore = auth()->user();
            return view('alloggio/contratto')
                            ->with('alloggio', $alloggio)
                            ->with('locatario', $locatario)
                            ->with('locatore', $locatore);
        } else {
            // alloggio non ancora assegnato
            abort(403, 'Questo alloggio non è ancora stato assegnato');
        }
    }

}
