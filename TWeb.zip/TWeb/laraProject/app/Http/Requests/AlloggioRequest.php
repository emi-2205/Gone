<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AlloggioRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'nome' => 'required|string|max:50',
            'descrizione' => 'nullable',
            'tipologia' => 'required',
            'superficie' => 'required|integer|min:0',
            'canone_affitto' => 'required|numeric|min:0|max:9999.99',
            'indirizzo' => 'required|string|max:100',
            'citta' => 'required|string|max:100',
            'eta_min' => 'required|integer|min:18|max:100',
            'eta_max' => 'required|integer|gte:eta_min|max:100',
            'genere' => 'required',
            'data_inizio_locazione' => 'required|date|after_or_equal:today',
            'data_fine_locazione' => 'required|date|after:data_inizio_locazione',
            'immagine' => 'image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            'num_letti_tot' => 'required|integer|min:0|max:99',
            'num_letti_camera' => 'nullable|integer|min:0|max:99',
            'num_camere' => 'nullable|integer|min:0|max:99',
        ];
    }

}
