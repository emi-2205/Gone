<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FindAlloggioRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'citta' => 'nullable|string|max:100',
            'prezzo_min' => 'nullable|numeric|min:0|max:9999.99',
            'prezzo_max' => 'nullable|numeric|min:0|max:9999.99',
            'data_inizio_locazione' => 'nullable|date_format:Y-m-d',
            'data_fine_locazione' => 'nullable|date_format:Y-m-d',
            'num_letti_tot' => 'nullable|integer|min:0|max:99',
            'num_letti_camera' => 'nullable|integer|min:0|max:99',
            'num_camere' => 'nullable|integer|min:0|max:99',

        ];
    }
}
