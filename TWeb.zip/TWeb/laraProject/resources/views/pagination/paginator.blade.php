{{-- se c'è più di una pagina --}}
@if ($paginator->lastPage() != 1)
<div class="w3-center">
    <div class="w3-bar w3-border">
        {{-- ancora che riporta alla prima pagina, &laquo è il codice html del carattere '<<' --}}
        <a href="{{ $paginator->url(1) }}" class="w3-bar-item w3-button">&laquo;</a>
        {{-- ciclo tutti gli indici della pagina --}}
        @for($i=1;$i<=$paginator->lastPage();$i++)
        {{-- se l'indice è quello della pagina corrente --}}
        @if ($paginator->currentPage() == $i)
        {{-- creo il bottone ma blu --}}
        <a href="#" class="w3-bar-item w3-button w3-blue">{{ $i }}</a>
        @endif
        {{-- altrimenti lo creo ma bianco --}}
        @if ($paginator->currentPage() != $i)
        <a href="{{ $paginator->url($i) }}" class="w3-bar-item w3-button">{{ $i }}</a>
        @endif
        @endfor
        {{-- alla fine metto l'ancora che riporta all'ultima pagina --}}
        <a href="{{ $paginator->url($paginator->lastPage()) }}" class="w3-bar-item w3-button">&raquo;</a>
    </div>
</div>
@endif
{{-- stampo il numero totale di risultati --}}
<div class="w3-center">
    <p>{{ $paginator->total() }} elementi trovati</p>
</div>
