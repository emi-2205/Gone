{{-- helper che prende il nome della foto dell'alloggio (gliela passo come parametro) e include la foto prendendola da 'images/anteprime/' . $imgFile se esiste sennò mette quella di default --}}
@php
        // se l'immagine non c'è prendo quella di default
        if (empty($imgFile)) {
            $imgFile = 'default.jpg';
        }
        if (is_null($attrs)) {
            $attrs = '';
        }

@endphp
{{-- {!! $attrs !!} non sanifica ma converte l'oggetto in stringa --}}
<img src="{{ asset('images/anteprime/' . $imgFile) }}" {!! $attrs !!}>