{{-- a seconda dello stato dell'alloggio mette un'incona differente --}}
@if($stato == 'Bozza')
<i class="fa fa-pencil-square-o fa-2x"></i>
@elseif($stato == 'Pubblicato')
<i class="fa fa-cloud-upload fa-2x"></i>
@elseif($stato == 'Assegnato')
<i class="fa fa-check fa-2x"></i>
@endif