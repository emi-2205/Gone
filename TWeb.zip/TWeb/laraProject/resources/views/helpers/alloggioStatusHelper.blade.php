@can('isLocatario')
@php
$msg = '';
if ($alloggio->stato == 'Assegnato') {
if ($alloggio->assegnatario_id == $locatario->id) {
$msg = "Questo alloggio ti è stato assegnato";
$msg = $msg.' in data '.date('d/m/Y H:i', strtotime($alloggio->data_ora_assegnazione));
} else {
$msg = "Alloggio assegnato ad altro Locatario";
}
} elseif ($alloggio->stato == 'Pubblicato') {
if (!is_null($opzione)) {
$msg = "Hai già opzionato questo alloggio";
}
}
@endphp

<h4>{{ $msg }}</h4>

@can('isOpzionabile', $alloggio) <!-- Le informazioni per fare questi controlli sarebbero
    già disponibili a livello di vista, ma si è voluto sperimentare l'utilizzo di un Gate complesso
    con passaggio di parametri -->

{{ Form::open(array('route' => 'send.message', 'id' => 'messaggio_opzione')) }}

{{ Form::hidden('chat_id', $chat->id) }}
{{ Form::hidden('locatario_id', $locatario->id) }}
{{ Form::hidden('tipo', 'Opzione') }}
{{ Form::hidden('testo', "Richiesta di opzione per l'alloggio ".$alloggio->nome) }}

{{ Form::submit('Opziona questo alloggio', ['class' => 'w3-btn w3-block w3-blue']) }}

{{ Form::close() }}
@endcan <!-- chisura isOpzionabile -->


@endcan

@can('isLocatore')
@php
$msg = '';
$showAssegnaButton = false;
$showContrattoButton = false;
if ($alloggio->stato == 'Assegnato') {
if ($alloggio->assegnatario_id == $locatario->id) {
$msg = "Alloggio assegnato a questo Locatario: ".$locatario->name." ".$locatario->surname;
$msg = $msg.' in data '.date('d/m/Y H:i', strtotime($alloggio->data_ora_assegnazione));
$showContrattoButton = true;
} else {
$msg = "Alloggio assegnato ad altro Locatario";
$msg = $msg.' in data '.date('d/m/Y H:i', strtotime($alloggio->data_ora_assegnazione));
}
} elseif ($alloggio->stato == 'Pubblicato') {
if (!is_null($opzione)) {
$msg = "Il Locatario ha opzionato questo alloggio";
$showAssegnaButton = true;
}
}

@endphp

<h4>{{ $msg }}</h4>

@if($showAssegnaButton)
{{ Form::open(array('route' => 'send.message', 'id' => 'messaggio_assegnamento')) }}

{{ Form::hidden('chat_id', $chat->id) }}
{{ Form::hidden('locatario_id', $locatario->id) }}
{{ Form::hidden('tipo', 'Assegnamento') }}
{{ Form::hidden('testo', "Ti è stato assegnato l'alloggio ".$alloggio->nome) }}

{{ Form::submit('Assegna questo alloggio', ['class' => 'w3-btn w3-block w3-blue']) }}

{{ Form::close() }}
@endif

@if($showContrattoButton)
@if($alloggio->data_ora_contratto == null)
<a href="{{ route('stampa.contratto', [$alloggio->id]) }}" target="_blank" class="w3-btn w3-blue w3-block">Stampa il contratto</a>
@else
<a href="{{ route('stampa.contratto', [$alloggio->id]) }}" target="_blank" class="w3-btn w3-blue w3-block">Stampa una copia del contratto</a>
@endif
@endif

@endcan

