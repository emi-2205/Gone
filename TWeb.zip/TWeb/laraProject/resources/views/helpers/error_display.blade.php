@if($errors->any())
<div class="w3-panel w3-yellow w3-display-container">
  <span onclick="this.parentElement.style.display='none'"
  class="w3-button w3-large w3-display-topright">&times;</span>
  <h4>Attenzione!</h4>
  <ul>
     @foreach ($errors->all() as $error)
         <li>{{$error}}</li>
     @endforeach
  </ul>
</div>
@endif