@extends('layouts.base')

@section('title', 'Chat Locatario')
@section('heading', 'Chat del Locatario')
@section('legenda', "Ti permette di gestire le comunicazioni con il locatore e di opzionare l'alloggio che soddisfa le tue necessità." )

@section('content')

{{--
@dump($locatario)
@dump($chat)
@dump($alloggio)
@dump($locatore)
@dump($messaggi)
@dump($opzione)
@dump($assegnamento)
@dump($rifiuto)
--}}

@isset($chat)


<div class="w3-row">
    <div class="w3-col m8 l9">
        @isset($alloggio)
        @include('componenti/alloggio')
        @endisset
        @empty($alloggio)
        @include('componenti/alloggio_che_fu')
        @endempty
    </div>
    <div class="w3-col m4 l3">
        @isset($locatore)
        @include('componenti/info_locatore')
        @endisset
        @isset($locatario)
        <!-- FORM PER NUOVO MESSAGGIO con funzionamento basato su campi hidden -->
        {{ Form::open(array('route' => 'send.message', 'id' => 'messaggio',
                    'class' => '3-container w3-margin w3-container info-card')) }}
        @include('helpers/error_display')
        <h5 class="w3-center">Scrivi al Locatore</h5>



        {{ Form::textarea('testo', '', [
                    'id' => 'msg',
                    'placeholder' => 'Nuovo messaggio',
                    'class' => 'w3-input w3-border',
                    'style' => 'resize:none',
                    'rows' => '4',
                    'autofocus'
        ]) }}

        {{ Form::hidden('chat_id', $chat->id) }}
        {{ Form::hidden('locatario_id', $locatario->id) }}
        {{ Form::hidden('tipo', 'Info_stu_loc') }}


        <p class="w3-center">
            {{ Form::submit('Invia', ['class' => 'w3-btn w3-blue']) }}
        </p>


            {{ Form::close() }}
        @endisset
    </div>
</div>


@isset($messaggi)


<div class="w3-content w3-border">
    @include('componenti/chatMessageCounter')
    @foreach ($messaggi as $messaggio)

    @if($messaggio->tipo == 'Info_stu_loc')
    <div class="w3-row w3-margin">
        <!-- layout mittente locatario -->
        <div class="w3-third"><span>&nbsp;</span></div>
        <div class="msg-container w3-twothird">
            <i class="fa fa-user fa-2x w3-right"></i>
            <p>{{ $messaggio->testo }}</p>
            <span class="msg-time-right">{{  date('d/m/Y H:i', strtotime($messaggio->data_ora_invio)) }}</span>
        </div>
    </div>
    @elseif($messaggio->tipo == 'Opzione')
    <div class="w3-row w3-margin">
        <!-- layout mittente locatario -->
        <div class="w3-third"><span>&nbsp;</span></div>
        <div class="msg-container w3-twothird w3-aqua">
            <i class="fa fa-paper-plane-o fa-2x w3-right"></i>
            <p>{{ $messaggio->testo }}</p>
            <span class="msg-time-right">{{  date('d/m/Y H:i', strtotime($messaggio->data_ora_invio)) }}</span>
        </div>
    </div>
    @elseif($messaggio->tipo == 'Info_loc_stu')
    <div class="w3-row w3-margin">
        <!-- layout mittente locatore -->
        <div class="msg-container w3-twothird msg-darker">
            <i class="fa fa-user-o fa-2x w3-left"></i>
            <p>&nbsp;{{ $messaggio->testo }}</p>
            <span class="msg-time-left">{{  date('d/m/Y H:i', strtotime($messaggio->data_ora_invio)) }}</span>
        </div>
        <div class="w3-third"><span>&nbsp;</span></div>
    </div>
    @elseif($messaggio->tipo == 'Assegnamento')
    <div class="w3-row w3-margin">
        <!-- layout mittente locatore -->
        <div class="msg-container w3-twothird w3-green">
            <i class="fa fa-check fa-2x w3-left"></i>
            <p>&nbsp;{{ $messaggio->testo }}</p>
            <span class="msg-time-left w3-text-white">{{  date('d/m/Y H:i', strtotime($messaggio->data_ora_invio)) }}</span>
        </div>
        <div class="w3-third"><span>&nbsp;</span></div>
    </div>
    @elseif($messaggio->tipo == 'Rifiuto')
    <div class="w3-row w3-margin">
        <!-- layout mittente locatore -->
        <div class="msg-container w3-twothird w3-red">
            <i class="fa fa-times fa-2x w3-left"></i>
            <p>&nbsp;{{ $messaggio->testo }}</p>
            <span class="msg-time-left w3-text-white">{{  date('d/m/Y H:i', strtotime($messaggio->data_ora_invio)) }}</span>
        </div>
        <div class="w3-third"><span>&nbsp;</span></div>
    </div>
    @endif

    @endforeach
    @include('pagination.paginator', ['paginator' => $messaggi])
</div>
@endisset


@endisset
@empty($chat)
<h1> Ma di cosa stiamo parlando? </h1>
@endempty
@endsection
