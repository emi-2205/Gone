@extends('layouts.base')

@section('title', 'Chat Locatario')
@section('heading', 'Le tue Chat')
@section('legenda', 'Puoi trovare qui tutte le tue chat.' )


@section('content')

{{--
@dump($chats)
--}}

@include('componenti/chat_list_locatario')

@endsection