@extends('layouts.base')

@section('title', 'Chat Locatario')
@section('heading', 'Le tue Opzioni')
@section('legenda', 'Puoi trovare qui tutte le tue opzioni con il loro esito finale.' )

@section('content')

@include('componenti/chat_list_locatario')

@endsection