@extends('layouts.base')

@section('title', 'Chat Locatario')
@section('heading', 'Ricerca alloggi')
@section('legenda', "Puoi cercare qui l'alloggio che soddisfa le tue esigenze." )


{{-- A questo view arrivano tutti gli alloggi filtrati, più i servizi mancanti della smart search,--}}
@section('content')

{{-- inludo la sezione con i filtri --}}
@include('componenti/alloggi_filter_locatario') 


@include('componenti/alloggi_list_locatario')
@isset($alloggi)
<!--Paginazione-->
<br>
@include('pagination.paginator', ['paginator' => $alloggi->appends(request()->input())])
@endisset
@endsection
