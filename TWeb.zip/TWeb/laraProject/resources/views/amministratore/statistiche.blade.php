@extends('layouts.base')

@section('title', 'Statistiche')

@section('heading', 'Calcolo delle statistiche')


@section('page_specific_js')
{{-- js per grafico google --}}
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
{{-- grafico più jQuery e AJAX --}}
<script type="text/javascript" src="{{ asset('js/statistiche.js') }}"></script>
@endsection

@section('content')

@include('helpers/error_display')


{{ Form::open(array('route' => 'statistiche-calcola', 'id' => 'statistiche',
                    'class' => 'w3-container w3-margin w3-container info-card')) }}




<div class="w3-row-padding">
    <div class="w3-third">
        <div  class="w3-section">
            {{ Form::label('tipologia', 'Tipologia :')}}

            {{-- jQuery class= 'ricalcolo' --}}
            {{ Form::select('tipologia', ['Qualsiasi' => 'Qualsiasi', 'Appartamento' => 'Appartamento', 'Posto Letto' => 'Posto Letto'], $tipologia,
                ['class' => 'w3-input w3-border ricalcolo','id' => 'tipologia']) }}
        </div>
    </div>
    <div class="w3-third">
        <div  class="w3-section">
            {{ Form::label('start_date', 'Dalla data :')}}

            {{-- jQuery class= 'ricalcolo' --}}
            {{ Form::date('start_date', $start_date, ['class' => 'w3-input w3-border ricalcolo','id' => 'start_date']) }}
        </div>
    </div>
    <div class="w3-third">
        <div  class="w3-section">
            {{ Form::label('end_date', 'Alla data :')}}

            {{-- jQuery class= 'ricalcolo' --}}
            {{ Form::date('end_date', $end_date, ['class' => 'w3-input w3-border ricalcolo','id' => 'end_date']) }}
        </div>
    </div>
</div>





{{ Form::close() }}

<div class="w3-row-padding">
    <div class="w3-half">
        <div class="w3-section">
            <h3 class="w3-center" id="info"></h3>
            <hr>
            <h4 class="w3-center" id="alloggi"></h4>
            <h4 class="w3-center" id="opzioni"></h4>
            <h4 class="w3-center" id="assegnazioni"></h4>
        </div>
    </div>

    <div class="w3-half">
        <div class="w3-center" id="columnchart_values"></div>
    </div>
</div>

@endsection
