@extends('layouts.base')

@section('title', 'Catalogo')

@section('heading', 'Catalogo degli Alloggi')

@section('content')

@isset($alloggi)
@foreach ($alloggi as $alloggio)


<div class="w3-container w3-margin info-card">
@include('componenti/info_alloggio')
@if($alloggio->stato == 'Assegnato')
<p class="banner">Questo alloggio è stato assegnato di recente.</p>
@endif
</div>

@endforeach

<!--Paginazione-->
@include('pagination.paginator', ['paginator' => $alloggi])

@endisset()


@endsection


