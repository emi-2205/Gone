<!DOCTYPE html>
{{-- prende la lingua locale specificata nel file config/app.php --}}
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <title>MyUniRent | @yield('title')</title>
        <meta charset="UTF-8">
        {{-- metadata che setta la viewport (la parte visibile all'utente della pagina web) in modo che si adatti alla larghezza di qualsiasi schermo e setta lo zoom al 100%--}}
        <meta name="viewport" content="width=device-width, initial-scale=1"> 

        <link rel="stylesheet" type="text/css" href="{{ asset('css/w3.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/poppins.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.min.css') }}">
        
        <!-- nostre eventuali personalizzazioni agli stili -->
        <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">

        <script type="text/javascript" src="{{ asset('js/jquery-3.6.0.min.js') }}"></script>
        <script type="text/javascript" src="{{ asset('js/myunirent.js') }}"></script>

        <!-- le pagine che estendono base inseriranno qui i riferimenti agli script a loro necessari -->
        @yield('page_specific_js')


    </head>
    <body>

        <!-- Sidebar/menu -->
        <div id="menu">
            @include('layouts/_sidebar')
        </div>

        <!-- end #menu -->

        <!-- Top menu on small screens -->
        <header class="w3-container w3-top w3-hide-large w3-blue w3-xlarge w3-padding">
            <a href="javascript:void(0)" class="w3-button w3-blue w3-margin-right" onclick="w3_open()">☰</a>
            <span>MyUniRent</span>
        </header>

        <!-- Overlay effect when opening sidebar on small screens -->
        <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left:245px;margin-right:25px">

            <!-- Header -->
            <div class="w3-container" style="margin-top:60px" id="showcase">
                <h1 class="w3-xxlarge"><b>@yield('heading')</b></h1>
                <hr style="border:2px solid #2196F3" class="w3-round">
                <p class="w3-small">@yield('legenda')</p>
            </div>

            {{-- sto richiamando la section 'content' che definisco da un'altra parte --}}
            @yield('content')

            <!-- End page content -->
            
            {{-- includo il footer --}}
            @include('layouts/_footer')

        </div>
        <!-- W3.CSS Container -->

    </body>
</html>
