
{{-- grazie all'id mySidebar gestisco in js l'apertura e chiusura --}}
<nav class="w3-sidebar w3-blue w3-collapse w3-top w3-large w3-padding w3-card-4" style="z-index:3;width:230px;font-weight:bold;" id="mySidebar"><br>
    <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Chiudi</a>
    <div class="w3-container">
        <div class="w3-bar-block w3-padding-32">
            {{-- asset completes the path to the public folder, alt is the text you will visualize if the image can't be visualized --}}
            <img src="{{ asset('images/affittasi.png') }}" alt="Logo" style="width:100%">
            <h3 class=""><b>MyUniRent<h6>Il miglior sito di alloggi per studenti</b></h6></h3>
            {{-- @auth è una direttiva di controllo, in particolare di autenticazione, di Blade. Ci dice se l'utente è autenticato, a prescindere dal livello di autenticazione  --}}
            @auth
            <h6>{{ Auth::user()->name }}</h6>
            @endauth 
            {{-- come @auth, ci dice però se l'utente è pubblico, cioè non autenticato --}}
            @guest
            <h6>Benvenuto</h6>
            @endguest
        </div>
    </div>
    <div class="w3-bar-block">
        <a href="{{ route('home') }}" title="Vai alla Home" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Home</a>
        <a href="{{ route('catalogo') }}" title="Visualizza il Catalogo" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Catalogo</a> 
        <a href="{{ route('faq-list', ['1']) }}" title="Consulta le Faq" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Faq</a>
        <hr>
        {{-- se autenticato --}}
        @auth
        {{-- In base al tipo di utente aggiungo elementi aggiuntivi alla sidebar --}}
        {{-- Direttiva blade che richiama il gate isLocatore --}}
        @can('isLocatore')
        @include('layouts/_sidebar_locatore')
        @endcan
        @can('isLocatario')
        @include('layouts/_sidebar_locatario')
        @endcan
        @can('isAmministratore')
        @include('layouts/_sidebar_amministratore')
        @endcan
        {{-- c'era un motivo di sicurezza legato al fatto che la rotta di logout non è inserita direttamente dentro l'href ma dentro l'action della form, specificando il verbo POST --}}
        <a href="" title="Esci dal sito" onclick="w3_close(); event.preventDefault(); document.getElementById('logout-form').submit();" class="w3-bar-item w3-button w3-hover-white">Logout</a>
        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            {{ csrf_field() }}
        </form>
        @endauth 
   
        @guest
        <a href="{{ route('login') }}" title="Accedi all'area riservata del sito" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Accedi</a>
        @endguest

    </div>
</nav>