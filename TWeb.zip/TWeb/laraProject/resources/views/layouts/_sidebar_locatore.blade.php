{{-- title è la label che viene visualizzata quando il cursore rimane sull'ancora --}}
<a href="{{ route('locatore-all-alloggi') }}" title="Gestisci i tuoi alloggi" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">I tuoi Alloggi</a>
<a href="{{ route('locatore-all-chat') }}" title="Parla con i locatari" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Chat Attive</a>
<a href="{{ route('locatore-archivio-chat') }}" title="Consulta l'archivio delle Chat" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Chat Archiviate</a>
<a href="{{ route('profilo') }}" title="Vai al tuo Profilo" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Profilo</a>
