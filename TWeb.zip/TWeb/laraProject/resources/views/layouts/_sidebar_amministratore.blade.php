<a href="{{ route('statistiche') }}" title="Visualizza le statistiche" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Statistiche</a>
<a href="{{ route('faq-list-admin', ['1']) }}" title="Gestisci le Faqs" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Gestione Faq</a>
