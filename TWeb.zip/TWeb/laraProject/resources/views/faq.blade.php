@extends('layouts.base')

@section('title', 'Faq')

{{-- $edit discrimina se siamo entrati dalla sezione pubblica o come amministratore --}}
@if($edit)
@section('heading', 'Gestione delle Frequently Asked Questions')
@else
@section('heading', 'Frequently Asked Questions')
@endif

@section('content')


<div class="w3-row">
    <div class="w3-quarter w3-container">
        <div class="w3-block w3-container w3-blue w3-card-4">
            <h2 class="faq-ellipsis">Argomenti</h2>
        </div>
        @if($edit)
        @php($rotta = 'faq-list-admin')
        @else
        @php($rotta = 'faq-list')
        @endif
        @foreach ($categorie as $categoria)

        @if($categoria->id == $categoria_id)
        {{-- coloro di blu la categoria attuale --}}
        <a class="w3-btn w3-border w3-light-blue w3-block faq-ellipsis" href="{{ route($rotta, [$categoria->id]) }}">{{ $categoria->nome }}</a>
        @else
        <a class="w3-btn w3-border w3-block faq-ellipsis" href="{{ route($rotta, [$categoria->id]) }}">{{ $categoria->nome }}</a>
        @endif        

        @endforeach
        @if($edit)
        <br>
        <a class="w3-btn w3-border w3-orange w3-block" href="{{ route('newfaq') }}">Nuova Faq</a>
        @endif

    </div>

    <!-- fine sezione laterale -->
    <div class="w3-threequarter w3-container">
        @isset($faqs)
        <div class="w3-cell w3-bar-block" style="margin-left: 20%;">
            @foreach ($faqs as $faq)

            <div class="w3-block w3-container w3-blue w3-card-4">
                <div class="w3-row">
                    <div class="w3-threequarter">
                        <h2>{{ $faq->domanda }}</h2>
                    </div>
                    <div class="w3-quarter">
                        {{-- se sei admin vengono aggiunti i due pulsanti di modifica ed elimina --}}
                        @if($edit)
                        <a href="{{ route('editfaq', [$faq->id]) }}">
                            <button class="w3-input w3-border w3-margin-bottom w3-round-large w3-teal"  style='cursor:pointer;'>
                                <i class="fa fa-pencil-square-o"></i>
                            </button>
                        </a>
                        <a href="{{ route('deletefaq', [$faq->id]) }}" onclick="return confirm('Sei sicuro di voler cancellare questa Faq?');">
                            <button class="w3-input w3-border w3-margin-bottom w3-round-large w3-red" style='cursor:pointer;' >
                                <i class="fa fa-trash-o"></i>
                            </button>
                        </a>
                        @endif
                    </div>
                </div>
            </div>

            <div class="w3-container w3-card-4">
                <p>{!! $faq->risposta !!}</p>
            </div>
            <br>
            @endforeach

        </div>
        <!--Paginazione-->
        @include('pagination.paginator', ['paginator' => $faqs])
        @endisset()

    </div>
</div>
@endsection


