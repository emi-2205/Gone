@extends('layouts.base')

@section('title', 'Login')

@section('heading', 'Login')

@section('content')
<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">
      <div class="w3-center"><br>
        
        <img src="{{ asset('images/img_avatar.png') }}" alt="Avatar" style="width:30%" class="w3-circle w3-margin-top">
      </div>

    {{-- Gestisco le form attraverso il package Laravel Collective --}}
    {{ Form::open(array('route' => 'login', 'class' => 'w3-container')) }}
    <h3>Login</h3>
    <p>Utilizza questa form per autenticarti al sito</p>

    <div  class="w3-section">
        {{ Form::label('username', 'Nome Utente', ['class' => 'label-input']) }}
        {{ Form::text('username', '', ['class' => 'w3-input w3-border w3-margin-bottom',
                    'placeholder' => 'Inserire il Nome Utente',
                    'id' => 'username',
                    'autofocus']) }}
        {{-- se sul vettore errors salvato sulla session esiste un errore associato alla form con id= username --}}
        @if ($errors->first('username'))
        <ul class="w3-text-red">
            {{-- per ogni errore --}}
            @foreach ($errors->get('username') as $message)
            {{-- ne stampo il contenuto --}}
            <li>{{ $message }}</li>
            @endforeach
        </ul>
        @endif
    </div>

    <div  class="wrap-input">
        {{ Form::label('password', 'Password', ['class' => 'label-input']) }}
        {{ Form::password('password', ['class' => 'w3-input w3-border', 'placeholder' => 'Inserire la Password', 'id' => 'password']) }}
        @if ($errors->first('password'))
        <ul class="w3-text-red">
            @foreach ($errors->get('password') as $message)
            <li>{{ $message }}</li>
            @endforeach
        </ul>
        @endif
    </div>

    <div class="container-form-btn">                
        {{ Form::submit('Login', ['class' => 'w3-button w3-block w3-green w3-section w3-padding']) }}
    </div>
    <div  class="wrap-input">
        <p> Se non hai già un account <a  href="{{ route('register') }}">registrati</a></p>
    </div> 

    {{ Form::close() }}


</div>
@endsection
