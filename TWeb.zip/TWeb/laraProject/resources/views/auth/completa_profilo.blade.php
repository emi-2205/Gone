@extends('layouts.base')

@section('title', 'Avviso')

@section('heading', 'Completa il tuo profilo')

@section('content')


<div class="w3-card-4">

    <header class="w3-container w3-blue">
        <h1>Non hai inserito la data di nascita</h1>
    </header>

    <div class="w3-container w3-center">
        <img src="{{ asset('images/alert.png') }}" alt="Attenzione">
    </div>

    <footer class="w3-container w3-blue">
        <h5>Vai nella gestione Profilo e completa le informazioni richieste</h5>
    </footer>

</div>

@endsection