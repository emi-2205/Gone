@extends('layouts.base')

@section('title', 'PROFILO')

@section('heading', 'Gestione del profilo di '.Auth::user()->name)

@section('content')

@include('helpers/error_display')
<div class="w3-card-4">

    {{ Form::model($user, array('route' => 'updateProfilo', 'class' => 'w3-container')) }}
    <div class="w3-row-padding">
        <div class="w3-quarter">

            <img src="{{ asset('images/img_avatar.png') }}" alt="Avatar" style="width:70%" class="w3-circle w3-margin-top">

        </div>
        <div class="w3-threequarter">
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        {{ Form::label('name', 'Nome', ['class' => ''])}}
                        {{ Form::text('name', null, ['class' => 'w3-input w3-border',
                                    'placeholder' => 'Nome...',
                                    'id' => 'name', 'autofocus']) }}
                    </div>
                </div>
                <div class="w3-half">
                    <div class="w3-section">
                        {{ Form::label('surname', 'Cognome', ['class' => '', 'style'=>''])}}
                        {{ Form::text('surname', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Cognome...', 'id' => 'surname']) }}
                    </div> 
                </div>
            </div>

            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        {{ Form::label('email', 'E-mail', ['class' => ''])}}
                        {{ Form::email('email', null, ['class' => 'w3-input w3-border', 'placeholder' => 'E-mail...', 'id' => 'email']) }}
                    </div>
                </div>
                <div class="w3-half">
                    <div class="w3-section">
                        {{ Form::label('telefono', 'Telefono', ['class' => ''])}}
                        {{ Form::text('telefono', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Telefono...', 'id' => 'telefono']) }}
                    </div>
                </div>
            </div>
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        {{ Form::label('genere', 'Genere', ['class' => ''])}}
                        {{ Form::select('genere', $genere, null, ['class' => 'w3-input w3-border', 'id' => 'tipologia']) }}
                    </div>
                </div>
                <div class="w3-half">
                    <div class="w3-section">
                        {{ Form::label('data_nascita', 'Data di Nascita', ['class' => ''])}}
                        {{ Form::date('data_nascita', null, ['class' => 'w3-input w3-border', 'id' => 'data_nascita']) }}
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="w3-row-padding">
        <div class="w3-threequarter">&nbsp;</div>
        <div class="w3-quarter">
            <div class="w3-section">
                {{ Form::submit('Salva', ['class' => 'w3-btn w3-block w3-blue ']) }}
            </div>
        </div>
    </div>

    {{ Form::close() }} 
</div>

@endsection

<!--                 <form action="/action_page.php" class="w3-input w3-border w3-margin-bottom w3-round-large">
                    <input type="date" class="w3-input w3-border w3-margin-bottom w3-round-large" id="birthday" name="birthday" value="ciao">
                </form> -->

