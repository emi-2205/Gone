@extends('layouts.base')

@section('title', 'Registrazione')

@section('heading', 'Registrazione Nuovo Utente')

@section('content')
<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">
    <div class="w3-center"><br>
        <img src="{{ asset('images/img_avatar.png') }}" alt="Avatar" style="width:30%" class="w3-circle w3-margin-top">
    </div>


    {{ Form::open(array('route' => 'register', 'class' => 'w3-container')) }}
    
    <p>Utilizza questa form per registrarti al sito</p>

    <div  class="w3-section">
        {{ Form::label('name', 'Nome', ['class' => 'label-input']) }}
        {{ Form::text('name', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'name', 'autofocus']) }}
        @if ($errors->first('name'))
        <ul class="w3-text-red">
            @foreach ($errors->get('name') as $message)
            <li>{{ $message }}</li>
            @endforeach
        </ul>
        @endif
    </div>

    <div  class="w3-section">
        {{ Form::label('surname', 'Cognome', ['class' => 'label-input']) }}
        {{ Form::text('surname', '', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'surname']) }}
        @if ($errors->first('surname'))
        <ul class="w3-text-red">
            @foreach ($errors->get('surname') as $message)
            <li>{{ $message }}</li>
            @endforeach
        </ul>
        @endif
    </div>

    <div  class="w3-section">
        {{ Form::label('email', 'Email', ['class' => 'label-input']) }}
        {{ Form::text('email', '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'email']) }}
        @if ($errors->first('email'))
        <ul class="w3-text-red">
            @foreach ($errors->get('email') as $message)
            <li>{{ $message }}</li>
            @endforeach
        </ul>
        @endif
    </div>

    <div  class="w3-section">
        {{ Form::label('username', 'Nome Utente', ['class' => 'label-input']) }}
        {{ Form::text('username', '', ['class' => 'w3-input w3-border w3-margin-bottom','id' => 'username']) }}
        @if ($errors->first('username'))
        <ul class="w3-text-red">
            @foreach ($errors->get('username') as $message)
            <li>{{ $message }}</li>
            @endforeach
        </ul>
        @endif
    </div>

    <div  class="w3-section">
        {{ Form::label('password', 'Password', ['class' => 'label-input']) }}
        {{ Form::password('password', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'password']) }}
        @if ($errors->first('password'))
        <ul class="w3-text-red">
            @foreach ($errors->get('password') as $message)
            <li>{{ $message }}</li>
            @endforeach
        </ul>
        @endif
    </div>

    <div  class="w3-section">
        {{ Form::label('password-confirm', 'Conferma password', ['class' => 'label-input']) }}
        {{ Form::password('password_confirmation', ['class' => 'w3-input w3-border w3-margin-bottom', 'id' => 'password-confirm']) }}
    </div>
    

    
    {{ Form::label('locatario', 'Locatario', ['class' => 'label-input']) }}
    {{ Form::radio('tipo', 'Locatario', true, ['id' => 'locatario']) }}
    &nbsp;
    {{ Form::label('locatore', 'Locatore', ['class' => 'label-input']) }}
    {{ Form::radio('tipo', 'Locatore', false, ['id' => 'locatore']) }}



    <div class="container-form-btn">                
        {{ Form::submit('Registra', ['class' => 'w3-button w3-block w3-green w3-section w3-padding']) }}
    </div>

    {{ Form::close() }}

</div>
@endsection