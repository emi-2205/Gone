@extends('layouts.base')

@section('title', 'Work In Progress')

@section('heading', 'Work In Progress')

@section('content')

<img src="{{ asset('images/under-construction.jpg') }}" alt="Logo" style="width:100%">

@endsection