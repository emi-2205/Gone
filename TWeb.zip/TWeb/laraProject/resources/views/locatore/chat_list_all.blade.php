@extends('layouts.base')

@section('title', 'Chat Locatore')
@section('heading', 'Chat Attive' )
@section('legenda', 'Puoi trovare qui tutte le chat associate ad alloggi per cui hai ricevuto contatti e/o opzioni.' )

@section('content')

{{--
@dump($chats)
@dump($num_contatti)
--}}

@include('componenti/chat_list_locatore')

@endsection