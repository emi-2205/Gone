@extends('layouts.base')

@section('title', 'Chat Locatore')
@section('heading', 'Chat Archiviate' )
@section('legenda', 'Puoi trovare qui tutte le chat associate ad alloggi già assegnati o eliminati dal sistema.' )

@section('content')

{{--
@dump($chats)
@dump($num_contatti)
--}}

@include('componenti/chat_list_locatore')

@endsection