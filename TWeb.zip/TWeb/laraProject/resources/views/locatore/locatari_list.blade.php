@extends('layouts.base')

@section('title', 'Chat Locatore')
@isset($alloggio)
@section('heading', "Locatari interessati all'alloggio ".$alloggio->nome)
@endisset
@empty($alloggio)
@section('heading', "Locatari interessati a un alloggio non presente nel sistema.")
@endempty
@section('legenda', "Puoi trovare qui l'elenco di tutti i locatari interessati al tuo alloggio." )


@section('content')

{{--
@dump($azioni)
--}}

@include('componenti/list_locatari')


@endsection