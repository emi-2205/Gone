@extends('layouts.base')

@section('title', 'Alloggi del locatore')
@section('heading', 'Gestione alloggi')
@section('legenda', "Puoi gestire qui gli alloggi che vuoi affittare." )

@section('page_specific_js')
<script type="text/javascript" src="{{ asset('js/inpagesearch.js') }}"></script>
@endsection

@section('content')
<div class="w3-container">
    <div class="w3-row">
        <div class="w3-quarter">
            <div class="w3-row"> 
                <div class="w3-threequarter">
                    {{-- jQuery -> id= myInput  --}}
                    <input id="myInput" class="w3-input w3-border" type="text" placeholder="Cerca in questa pagina..." autofocus>
                </div>
                <div class="w3-quarter">
                    {{-- jQuery -> id= pulisci  --}}
                    <button id="pulisci" class="w3-button w3-blue">X</button>
                </div>
            </div>
        </div>
        <div class="w3-half">
            {{-- includo il paginator, cioè la barra di navigazione delle pagine --}}
            @include('pagination.paginator', ['paginator' => $alloggi])
        </div>
        <div class="w3-quarter" align="center">
            <a href="{{ route('newalloggio') }}" class="w3-btn w3-blue">Nuovo alloggio</a>
        </div>
    </div>
</div>
{{-- includo la tabella con gli alloggi --}}
@include('componenti/alloggi_list_locatore')
@endsection