{{-- se il servizio internet è presente nell'array 'manca' allora lo faccio rosso --}}
@if(in_array('internet', $manca))
<i class="fa fa-wifi" title="Internet" style="color:red"></i>&nbsp;
@endif

@if(in_array('cucina', $manca))
<i class="fa fa-fire" title="Uso cucina" style="color:red"></i>&nbsp;
@endif

@if(in_array('locale_ricreativo', $manca))
<i class="fa fa-gamepad" title="Locale ricreativo" style="color:red"></i>&nbsp;
@endif

@if(in_array('angolo_studio', $manca))
<i class="fa fa-pencil-square-o" title="Angolo Studio" style="color:red"></i>&nbsp;
@endif

@if(in_array('televisione', $manca))
<i class="fa fa-television" title="Televisione" style="color:red"></i>&nbsp;
@endif

@if(in_array('lavatrice', $manca))
<i class="fa fa-recycle" title="Lavatrice" style="color:red"></i>&nbsp;
@endif

@if(in_array('posto_bici', $manca))
<i class="fa fa-bicycle" title="Posto bici" style="color:red"></i>
@endif