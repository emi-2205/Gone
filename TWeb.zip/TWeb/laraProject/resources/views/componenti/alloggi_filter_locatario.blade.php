@section('page_specific_js')
<script type="text/javascript" src="{{ asset('js/alloggio.js') }}"></script>
@endsection

@include('helpers/error_display')

@if(Auth::user()->genere == 'Non assegnato')
<p class="w3-orange w3-center">Attenzione: Non hai inserito il genere nella tua scheda profilo. Verranno mostrati solo quegli alloggi per cui il Locatore non ha richiesto tale tipo di informazione.</p>
@endif

<div class="w3-card-4">

    {{ Form::open(['route' => ['locatario-find'], 'method' => 'get', 'class' => 'w3-container']) }}

    <div class="w3-row-padding">
        <div class="w3-quarter">
            {{ Form::label('citta', 'Città') }}
            {{ Form::text('citta', request()->input('citta'), ['class' => 'w3-input w3-border', 'placeholder' => 'Città...', 'id' => 'citta', 'autofocus']) }}
        </div>
        <div class="w3-quarter">
            <div class="w3-half">
                {{ Form::label('prezzo_min', 'Fascia di prezzo') }}
                {{ Form::text('prezzo_min', request()->input('prezzo_min'), ['class' => 'w3-input w3-border', 'placeholder' => 'Prezzo min...', 'id' => 'prezzo_min']) }}
            </div>

            <div class="w3-half">
                {{ Form::label('prezzo_max', '&nbsp;') }}
                {{ Form::text('prezzo_max', request()->input('prezzo_max'), ['class' => 'w3-input w3-border', 'placeholder' => 'Prezzo max...', 'id' => 'prezzo_max']) }}
            </div>
        </div>
        <div class="w3-quarter">
            <div class="w3-half">
                {{ Form::label('data_inizio_locazione', 'Periodo di locazione') }}
                {{ Form::date('data_inizio_locazione', request()->input('data_inizio_locazione'), ['class' => 'w3-input w3-border', 'id' => 'data_inizio_locazione']) }}
            </div>

            <div class="w3-half">
                {{ Form::label('data_fine_locazione', '&nbsp;') }}
                {{ Form::date('data_fine_locazione', request()->input('data_fine_locazione'), ['class' => 'w3-input w3-border', 'id' => 'data_fine_locazione']) }}
            </div>
        </div>
        <div class="w3-quarter">
            {{ Form::label('tipologia', 'Tipologia') }}
            {{ Form::select('tipologia', $tipologie, request()->input('tipologia'), ['class' => 'w3-input w3-border', 'id' => 'tipologia']) }}
        </div>
    </div>
    <br>

    <div class="w3-row-padding">
        <div class="w3-quarter">
            {{ Form::label('num_letti_tot', 'Numero posti letto totali') }}
            {{ Form::text('num_letti_tot', request()->input('num_letti_tot'), ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di posti letto totali...', 'id' => 'num_letti_tot_app']) }}
        </div>
    </div>
    <br>
    <div id="idBloccoAppartamento">
        <div class="w3-row-padding">
            <div class="w3-quarter">
                {{ Form::label('num_camere', 'Numero camere') }}
                {{ Form::text('num_camere', request()->input('num_camere'), ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di camere...', 'id' => 'num_camere_app']) }}
            </div>

            <div class="w3-half">
                <br>
                <div class="w3-rest">
                    {{ Form::label('cucina', 'Cucina') }}
                    {{ Form::checkbox('cucina', 1, request()->input('cucina'), ['class' => 'w3-check']) }}

                    {{ Form::label('locale_ricreativo', 'Locale ricreativo') }}
                    {{ Form::checkbox('locale_ricreativo', 1, request()->input('locale_ricreativo'), ['class' => 'w3-check']) }}

                </div>
            </div>

        </div>
    </div>


    <div id="idBloccoPostoLetto">
        <div class="w3-row-padding">
            <div class="w3-quarter">
                {{ Form::label('num_letti_camera', 'Numero posti letto della camera') }}
                {{ Form::text('num_letti_camera', request()->input('num_letti_camera'), ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di posti letto della camera...', 'id' => 'num_letti_camera']) }}
            </div>
            <div class="w3-half">
                <br>
                <div class="w3-rest">
                    {{ Form::label('angolo_studio', 'Angolo studio') }}
                    {{ Form::checkbox('angolo_studio', 1, request()->input('angolo_studio'), ['class' => 'w3-check']) }}

                    {{ Form::label('televisione', 'Televisione') }}
                    {{ Form::checkbox('televisione', 1, request()->input('televisione'), ['class' => 'w3-check']) }}

                    {{ Form::label('lavatrice', 'Lavatrice') }}
                    {{ Form::checkbox('lavatrice', 1, request()->input('lavatrice'), ['class' => 'w3-check']) }}

                    {{ Form::label('posto_bici', 'Posto bici') }}
                    {{ Form::checkbox('posto_bici', 1, request()->input('posto_bici'), ['class' => 'w3-check']) }}
                </div>
            </div>
        </div>
    </div>

    <div class="w3-row-padding">
        <div class="w3-quarter">
            {{ Form::label('internet', 'Internet') }}
            {{ Form::checkbox('internet', 1, request()->input('internet'), ['class' => 'w3-check']) }}
        </div>
        
        <div class="w3-threequarter" align="right">
            {{ Form::label('smart', 'Smart Search', ['class' => 'w3-text-red']) }}
            {{ Form::checkbox('smart', 1, request()->input('smart'), ['class' => 'w3-check']) }}
        </div>
    </div>

    <div class="container-form-btn">
        {{ Form::submit('Cerca', ['class' => 'w3-button w3-block w3-green w3-section w3-padding']) }}
    </div>


    {{ Form::close() }}
</div>

<br>


