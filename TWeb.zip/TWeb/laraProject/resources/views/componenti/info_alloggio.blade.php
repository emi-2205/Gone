<div class="w3-row w3-margin">

    <div class="w3-third" style="max-width:400px">
        @include('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine])
    </div>
    <div class="w3-twothird">
        <div class="">
            <div class="w3-col">
                <b><h2>{{ $alloggio->nome }}</h2></b>
                <hr style="height:2px;border-width:0;color:gray;background-color:gray">
            </div>
        </div>
        <div class="w3-cell-row">
            <div class="w3-cell w3-margin">
                <h4><i class="fa fa-map-marker" title="Indirizzo"></i>&nbsp{{ $alloggio->indirizzo }}</h4>
                @if($alloggio->tipologia == 'Appartamento')
                <h4><i class="fa  fa-home"title="Tipologia"></i>&nbsp{{ $alloggio->tipologia }}</h4>
                @else
                <h4><i class="fa  fa-bed"title="Tipologia"></i>&nbsp{{ $alloggio->tipologia }}</h4>
                @endif
                <h4><i class="fa fa-calendar" title="Periodo di locazione"></i>&nbsp{{ date('d/m/Y', strtotime($alloggio->data_inizio_locazione)) }} - {{ date('d/m/Y', strtotime($alloggio->data_fine_locazione)) }}</h4>
                <h4>@include('componenti/alloggioServizi')</h4>
                @isset($alloggio->data_ora_pubblicazione)
                <p>Annuncio inserito il {{ date('d/m/Y', strtotime($alloggio->data_ora_pubblicazione)) }}</p>
                @endisset
            </div>
            <div class="w3-cell-middle" style="text-align: right;">
                <h3>&nbsp</h3>
                <h3>&nbsp{{ $alloggio->canone_affitto }}€</h3>
            </div>
        </div>
        <div class="w3-row">
            <div class="">
                <p>
                    {{ $alloggio->descrizione }}
                </p>
            </div>
        </div>
    </div>
</div>
