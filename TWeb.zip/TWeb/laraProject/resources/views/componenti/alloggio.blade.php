
<div class="w3-container w3-margin info-card">
    @include('componenti/info_alloggio')
    
    @include('helpers/alloggioStatusHelper') <!-- Helper che si occupa di gestire l'accesso alle funzioni di
    opzione e assegnamento e di stampare i relativi messaggi di stato, sia per il locatore che per il locatario-->
    
    @can('isLocatario') <!-- Cose da fare nel caso di Locatario -->
    
    @endcan <!-- chisura isLocatario -->
    
    @can('isLocatore') <!-- Cose da fare nel caso di Locatore -->

    @endcan <!-- chisura isLocatore -->

</div>
