@section('page_specific_js')
<script type="text/javascript" src="{{ asset('js/alloggio.js') }}"></script>
@endsection

<div class="w3-row-padding">
    <div class="w3-quarter">
        <div  class="w3-section">
            {{ Form::label('nome', 'Nome') }}
            {{ Form::textarea('nome', null, ['class' => 'w3-input w3-border', 'rows' => 2, 'placeholder' => 'Nome...', 'id' => 'nome', 'autofocus']) }}
            @if ($errors->first('nome'))
            <ul class="w3-text-red"> 
                @foreach ($errors->get('nome') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif 
        </div>
    </div>
    <div class="w3-threequarter">
        <div  class="w3-section">
            {{ Form::label('descrizione', 'Descrizione') }}
            {{ Form::textarea('descrizione', null, ['class' => 'w3-input w3-border', 'rows' => 2, 'placeholder' => 'Descrizione...', 'id' => 'descrizione']) }}
            @if ($errors->first('descrizione'))
            <ul class="w3-text-red">
                @foreach ($errors->get('descrizione') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif
        </div>
    </div>
</div>


<div class="w3-row-padding">
    <div class="w3-quarter">
        <div  class="w3-section">
            {{ Form::label('canone_affitto', 'Canone affitto') }}
            {{ Form::text('canone_affitto',  null, ['class' => 'w3-input w3-border', 'placeholder' => 'Canone affitto...', 'id' => 'canone_affitto']) }}
            @if ($errors->first('canone_affitto'))
            <ul class="w3-text-red">
                @foreach ($errors->get('canone_affitto') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            {{ Form::label('superficie', 'Superficie mq') }}
            {{ Form::text('superficie', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Superficie...', 'id' => 'superficie']) }}
            @if ($errors->first('superficie'))
            <ul class="w3-text-red">
                @foreach ($errors->get('superficie') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            {{ Form::label('citta', 'Città') }}
            {{ Form::text('citta', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Città...', 'id' => 'citta']) }}
            @if ($errors->first('citta'))
            <ul class="w3-text-red">
                @foreach ($errors->get('citta') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            {{ Form::label('indirizzo', 'Indirizzo') }}
            {{ Form::text('indirizzo', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Indirizzo...', 'id' => 'indirizzo']) }}
            @if ($errors->first('indirizzo'))
            <ul class="w3-text-red">
                @foreach ($errors->get('indirizzo') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif
        </div>
    </div>
</div>


<div class="w3-row-padding">
    <div class="w3-quarter">
        <div  class="w3-section">
            {{ Form::label('eta_min', 'Età minima richiesta', ['class' => 'label-input']) }}
            {{ Form::text('eta_min', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Età minima richiesta...', 'id' => 'eta_min']) }}
            @if ($errors->first('eta_min'))
            <ul class="w3-text-red">
                @foreach ($errors->get('eta_min') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif
        </div>
    </div>
    <div class="w3-quarter">
        <div  class="w3-section">
            {{ Form::label('eta_max', 'Età massima richiesta') }}
            {{ Form::text('eta_max', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Età massima richiesta...', 'id' => 'eta_max']) }}
            @if ($errors->first('eta_max'))
            <ul class="w3-text-red">
                @foreach ($errors->get('eta_max') as $message)
                <li>{{ $message }}</li>
                @endforeach
            </ul>
            @endif
        </div>
    </div>
    <div class="w3-quarter">
        <div class="w3-section">
            {{ Form::label('genere', 'Genere Richiesto') }}
            {{ Form::select('genere', $generi, null, ['class' => 'w3-input w3-border','id' => 'genere']) }}
        </div>
    </div>
</div>


<div class="w3-row">
    <div class="w3-half">
        <div class="w3-row-padding">
            <div class="w3-half">
                <div class="w3-section">
                    {{ Form::label('data_inizio_locazione', 'Data Inizio Locazione') }}
                    {{ Form::date('data_inizio_locazione', null, ['class' => 'w3-input w3-border','id' => 'data_inizio_locazione']) }}
                    @if ($errors->first('data_inizio_locazione'))
                    <ul class="w3-text-red">
                        @foreach ($errors->get('data_inizio_locazione') as $message)
                        <li>{{ $message }}</li>
                        @endforeach
                    </ul>
                    @endif
                </div>
            </div>
            <div class="w3-half">
                <div class="w3-section">
                    {{ Form::label('data_fine_locazione', 'Data Fine Locazione') }}
                    {{ Form::date('data_fine_locazione', null, ['class' => 'w3-input w3-border','id' => 'data_fine_locazione']) }}
                    @if ($errors->first('data_fine_locazione'))
                    <ul class="w3-text-red">
                        @foreach ($errors->get('data_fine_locazione') as $message)
                        <li>{{ $message }}</li>
                        @endforeach
                    </ul>
                    @endif
                </div>
            </div>
        </div>
        <div class="w3-row">
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div class="w3-section">
                        {{ Form::label('tipologia', 'Tipologia') }}
                        {{-- jQuery id= tipologia, al change della select --}}
                        {{ Form::select('tipologia', $tipologie, null, ['class' => 'w3-input w3-border','id' => 'tipologia']) }}
                    </div>
                </div>

                <div class="w3-half">
                    <div  class="w3-section">
                        {{ Form::label('num_letti_tot', 'Numero posti letto totali') }}
                        {{ Form::text('num_letti_tot', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di posti letto totali...', 'id' => 'num_letti_tot']) }}
                        @if ($errors->first('num_letti_tot'))
                        <ul class="w3-text-red">
                            @foreach ($errors->get('num_letti_tot') as $message)
                            <li>{{ $message }}</li>
                            @endforeach
                        </ul>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <div id="idBloccoAppartamento">
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div  class="w3-section">
                        {{ Form::label('num_camere', 'Numero camere') }}
                        {{ Form::text('num_camere', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Numero di camere...', 'id' => 'num_camere']) }}
                        @if ($errors->first('num_camere'))
                        <ul class="w3-text-red">
                            @foreach ($errors->get('num_camere_app') as $message)
                            <li>{{ $message }}</li>
                            @endforeach
                        </ul>
                        @endif
                    </div>
                </div>
                <div class="w3-half">
                    <br>
                    <div class="w3-section">
                        {{ Form::label('cucina', 'Cucina') }}
                        {{ Form::checkbox('cucina', 1, null, ['class' => 'w3-check']) }}
                        &nbsp;
                        {{ Form::label('locale_ricreativo', 'Locale ricreativo') }}
                        {{ Form::checkbox('locale_ricreativo', 1, null, ['class' => 'w3-check']) }}
                    </div>
                </div>
            </div>
        </div>
        {{-- Fine appartamento --}}

        <div id="idBloccoPostoLetto">
            <div class="w3-row-padding">
                <div class="w3-half">
                    <div  class="w3-section">
                        {{ Form::label('num_letti_camera', 'Numero posti letto della camera') }}
                        {{ Form::text('num_letti_camera', null, ['class' => 'w3-input w3-border', 'placeholder' => 'Posti letto della camera...', 'id' => 'num_letti_camera']) }}
                        @if ($errors->first('num_letti_camera'))
                        <ul class="w3-text-red">
                            @foreach ($errors->get('num_letti_camera') as $message)
                            <li>{{ $message }}</li>
                            @endforeach
                        </ul>
                        @endif
                    </div>
                </div>
                <div class="w3-half">
                    <br>
                    <div class="w3-section">
                        {{ Form::label('angolo_studio', 'Angolo studio') }}
                        {{ Form::checkbox('angolo_studio', 1, null, ['class' => 'w3-check']) }}
                        &nbsp;
                        {{ Form::label('televisione', 'Televisione') }}
                        {{ Form::checkbox('televisione', 1, null, ['class' => 'w3-check']) }}
                        &nbsp;
                        {{ Form::label('lavatrice', 'Lavatrice') }}
                        {{ Form::checkbox('lavatrice', 1, null, ['class' => 'w3-check']) }}
                        &nbsp;
                        {{ Form::label('posto_bici', 'Posto bici') }}
                        {{ Form::checkbox('posto_bici', 1, null, ['class' => 'w3-check']) }}
                    </div>
                </div>
            </div>
        </div>
        {{-- Fine posto letto --}}

        <div class="w3-row-padding">
            <div class="w3-half">
                <div class="w3-section">
                    {{ Form::label('internet', 'Internet') }}
                    {{ Form::checkbox('internet', 1, null, ['class' => 'w3-check']) }}
                </div>
            </div>
        </div>
    </div>

    <div class="w3-half">
        <div class="w3-half">
            <div class="w3-section">   
                {{ Form::label('immagine', 'Caricamento immagine: ') }}<br>
                {{ Form::file('immagine', ['class' => 'w3-input w3-border', 'id' => 'immagine']) }}

                @if ($errors->first('immagine'))
                <ul class="w3-text-red">
                    @foreach ($errors->get('immagine') as $message)
                    <li>{{ $message }}</li>
                    @endforeach
                </ul>
                @endif
            </div>
        </div>
        <div class="w3-half">
            <div class="w3-section w3-input">   
                @include('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine])
            </div>
        </div>

    </div>
</div>




