<div class="w3-container w3-light-blue">
    <div class="w3-row">
        @if($num_messaggi == 0)
        <h4>Non hai messaggi per questo alloggio</h4>
        @elseif($num_messaggi == 1)
        <h4>Hai un messaggio per questo alloggio</h4>
        @else
        <h4>Hai {{ $num_messaggi }} messaggi per questo alloggio</h4>
        @endif
    </div>
</div>