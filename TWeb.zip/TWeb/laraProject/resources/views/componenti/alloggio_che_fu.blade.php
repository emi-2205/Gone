<div class="w3-container w3-margin info-card">

<h1>{{ $chat-> descrizione }} </h1>
<h1> Notizie della chat di un alloggio che fu... </h1>

</div>