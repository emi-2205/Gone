

<div class="w3-container">
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-cloud-upload"></i>
        Pubblicato&nbsp;
        <i class="fa fa-check"></i>
        Assegnato
    </div>

    {{-- tabella per schermo grande --}}
    <table class="w3-table-all w3-hoverable big-screen">
        <tr>
            <th></th>
            <th></th>
            <th>Nome Alloggio</th>
            <th>Descrizione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th></th>
        </tr>
        @isset($alloggi)
        @foreach($alloggi as $alloggio)
        <tr>
            <td>@include('helpers/iconStatoAlloggio', ['stato' => $alloggio->stato])</td>
            <td style="max-width: 300px">@include('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine])</td>
            @isset($statusList[$alloggio->id])
            <td class="break-word" style="width: 20%">{{ $alloggio->nome }}
                <br>@include('componenti/alloggioServizi')
                <br>@include('componenti/alloggioServiziManca', ['manca' => $statusList[$alloggio->id]])
                {{-- <br><del class="w3-text-red">{{ implode(", ", $statusList[$alloggio->id]) }}</del></td> --}}
            @endisset
            @empty($statusList[$alloggio->id])
            <td class="break-word" style="width: 20%">{{ $alloggio->nome }}<br>@include('componenti/alloggioServizi')</td>
            @endempty
            <td class="break-word" style="width: 40%">{{ $alloggio->descrizione }}</td>
            <td class="w3-right-align">{{ $alloggio->canone_affitto }}&euro;</td>
            <td class="w3-right-align"><a href="{{ route('chat-locatario', [$alloggio->chat_id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
        </tr>
        @endforeach
        @endisset
    </table>


    {{-- tabella per schermo piccolo --}}
    <table class="w3-table-all w3-hoverable small-screen">
        <tr>
            <th></th>
            <th>Nome Alloggio</th>
            <th class="w3-right-align">Canone</th>
            <th></th>
        </tr>
        @isset($alloggi)
        @foreach($alloggi as $alloggio)
        <tr>
            <td>@include('helpers/iconStatoAlloggio', ['stato' => $alloggio->stato])</td>
            @isset($statusList[$alloggio->id])
            <td class="break-word" style="width: 40%">{{ $alloggio->nome }}
                <br>@include('componenti/alloggioServizi')
                <br>@include('componenti/alloggioServiziManca', ['manca' => $statusList[$alloggio->id]])
                {{-- <br><del class="w3-text-red">{{ implode(", ", $statusList[$alloggio->id]) }}</del></td> --}}
            @endisset
            @empty($statusList[$alloggio->id])
            <td class="break-word" style="width: 40%">{{ $alloggio->nome }}<br>@include('componenti/alloggioServizi')</td>
            @endempty
            <td class="w3-right-align">{{ $alloggio->canone_affitto }}&euro;</td>
            <td class="w3-right-align"><a href="{{ route('chat-locatario', [$alloggio->chat_id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
        </tr>
        @endforeach
        @endisset
    </table>
</div>