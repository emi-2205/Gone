<div class="w3-container">
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-comments"></i>
        Info&nbsp;
        <i class="fa fa-paper-plane"></i>
        Opzione&nbsp;
        <i class="fa fa-check"></i>
        Assegnamento&nbsp;
        <i class="fa fa-times"></i>
        Rifiuto&nbsp;
    </div>

    {{-- tabella schermo grande --}}
    <table class="w3-table-all w3-hoverable big-screen">
        <tr>
            <th></th>
            <th>Nome Alloggio</th>
            <th>Descri&shy;zione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th></th>
        </tr>
        @foreach($chats as $chat)
        <tr>
            @isset($chat->alloggio)
            <td><i class="{{ $chat_status[$chat->id] }}"></i></td>
            <td class="break-word" style="width: 20%">{{ $chat->alloggio->nome }}</td>
            <td class="break-word">{{ $chat->alloggio->descrizione }}</td>
            <td style="width: 10%" class="w3-right-align">{{ $chat->alloggio->canone_affitto }}&euro;</td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('chat-locatario', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            @endisset
            @empty($chat->alloggio)
            <td><i class="{{ $chat_status[$chat->id] }}"></i></td>
            <td class="break-word" style="width: 20%">{{ $chat->descrizione }}</td>
            <td>N/A</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('chat-locatario', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>

            @endempty
        </tr>
        @endforeach
    </table>

    {{-- tabella schermo piccolo --}}
        <table class="w3-table-all w3-hoverable small-screen">
        <tr>
            <th></th>
            <th>Nome Alloggio</th>
            <th class="w3-right-align">Canone</th>
            <th></th>
        </tr>
        @foreach($chats as $chat)
        <tr>
            @isset($chat->alloggio)
            <td><i class="{{ $chat_status[$chat->id] }}"></i></td>
            <td class="break-word" style="width: 70%">{{ $chat->alloggio->nome }}</td>
            <td style="width: 10%" class="w3-right-align">{{ $chat->alloggio->canone_affitto }}&euro;</td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('chat-locatario', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            @endisset
            @empty($chat->alloggio)
            <td><i class="{{ $chat_status[$chat->id] }}"></i></td>
            <td class="break-word" style="width: 70%">{{ $chat->descrizione }}</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('chat-locatario', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>

            @endempty
        </tr>
        @endforeach
    </table>
</div>