<div class="w3-container">
    {{-- legendina in alto --}}
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-comments"></i>
        Info&nbsp;
        <i class="fa fa-paper-plane"></i>
        Opzione&nbsp;
        <i class="fa fa-check"></i>
        Assegnamento&nbsp;
        <i class="fa fa-times"></i>
        Rifiuto&nbsp;
    </div>

    {{-- tabella (riga locatario) schermo grande --}}
    <table class="w3-table-all w3-hoverable big-screen">
        <tr>
            <th></th>
            <th>Cognome</th>
            <th>Nome</th>
            <th>Telefono</th>
            <th>Mail</th>
            <th></th>
        </tr>
        @foreach($azioni as $azione)
        @php($locatario = $azione->locatario)
        <tr>
            <td><i class="{{ $locatari_status[$locatario->id] }}"></i></td>
            <td class="break-word" style="width: 20%">{{ $locatario->surname }}</td>
            <td class="break-word" style="width: 20%">{{ $locatario->name }}</td>
            <td class="break-word">{{ $locatario->telefono }}</td>
            <td class="break-word">{{ $locatario->email }}</td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('chat-locatore', [$chat_id, $locatario->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
        </tr>
        @endforeach

    {{-- tabella schermo piccolo --}}
    </table>
        <table class="w3-table-all w3-hoverable small-screen">
        <tr>
            <th></th>
            <th>Cognome</th>
            <th>Nome</th>
            <th></th>
        </tr>
        @foreach($azioni as $azione)
        @php($locatario = $azione->locatario)
        <tr>
            <td><i class="{{ $locatari_status[$locatario->id] }}"></i></td>
            <td class="break-word" style="width: 40%">{{ $locatario->surname }}</td>
            <td class="break-word" style="width: 40%">{{ $locatario->name }}</td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('chat-locatore', [$chat_id, $locatario->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
        </tr>
        @endforeach
    </table>
</div>