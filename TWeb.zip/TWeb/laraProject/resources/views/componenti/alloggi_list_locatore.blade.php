
<div class="w3-container">
    <div class="w3-padding w3-light-blue">
        <i class="fa fa-pencil-square-o"></i>
        Bozza&nbsp;
        <i class="fa fa-cloud-upload"></i>
        Pubblicato&nbsp;
        <i class="fa fa-check"></i>
        Assegnato
    </div>

    {{-- tabella che visualizzo se la finestra del browser è più larga di 700 pixel (grazie alla classe big-screen) --}}
    <table class="w3-table-all w3-hoverable big-screen">
        <tr>
            <th></th>
            <th></th>
            <th>Nome Alloggio</th>
            <th>Descrizione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th></th>
        </tr>
        
        {{-- jQuery -> id= myTable  --}}
        <tbody id="myTable">
            @isset($alloggi)
            @foreach($alloggi as $alloggio)
            {{-- ogni alloggio è una tabella --}}
            <tr>
                {{-- helper che inserisce l'icona dello stato --}}
                <td>@include('helpers/iconStatoAlloggio', ['stato' => $alloggio->stato])</td>
                <td style="max-width: 300px">@include('helpers/alloggioImg', ['attrs' => 'class="responsive"', 'imgFile' => $alloggio->immagine])</td>
                
                {{-- jQuery -> class= nome  --}}
                <td class="break-word nome" style="width: 20%">{{ $alloggio->nome }}<br>@include('componenti/alloggioServizi')</td> {{-- helper che inserisce le icone dei servizi  --}}
                <td class="break-word" style="width: 40%">{{ $alloggio->descrizione }}</td>
                <td class="w3-right-align">{{ $alloggio->canone_affitto }}&euro;</td>
                {{-- rotta per aprire nel dettaglio l'alloggio --}}
                <td class="w3-right-align"><a href="{{ route('alloggio', [$alloggio->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            </tr>
            @endforeach
            @endisset
        </tbody>
    </table>

    {{-- tabella che visualizzo se la finestra del browser è più stretta di 700 pixel (grazie alla classe small-screen) --}}
    <table class="w3-table-all w3-hoverable small-screen">
        <tr>
            <th></th>
            <th>Nome Alloggio</th>
            <th class="w3-right-align">Canone</th>
            <th></th>
        </tr>
        <tbody id="myTable">
            @isset($alloggi)
            @foreach($alloggi as $alloggio)
            <tr>
                <td>@include('helpers/iconStatoAlloggio', ['stato' => $alloggio->stato])</td>
                <td class="break-word nome" style="width: 40%">{{ $alloggio->nome }}<br>@include('componenti/alloggioServizi')</td>
                <td class="w3-right-align">{{ $alloggio->canone_affitto }}&euro;</td>
                <td class="w3-right-align"><a href="{{ route('alloggio', [$alloggio->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            </tr>
            @endforeach
            @endisset
        </tbody>
    </table>

</div>