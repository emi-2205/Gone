{{-- Questo componente viene incluso sia dalla vista delle chat attive che delle chata archiviate --}}
<div class="w3-container">

    {{-- tabella per schermo grande --}}
    <table class="w3-table-all w3-hoverable big-screen">
        <tr>
            {{-- &shy suggerisce al browser dove andare a capo se necessario --}}
            <th class="break-word">Nome Alloggio</th>
            <th class="break-word">Descri&shy;zione</th>
            <th class="w3-right-align">Canone Affitto</th>
            <th class="w3-right-align">Con&shy;tatti</th>
            <th class="w3-right-align">Opzio&shy;ni</th>
            <th></th>
        </tr>
        @foreach($chats as $chat)
        <tr>
            {{-- se l'alloggio esiste --}}
            {{-- per le chat attive --}}
            @isset($chat->alloggio)
            <td class="break-word" style="width: 20%">{{ $chat->alloggio->nome }}</td>
            <td class="break-word">{{ $chat->alloggio->descrizione }}</td>
            <td style="width: 10%" class="w3-right-align">{{ $chat->alloggio->canone_affitto }}&euro;</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow">{{ $num_contatti[$chat->id] }}</span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green">{{ $num_opzioni[$chat->id] }}</span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('locatore-chat-all-locatari', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            @endisset
            {{-- se non esiste --}}
            {{-- per le chat archiviate --}}
            @empty($chat->alloggio)
            <td class="break-word" style="width: 20%">{{ $chat->descrizione }}</td>
            <td>N/A</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow">{{ $num_contatti[$chat->id] }}</span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green">{{ $num_opzioni[$chat->id] }}</span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('locatore-chat-all-locatari', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            @endempty
        </tr>
        @endforeach
    </table>

    {{-- tabella per schermo piccolo --}}
        <table class="w3-table-all w3-hoverable small-screen">
        <tr>
            <th class="break-word">Nome Alloggio</th>
            <th class="w3-right-align">Canone</th>
            <th class="w3-right-align">Con&shy;tatti</th>
            <th class="w3-right-align">Opzio&shy;ni</th>
            <th></th>
        </tr>
        @foreach($chats as $chat)
        <tr>
            @isset($chat->alloggio)
            <td class="break-word" style="width: 70%">{{ $chat->alloggio->nome }}</td>
            <td style="width: 10%" class="w3-right-align">{{ $chat->alloggio->canone_affitto }}&euro;</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow">{{ $num_contatti[$chat->id] }}</span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green">{{ $num_opzioni[$chat->id] }}</span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('locatore-chat-all-locatari', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            @endisset
            @empty($chat->alloggio)
            <td class="break-word" style="width: 70%">{{ $chat->descrizione }}</td>
            <td>N/A</td>
            <td style="width: 10%" class="w3-right-align">N/A</td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-yellow">{{ $num_contatti[$chat->id] }}</span></td>
            <td class="w3-center" style="width: 7%"><span class="w3-badge w3-green">{{ $num_opzioni[$chat->id] }}</span></td>
            <td class="w3-right-align" style="width: 70px"> <a href="{{ route('locatore-chat-all-locatari', [$chat->id]) }}" class="w3-btn w3-blue"><i class="fa fa-search"></i></a></td>
            @endempty
        </tr>
        @endforeach
    </table>
</div>
