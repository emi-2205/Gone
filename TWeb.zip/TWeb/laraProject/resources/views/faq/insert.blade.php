@extends('layouts.base')

@section('title', 'Gestione Faq')
@section('heading', 'Inserimento di una nuova Faq')
@section('legenda', "Puoi inserire qui una nuova Faq." )

@section('content')
@include('helpers/error_display')
<div class="w3-card-4">

    {{ Form::model($faq, array('route' => 'newfaq.store'), ['class' => 'w3-container w3-card-4 w3-light-grey w3-text-blue w3-margin']) }}

    @include('componenti/faq_management')

    <footer class="w3-container">
        <div class="w3-row w3-section">
            <div class="w3-col m5"></div>
            <div class="w3-col m2">
                {{ Form::submit('Aggiungi Faq', ['class' => 'w3-button w3-block w3-green', 'style' => 'cursor:pointer;']) }}
            </div>
            <div class="w3-col m5"></div>
        </div>
    </footer>
    {{ Form::close() }}

</div>









@endsection


