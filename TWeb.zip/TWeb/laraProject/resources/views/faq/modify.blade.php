@extends('layouts.base')

@section('title', 'Gestione Faq')
@section('heading', 'Modifica di una Faq')
@section('legenda', "Puoi modificare qui una Faq." )

@section('content')
@include('helpers/error_display')
@isset($faq)
<div class="w3-card-4">
    {{ Form::model($faq, array('route' => 'editfaq.store')) }}
    
    @include('componenti/faq_management')
    {{ Form::hidden('id', null) }}

    <footer class="w3-container">
        <div class="w3-row w3-section">
            <div class="w3-col m5"></div>
            <div class="w3-col m2">
                {{ Form::submit('Salva Modifica', ['class' => 'w3-button w3-block w3-green', 'style' => 'cursor:pointer;']) }}
            </div>
            <div class="w3-col m5"></div>
        </div>
    </footer>

    {{ Form::close() }}


</div>
@endisset



@endsection