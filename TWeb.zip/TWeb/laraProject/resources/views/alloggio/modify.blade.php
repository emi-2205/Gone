@extends('layouts.base')

@section('title', 'Alloggi del locatore')
@if($alloggio->stato == 'Bozza')
@section('heading', 'Modifica di un alloggio in stato di bozza')
@else
@section('heading', 'Modifica di un alloggio')
@endif
@section('legenda', "Puoi modificare i dati del tuo alloggio." )

@section('content')
<div class="w3-card-4">
    {{-- files => true indica che la form potrebbe prendere in input dei file, esempio delle immagini --}}
    {{-- form::model si usa quando i campi delle form sono associate ad attributi di un model, in quel caso dando lo stesso nome, la form visualizza in automatico il valore dell'attributo --}}
    {{ Form::model($alloggio, array('route' => array('alloggio.update', $alloggio->id), 'class' => 'w3-container', 'files' => true)) }}

    @include('componenti/alloggio_management')
    <!-- Azioni proprie dell'inserimento di un nuovo alloggio -->
    <div class="container-form-btn"> 
        {{ Form::submit('Salva alloggio', ['class' => 'w3-btn w3-yellow', 'name' => 'azione']) }}
        @if($alloggio->stato == 'Bozza')
        {{ Form::submit('Pubblica alloggio', ['class' => 'w3-btn w3-green', 'name' => 'azione']) }}
        @endif
        {{-- Se viene premuto annulla si riporta alla vista precedente --}}
        <a href="{{ route('locatore-all-alloggi') }}" class="w3-btn w3-blue">Annulla</a>
        &nbsp;&nbsp;
        <a class="w3-btn w3-red" href="{{ route('alloggio.elimina', [$alloggio->id]) }}" onclick="return confirm('Vuoi veramente cancellare questo alloggio?');">
        Cancella questo alloggio
        </a>
    </div>
    {{ Form::close() }}
    <br>
</div>

@endsection
