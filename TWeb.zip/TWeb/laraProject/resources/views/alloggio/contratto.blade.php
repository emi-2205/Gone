
<!DOCTYPE html>
<html>
    <title>MyUniRent - Contratto di Affitto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/w3.css') }}" >
    <body>

        <div class="w3-container w3-margin-top w3-border" style="width:800px">
            <br>
            <div class="w3-light-grey w3-padding-32 w3-center">
                <h1 class="w3-xxlarge">Contratto di Locazione</h1>
            </div>

            <div class="w3-container w3-margin-top">
                <div class="w3-justify w3-container">
                    <h2>{{ $alloggio->citta }}, {{ date('d/m/Y', strtotime($alloggio->data_ora_contratto)) }}</h2>
                    <p>Il sottoscritto {{ $locatore->name }} {{ $locatore->surname }} in qualià di locatore concede in locazione l'alloggio denominato "{{ $alloggio->nome }}"
                        situato in {{ $alloggio->indirizzo }}, {{ $alloggio->citta }} a {{ $locatario->name }} {{ $locatario->surname }} in qualità di locatario.</p>
                    <p>Il canone di affitto pattuito è pari a {{ $alloggio->canone_affitto }} euro mensili.
                    <hr>
                    <p></p>
                    <p>Letto approvato e sottoscritto</p>
                    <p>Il locatore: {{ $locatore->name }} {{ $locatore->surname }}</p>
                    <br>
                    <p>Il locatario: {{ $locatario->name }} {{ $locatario->surname }}</p>
                    <br>
                    <br>
                </div>
            </div>
        </div>
    </body>
</html>

