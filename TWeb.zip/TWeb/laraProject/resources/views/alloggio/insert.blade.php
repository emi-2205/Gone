@extends('layouts.base')

@section('title', 'Alloggi del locatore')
@section('heading', 'Inserimento di un nuovo alloggio')
@section('legenda', "Puoi inserire qui un nuovo alloggio da affittare." )

@section('content')
<div class="w3-card-4">
{{ Form::model($alloggio, array('route' => array('newalloggio.store'), 'class' => 'w3-container', 'files' => true)) }}

@include('componenti/alloggio_management')

<!-- Azioni proprie dell'inserimento di un nuovo alloggio -->
<div class="container-form-btn">   
    {{ Form::submit('Salva alloggio', ['class' => 'w3-btn w3-yellow', 'name' => 'azione']) }}
    {{ Form::submit('Pubblica alloggio', ['class' => 'w3-btn w3-green', 'name' => 'azione']) }}
    <a href="{{ route('locatore-all-alloggi') }}" class="w3-btn w3-blue">Annulla</a>
</div>
{{ Form::close() }}
<br>
</div>

@endsection
