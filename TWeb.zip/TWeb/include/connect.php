<?php 
$USER="root";
$DB="myunirent_db";
$HOST="127.0.0.1";
$PASSWORD="root";